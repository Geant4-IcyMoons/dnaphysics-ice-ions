#!/usr/bin/env bash
# Prepare, submit, or collect the independent GPAW carbon cDFT pilot.

set -euo pipefail

if (( $# != 1 )) || [[ ! "$1" =~ ^(plan|submit|collect)$ ]]; then
    echo "Usage: $0 {plan|submit|collect}" >&2
    exit 2
fi

ACTION="$1"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
NEP_DIR="${REPO_ROOT}/python_scripts/physics_ice/nep_mbpol"
PYTHON_BIN="${PYTHON_BIN:-${NEP_DIR}/.venv/bin/python}"
SCF_PROFILE="${SCF_PROFILE:-official_damped_pulay}"
OUTPUT_ROOT="${OUTPUT_ROOT:-${REPO_ROOT}/python_scripts/physics_ice/process_evidence/soft_nuclear_collisions/validation/runs/gpaw_cdft_carbon_12A_pilot_damped_pulay}"
MANIFEST="${OUTPUT_ROOT}/manifest.json"

"${PYTHON_BIN}" "${NEP_DIR}/prepare_gpaw_cdft_pilot.py" \
    --projectile C --charges 1 2 --separation-angstrom 12.0 \
    --scf-profile "${SCF_PROFILE}" \
    --output-root "${OUTPUT_ROOT}"

TASK_COUNT="$("${PYTHON_BIN}" -c '
import json, sys
print(json.load(open(sys.argv[1], encoding="utf-8"))["task_count"])
' "${MANIFEST}")"
ARRAY_LAST="$((TASK_COUNT - 1))"

echo "manifest=${MANIFEST}"
echo "tasks=${TASK_COUNT} (q=1,2 x five orientations)"
echo "scf_profile=${SCF_PROFILE}"
echo "resources_per_task=8 CPUs, 8 GB, 96 h"
echo "maximum_concurrent_resources=$((TASK_COUNT * 8)) CPUs, $((TASK_COUNT * 8)) GB"

case "${ACTION}" in
    plan)
        exit 0
        ;;
    submit)
        if ! command -v qsub >/dev/null 2>&1; then
            echo "qsub is unavailable." >&2
            exit 127
        fi
        export MANIFEST REPO_ROOT
        dependency_args=()
        if [[ -n "${INSTALL_JOB_ID:-}" ]]; then
            dependency_args=(-W "depend=afterok:${INSTALL_JOB_ID}")
        fi
        smoke_job="$(qsub "${dependency_args[@]}" \
            -v MANIFEST,REPO_ROOT,TASK_INDEX=0 \
            "${REPO_ROOT}/pbs/run_gpaw_cdft_pilot.pbs")"
        echo "q1_oxygen_back_smoke_job=${smoke_job}"
        if (( TASK_COUNT > 1 )); then
            remaining_job="$(qsub -W "depend=afterok:${smoke_job}" \
                -J "1-${ARRAY_LAST}" -v MANIFEST,REPO_ROOT \
                "${REPO_ROOT}/pbs/run_gpaw_cdft_pilot.pbs")"
            echo "remaining_array_job=${remaining_job}"
        fi
        ;;
    collect)
        "${PYTHON_BIN}" "${NEP_DIR}/collect_gpaw_cdft_pilot.py" \
            --manifest "${MANIFEST}"
        ;;
esac
