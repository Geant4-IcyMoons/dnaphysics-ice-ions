#!/usr/bin/env python3
from argparse import ArgumentParser
from pathlib import Path
from soft_dft.gpaw_mom_retention import build_manifest
p = ArgumentParser(); p.add_argument("--output-root", type=Path, required=True)
args = p.parse_args(); print(build_manifest(args.output_root))
