#!/usr/bin/env python3
from argparse import ArgumentParser
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from soft_dft.gpaw_gmf_fixed_scan import execute

parser = ArgumentParser()
parser.add_argument("--manifest", type=Path, required=True)
parser.add_argument("--task-index", type=int, required=True)
args = parser.parse_args()
print(execute(args.manifest, args.task_index))
