#!/usr/bin/env python3
"""Prepare identity-tracked CAS(9,7) entrance/transfer state averages."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import os
from pathlib import Path

from soft_dft.geometry import ORIENTATIONS, build_scan_geometry


BASIS = "ANO-RCC-VDZP"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def render(orbitals: Path, label: str, roots: tuple[int, int, int]) -> str:
    orientation = next(item for item in ORIENTATIONS if item.name == "oxygen_back")
    geometry = build_scan_geometry(orientation, 20.0, "C")
    coordinates = "\n".join(
        f"    {element:2s} {x: .12f} {y: .12f} {z: .12f}"
        for element, x, y, z in geometry.coordinates_angstrom
    )
    root_text = " ".join(map(str, roots))
    return f"""* Validation-only identity-tracked CAS(9,7) manifold average.
&GATEWAY
  Title = C H2O CAS97 {label} gate at R 20 Angstrom
  Coord = 4
    Angstrom
{coordinates}
  Basis = {BASIS}
  Group = C1
  NoCD

&SEWARD

>>COPY {orbitals} INPORB
&RASSCF
  Title = q1 CAS97 {label} state average
  EXPERT
  LUMORB
  Spin = 2
  NACTEL = 9 0 0
  INACTIVE = 3
  RAS2 = 7
  SUPSYM
    5
    3 4 5 7
    2 6 12
    2 8 14
    2 9 15
    2 10 16
  ORDER = 0
  ITERATIONS = 500 250
  CIROOT = 3 18; {root_text}; 1 1 1
  PRWF = 0.001
  ORBLISTING = ALL
"""


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--pz-orbitals", type=Path, required=True)
    parser.add_argument("--px-orbitals", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    sources = (
        ("pz", args.pz_orbitals.resolve(), "entrance", (4, 5, 6)),
        ("pz", args.pz_orbitals.resolve(), "transfer", (1, 2, 3)),
        ("px", args.px_orbitals.resolve(), "entrance", (2, 4, 6)),
        ("px", args.px_orbitals.resolve(), "transfer", (1, 3, 5)),
    )
    root = args.output_root.resolve()
    tasks = []
    for index, (parent, orbitals, manifold, roots) in enumerate(sources):
        if not orbitals.is_file():
            raise SystemExit(f"Missing source orbitals: {orbitals}")
        label = f"{parent}_{manifold}"
        task_root = root / f"{index:04d}_{label}_cas97_r20A"
        task_root.mkdir(parents=True, exist_ok=True)
        input_path = task_root / "pilot.input"
        input_path.write_text(render(orbitals, label, roots))
        tasks.append(
            {
                "index": index,
                "label": label,
                "component": "cas97_identity_tracked_manifold_average",
                "manifold": manifold,
                "selected_roots": list(roots),
                "separation_angstrom": 20.0,
                "task_root": str(task_root),
                "input_path": str(input_path),
                "input_sha256": sha256(input_path),
                "inventory_orbitals": str(orbitals),
                "inventory_orbitals_sha256": sha256(orbitals),
                "accepted_state": False,
            }
        )
    payload = {
        "schema_version": 1,
        "method": "identity-tracked separate-manifold CAS(9,7) state averages",
        "basis": BASIS,
        "tasks": tasks,
        "production_eligible": False,
    }
    temporary = root / "manifest.json.next"
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, root / "manifest.json")
    print(root / "manifest.json")


if __name__ == "__main__":
    main()
