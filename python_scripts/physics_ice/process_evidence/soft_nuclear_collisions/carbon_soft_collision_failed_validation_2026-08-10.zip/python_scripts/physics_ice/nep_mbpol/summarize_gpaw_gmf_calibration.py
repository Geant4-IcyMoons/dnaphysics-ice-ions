#!/usr/bin/env python3
"""Freeze the valid pre-update evidence from a rejected GPAW calibration."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path

HARTREE_EV = 27.211386024367243


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: object) -> None:
    temporary = path.with_name(path.name + ".next")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.run_root.resolve()
    manifest = json.loads((root / "manifest.json").read_text())
    summaries = []
    for task in manifest["tasks"]:
        matches = list((root / "tasks").glob(
            f"{int(task['task_index']):04d}_*_{task['task_signature'][:12]}"
        ))
        if len(matches) != 1:
            raise RuntimeError(f"Could not resolve task {task['task_index']}.")
        task_root = matches[0]
        trace_path = task_root / "iteration_trace.jsonl"
        rows = [json.loads(line) for line in trace_path.read_text().splitlines()
                if line.strip()]
        if not rows:
            raise RuntimeError(f"Empty trace: {trace_path}")
        initial = [float(value) for value in rows[0]["constraint_coefficients_ev"]]
        first_change = None
        for index, row in enumerate(rows):
            current = [float(value) for value in row["constraint_coefficients_ev"]]
            if any(not math.isclose(a, b, rel_tol=0.0, abs_tol=1.0e-12)
                   for a, b in zip(current, initial)):
                first_change = index
                break
        boundary = len(rows) if first_change is None else first_change
        preupdate = rows[:boundary]
        retained_path = task_root / "preupdate_trace.jsonl"
        retained_path.write_text(
            "".join(json.dumps(row, sort_keys=True) + "\n" for row in preupdate)
        )
        post = None if first_change is None else rows[first_change]
        changed = None if post is None else [
            float(value) for value in post["constraint_coefficients_ev"]
        ]
        step_ev = None if changed is None else [
            value - start for value, start in zip(changed, initial)
        ]
        cdft_log = task_root / "cdft.log"
        preupdate_converged = (
            cdft_log.is_file() and "Iteration: 0" in cdft_log.read_text(errors="replace")
        )
        removed = []
        # Failed calibrations may retain traces but must never expose a
        # post-collapse wavefunction as a restartable state.
        for candidate in (task_root / "final.gpw", task_root / "result.json"):
            if candidate.exists():
                candidate.unlink()
                removed.append(str(candidate))
        summaries.append({
            "task_index": int(task["task_index"]),
            "task_id": task["task_id"],
            "calibration_trial": task["calibration_trial"],
            "constraint_mode": task["constraint_mode"],
            "preupdate_converged": preupdate_converged,
            "preupdate_rows": len(preupdate),
            "preupdate_trace": str(retained_path),
            "preupdate_trace_sha256": sha256_file(retained_path),
            "initial_coefficients_ev": initial,
            "first_updated_coefficients_ev": changed,
            "first_multiplier_step_ev": step_ev,
            "first_multiplier_step_hartree": (
                None if step_ev is None else [value / HARTREE_EV for value in step_ev]
            ),
            "last_preupdate": preupdate[-1],
            "first_postupdate": post,
            "accepted_state": False,
            "restart_wavefunction_allowed": False,
            "removed_postcollapse_state_files": removed,
            "raw_trace_retained_for_rejection_audit": True,
        })
    output = {
        "schema_version": 1,
        "run_root": str(root),
        "interpretation": (
            "Only pre-update traces are retained as numerical evidence; raw "
            "post-update traces remain solely as a rejection audit and no "
            "post-collapse wavefunction is restartable."
        ),
        "tasks": summaries,
    }
    atomic_json(root / "preupdate_summary.json", output)
    print(root / "preupdate_summary.json")


if __name__ == "__main__":
    main()
