#!/usr/bin/env python3
"""Prepare independent 20 A common-orbital CAS(9,7) asymptotic gates."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import os
from pathlib import Path

from soft_dft.geometry import ORIENTATIONS, build_scan_geometry


BASIS = "ANO-RCC-VDZP"
EXPECTED_OPENMOLCAS_COMMIT = "8355057f32d65706a35996b5ab07cac2962bb728"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def render(orbitals: Path, *, six_state_average: bool) -> str:
    orientation = next(item for item in ORIENTATIONS if item.name == "oxygen_back")
    geometry = build_scan_geometry(orientation, 20.0, "C")
    coordinates = "\n".join(
        f"    {element:2s} {x: .12f} {y: .12f} {z: .12f}"
        for element, x, y, z in geometry.coordinates_angstrom
    )
    ciroot = "6 18; 1 2 3 4 5 6; 1 1 1 1 1 1" if six_state_average else "18 18 1"
    return f"""* Validation-only q1 common-orbital CAS(9,7) 18-root gate.
&GATEWAY
  Title = C H2O CAS97 gate at R 20 Angstrom
  Coord = 4
    Angstrom
{coordinates}
  Basis = {BASIS}
  Group = C1
  NoCD

&SEWARD

>>COPY {orbitals} INPORB
&RASSCF
  Title = q1 common CAS97 eighteen root state average
  EXPERT
  LUMORB
  Spin = 2
  NACTEL
    9 0 0
  INACTIVE
    3
  RAS2
    7
  SUPSYM
    5
    3 4 5 7
    2 6 12
    2 8 14
    2 9 15
    2 10 16
  ORDER = 0
  ITERATIONS = 400 200
  CIROOT = {ciroot}
  PRWF = 0.001
  ORBLISTING = ALL
"""


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--orbitals", type=Path, action="append", required=True)
    parser.add_argument("--labels", action="append", required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--six-state-average", action="store_true")
    args = parser.parse_args()
    if len(args.orbitals) != len(args.labels) or len(args.orbitals) < 2:
        raise SystemExit("At least two independent CAS(5,5) orbital files are required")
    root = args.output_root.resolve()
    tasks = []
    for index, (path, label) in enumerate(zip(args.orbitals, args.labels, strict=True)):
        path = path.resolve()
        if not path.is_file():
            raise SystemExit(f"Missing source orbitals: {path}")
        task_root = root / f"{index:04d}_{label}_cas97_r20A"
        task_root.mkdir(parents=True, exist_ok=True)
        input_path = task_root / "pilot.input"
        input_path.write_text(render(path, six_state_average=args.six_state_average))
        tasks.append(
            {
                "index": index,
                "label": label,
                "component": "common_cas97_18roots",
                "separation_angstrom": 20.0,
                "task_root": str(task_root),
                "input_path": str(input_path),
                "input_sha256": sha256(input_path),
                "inventory_orbitals": str(path),
                "inventory_orbitals_sha256": sha256(path),
                "accepted_state": False,
            }
        )
    payload = {
        "schema_version": 1,
        "method": (
            "common-orbital CAS(9,7), 18 roots retained, six relevant roots averaged"
            if args.six_state_average
            else "common-orbital state-averaged CAS(9,7), 18 roots"
        ),
        "active_orbitals": [
            "H2O_1b2", "H2O_3a1", "C_2s", "H2O_1b1",
            "C_2p_z", "C_2p_x", "C_2p_y"
        ],
        "basis": BASIS,
        "expected_openmolcas_commit": EXPECTED_OPENMOLCAS_COMMIT,
        "tasks": tasks,
        "production_eligible": False,
    }
    root.mkdir(parents=True, exist_ok=True)
    temporary = root / "manifest.json.next"
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, root / "manifest.json")
    print(root / "manifest.json")


if __name__ == "__main__":
    main()
