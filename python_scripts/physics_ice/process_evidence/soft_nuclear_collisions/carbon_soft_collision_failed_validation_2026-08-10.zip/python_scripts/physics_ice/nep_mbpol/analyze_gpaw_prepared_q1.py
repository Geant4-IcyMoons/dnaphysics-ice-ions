#!/usr/bin/env python3
"""Analyze immutable GPAW q=1 checkpoints without electronic iterations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

SCRIPT_DIRECTORY = Path(__file__).resolve().parent
if str(SCRIPT_DIRECTORY) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIRECTORY))

from soft_dft.gpaw_q1_checkpoint_analysis import analyze_checkpoints


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze_checkpoints(args.run_root, args.output)
    print(json.dumps(result["acceptance_summary"], sort_keys=True))


if __name__ == "__main__":
    main()
