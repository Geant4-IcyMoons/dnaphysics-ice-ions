#!/usr/bin/env python3
"""Prepare the validation-only OpenMolcas q=1 asymptotic fragment gate."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import math
import os
from pathlib import Path


EXPECTED_OPENMOLCAS_COMMIT = "8355057f32d65706a35996b5ab07cac2962bb728"

CARBON_GUESS_PARTNERS = {
    # (radial-s partner, radial-p partners), established from basis-specific
    # spherical GATEWAY orbital inventories rather than assumed ordering.
    ("ANO-RCC-VDZP", False): (6, "12 13 14"),
    ("ANO-RCC-VDZP", True): (17, "23 24 25"),
    ("ANO-RCC-VTZP", False): (6, "7 8 9"),
    ("ANO-RCC-VTZP", True): (14, "19 20 21"),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".next")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def basis_block(
    label: str,
    element: str,
    xyz: tuple[float, float, float],
    ghost: bool,
    basis: str,
) -> str:
    charge = "\n  Charge\n    0.0" if ghost else ""
    x, y, z = xyz
    return f"""  Basis set
    {element}.{basis}.
    {label} {x:.12f} {y:.12f} {z:.12f} Angstrom{charge}
  End of basis"""


def render_input(
    fragment: str,
    counterpoise: bool,
    separation: float,
    active_space: str,
    basis: str,
) -> str:
    oh = 0.9572
    half_angle = math.radians(104.52 / 2.0)
    hx, hz = oh * math.sin(half_angle), oh * math.cos(half_angle)
    atoms = [
        ("C", 0.0, 0.0, -separation),
        ("O", 0.0, 0.0, 0.0),
        ("H", hx, 0.0, hz),
        ("H", -hx, 0.0, hz),
    ]
    labels = ("C1", "O1", "H1", "H2")
    blocks = []
    for label, (element, x, y, z) in zip(labels, atoms):
        belongs = (fragment == "carbon" and element == "C") or (
            fragment == "water" and element != "C"
        )
        if belongs or counterpoise:
            blocks.append(
                basis_block(label, element, (x, y, z), ghost=not belongs, basis=basis)
            )

    if fragment == "carbon":
        if active_space == "cas34":
            states = (
                ("cation", 1, 2, 1, 2, 3, "3 3 1"),
                ("neutral", 0, 3, 2, 2, 3, "3 3 1"),
            )
        else:
            states = (
                ("cation", 1, 2, 3, 1, 4, "3 3 1"),
                ("neutral", 0, 3, 4, 1, 4, "3 3 1"),
            )
    elif fragment == "water":
        if active_space == "cas97":
            states = (
                ("neutral", 0, 1, 6, 2, 3, "1 1 1"),
                ("cation", 1, 2, 5, 2, 3, "1 1 1"),
            )
        else:
            states = (
                ("neutral", 0, 1, 2, 4, 1, "1 1 1"),
                ("cation", 1, 2, 1, 4, 1, "1 1 1"),
            )
    else:
        raise ValueError(fragment)

    calculations = []
    for state, charge, spin, active_electrons, inactive, active_orbitals, roots in states:
        # In C1, an unconstrained atomic CASSCF can mix one 2p component
        # with the 3s orbital and spuriously split the 2P/3P manifold.  The
        # verified C atomic UHF ordering is 3--5 (2p) and 7--9 (radial 3p).
        # Keep that six-orbital p subspace closed under orbital rotations.
        if fragment == "carbon":
            # GATEWAY's spherical atomic guess has the three fractionally
            # occupied C(2p) orbitals at 3--5.  Its C(3p) partners are 12--14
            # in the isolated basis and 23--25 when the remote ghost basis is
            # present.  Starting directly from this state-averaged guess avoids
            # selecting one arbitrary UHF 2P component.
            try:
                radial_s, radial = CARBON_GUESS_PARTNERS[(basis, counterpoise)]
            except KeyError as error:
                raise ValueError(
                    f"No audited carbon orbital inventory for {basis}, "
                    f"counterpoise={counterpoise}"
                ) from error
            if active_space == "cas34":
                orbital_subspace = f"  SUPSYM\n    1\n    6 3 4 5 {radial}\n"
            else:
                orbital_subspace = (
                    f"  SUPSYM\n    2\n    2 2 {radial_s}\n"
                    f"    6 3 4 5 {radial}\n"
                )
            preparation = ">>COPY fragment.GssOrb INPORB\n"
        else:
            orbital_subspace = ""
            preparation = f"""&SCF
  Title = {fragment} {state} orbital preparation
  Charge = {charge}
  Spin = {spin}
  ITERATIONS = 200
  THRESHOLDS = 1.0d-10 1.0d-08 1.0d-08 1.0d-08

"""
        alter = ""
        calculations.append(
            f"""{preparation}&RASSCF
  Title = {fragment} {state} state averaged fragment
  LUMORB
  Charge = {charge}
  Spin = {spin}
  NACTEL
    {active_electrons} 0 0
  INACTIVE
    {inactive}
  RAS2
    {active_orbitals}
{orbital_subspace}  ORDER = 0
{alter}  ITERATIONS = 200 100
  CIROOT = {roots}
  PRWF = 0.001

>>COPY fragment.JobIph fragment_{state}.JobIph
>>COPY fragment.RasOrb fragment_{state}.RasOrb
"""
        )
    cp_label = "counterpoise" if counterpoise else "isolated"
    return f"""* OpenMolcas q=1 asymptotic fragment gate; validation only.
&GATEWAY
  Title = {fragment} {cp_label} at R {separation:.1f} Angstrom
{os.linesep.join(blocks)}
  NoCD

&SEWARD

{os.linesep.join(calculations)}"""


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--separation", type=float, default=20.0)
    parser.add_argument(
        "--active-space", choices=("cas34", "cas55", "cas97"), default="cas34"
    )
    parser.add_argument(
        "--basis", choices=("ANO-RCC-VDZP", "ANO-RCC-VTZP"), default="ANO-RCC-VDZP"
    )
    args = parser.parse_args()
    root = args.output_root.resolve()
    tasks = []
    for index, (fragment, counterpoise) in enumerate(
        (("carbon", False), ("water", False), ("carbon", True), ("water", True))
    ):
        label = f"{fragment}_{'cp' if counterpoise else 'isolated'}"
        task_root = root / f"{index:04d}_{label}"
        task_root.mkdir(parents=True, exist_ok=True)
        input_path = task_root / "fragment.input"
        input_path.write_text(
            render_input(
                fragment, counterpoise, args.separation, args.active_space, args.basis
            )
        )
        tasks.append(
            {
                "index": index,
                "label": label,
                "fragment": fragment,
                "counterpoise": counterpoise,
                "task_root": str(task_root),
                "input_path": str(input_path),
                "input_sha256": sha256(input_path),
                "accepted": False,
            }
        )
    atomic_json(
        root / "manifest.json",
        {
            "schema_version": 1,
            "method": "state-averaged fragment CASSCF asymptotic and counterpoise gate",
            "basis": args.basis,
            "active_space": args.active_space,
            "separation_angstrom": args.separation,
            "expected_openmolcas_commit": EXPECTED_OPENMOLCAS_COMMIT,
            "tasks": tasks,
            "production_eligible": False,
        },
    )
    print(root / "manifest.json")


if __name__ == "__main__":
    main()
