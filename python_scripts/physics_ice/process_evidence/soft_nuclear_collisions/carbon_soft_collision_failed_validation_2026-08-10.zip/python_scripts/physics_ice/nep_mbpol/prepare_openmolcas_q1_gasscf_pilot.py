#!/usr/bin/env python3
"""Prepare validation-only occupation-restricted GASSCF q=1 pilots."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import os
from pathlib import Path

from soft_dft.geometry import ORIENTATIONS, build_scan_geometry


REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
EXPECTED_OPENMOLCAS_COMMIT = "8355057f32d65706a35996b5ab07cac2962bb728"
BASIS = "ANO-RCC-VDZP"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".next")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def permutation_swaps(desired_first_ten: tuple[int, ...]) -> list[tuple[int, int]]:
    current = list(range(1, 11))
    swaps: list[tuple[int, int]] = []
    for position, wanted in enumerate(desired_first_ten):
        if current[position] == wanted:
            continue
        other = current.index(wanted)
        swaps.append((position + 1, other + 1))
        current[position], current[other] = current[other], current[position]
    if tuple(current) != desired_first_ten:
        raise AssertionError("Failed to construct the requested orbital permutation")
    return swaps


def render_input(
    separation: float,
    component: str,
    inventory_orbitals: Path,
    *,
    orbitals_preordered: bool = False,
) -> tuple[str, list[tuple[int, int]]]:
    orientation = next(item for item in ORIENTATIONS if item.name == "oxygen_back")
    geometry = build_scan_geometry(orientation, separation, "C")
    coordinates = "\n".join(
        f"    {element:2s} {x: .12f} {y: .12f} {z: .12f}"
        for element, x, y, z in geometry.coordinates_angstrom
    )

    # The verified UHF inventory gives original orbitals 8=H2O donor,
    # 5=C(2pz), 9=C(2px), and 10=C(2py).  Positions 7--10 are made active.
    selected = {"entrance_pz": 5, "entrance_px": 9, "entrance_py": 10}
    ciroot = "1 1 1"
    if component in selected:
        chosen = selected[component]
        other = tuple(index for index in (5, 9, 10) if index != chosen)
        active = (8, chosen, *other)
        # Each directional C(2p) orbital must remain able to relax into its
        # same-direction radial C(3p) partner.  Isolating the valence orbital
        # alone gives a false 20 A splitting of the atomic 2P components.
        radial_partner = {5: 14, 9: 15, 10: 16}
        p_groups = "\n".join(
            f"    2 {position} {radial_partner[original]}"
            for position, original in enumerate(active[1:], start=8)
        )
        gas = """  GASSCF
    4
    1
    2 2
    1
    3 3
    1
    3 3
    1
    3 3
  SUPSYM
    4
    1 7
""" + p_groups + "\n"
    elif component == "entrance_manifold":
        active = (8, 5, 9, 10)
        gas = """  GASSCF
    2
    1
    2 2
    3
    3 3
  SUPSYM
    2
    1 7
    6 8 9 10 14 15 16
"""
        ciroot = "3 3 1"
    elif component == "common_cas6":
        active = (8, 5, 9, 10)
        gas = """  RAS2
    4
  SUPSYM
    2
    1 7
    6 8 9 10 14 15 16
"""
        ciroot = "6 6 1"
    elif component == "transfer_lowest":
        active = (8, 5, 9, 10)
        gas = """  GASSCF
    2
    1
    1 1
    3
    3 3
  SUPSYM
    2
    1 7
    6 8 9 10 14 15 16
"""
    else:
        raise ValueError(f"Unknown component: {component}")

    desired = (1, 2, 3, 4, 6, 7, *active)
    swaps = [] if orbitals_preordered else permutation_swaps(desired)
    alter = "; ".join(f"1 {left} {right}" for left, right in swaps)
    spin_orbital_selection = "" if orbitals_preordered else "  ALPHAORBETA = 1\n"
    alter_input = "" if orbitals_preordered else f"  ALTER = {len(swaps)}; {alter}\n"
    return (
        f"""* Validation-only OpenMolcas q=1 occupation-restricted GASSCF pilot.
&GATEWAY
  Title = C+--H2O {component}, R={separation:.1f} A
  Coord = 4
    Angstrom
{coordinates}
  Basis = {BASIS}
  Group = C1
  NoCD

&SEWARD

>>COPY {inventory_orbitals} INPORB
&RASSCF
  Title = q1 {component}, R={separation:.1f} A
  EXPERT
  LUMORB
{spin_orbital_selection}  Spin = 2
  NACTEL
    3 0 0
  INACTIVE
    6
{gas}{alter_input}
  ITERATIONS = 200 100
  CIROOT = {ciroot}
  PRWF = 0.001
  ORBLISTING = ALL
""",
        swaps,
    )


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--inventory-root", type=Path, required=True)
    parser.add_argument("--inventory-job-id", required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--separation", type=float, choices=(12.0, 20.0), default=20.0)
    parser.add_argument("--alternate-preordered-orbitals", type=Path)
    args = parser.parse_args()

    inventory_task = 0 if args.separation == 20.0 else 1
    inventory_attempt = (
        args.inventory_root.resolve()
        / f"{inventory_task:04d}_oxygen_back_r{int(args.separation)}A"
        / "attempts"
        / args.inventory_job_id
    )
    completion = inventory_attempt / "inventory.completed.json"
    orbitals = inventory_attempt / "scratch" / "inventory" / "inventory.UhfOrb"
    if not completion.is_file() or not orbitals.is_file():
        raise SystemExit("A normally completed matching orbital inventory is required")

    components = (
        "entrance_px",
        "entrance_py",
        "entrance_pz",
        "transfer_lowest",
        "entrance_manifold",
        "common_cas6",
    )
    orbitals_preordered = args.alternate_preordered_orbitals is not None
    if orbitals_preordered:
        orbitals = args.alternate_preordered_orbitals.resolve()
        if not orbitals.is_file():
            raise SystemExit("The alternate preordered orbital file is missing")
        components = ("common_cas6",)
    root = args.output_root.resolve()
    tasks = []
    for index, component in enumerate(components):
        task_root = root / f"{index:04d}_{component}_r{int(args.separation)}A"
        task_root.mkdir(parents=True, exist_ok=True)
        input_path = task_root / "pilot.input"
        rendered, swaps = render_input(
            args.separation,
            component,
            orbitals,
            orbitals_preordered=orbitals_preordered,
        )
        input_path.write_text(rendered, encoding="utf-8")
        tasks.append(
            {
                "index": index,
                "component": component,
                "separation_angstrom": args.separation,
                "task_root": str(task_root),
                "input_path": str(input_path),
                "input_sha256": sha256(input_path),
                "inventory_orbitals": str(orbitals),
                "inventory_orbitals_sha256": sha256(orbitals),
                "orbital_swaps": swaps,
                "accepted_state": False,
            }
        )
    manifest = {
        "schema_version": 1,
        "method": "occupation-restricted GASSCF pilot; not BLW",
        "expected_openmolcas_commit": EXPECTED_OPENMOLCAS_COMMIT,
        "basis": BASIS,
        "total_charge": 1,
        "multiplicity": 2,
        "orientation": "oxygen_back",
        "separation_angstrom": args.separation,
        "inventory_job_id": args.inventory_job_id,
        "orbitals_preordered": orbitals_preordered,
        "inventory_completion_sha256": sha256(completion),
        "tasks": tasks,
        "production_eligible": False,
    }
    manifest_path = root / "manifest.json"
    atomic_json(manifest_path, manifest)
    print(manifest_path)


if __name__ == "__main__":
    main()
