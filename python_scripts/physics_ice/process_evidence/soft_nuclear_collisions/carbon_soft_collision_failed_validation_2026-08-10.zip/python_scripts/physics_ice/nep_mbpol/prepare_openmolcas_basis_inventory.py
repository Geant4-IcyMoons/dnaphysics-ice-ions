#!/usr/bin/env python3
"""Prepare carbon orbital inventories for an OpenMolcas basis-set gate."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import math
import os
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geometry() -> tuple[tuple[str, str, float, float, float], ...]:
    oh = 0.9572
    angle = math.radians(104.52 / 2.0)
    x, z = oh * math.sin(angle), oh * math.cos(angle)
    return (
        ("C1", "C", 0.0, 0.0, -20.0),
        ("O1", "O", 0.0, 0.0, 0.0),
        ("H1", "H", x, 0.0, z),
        ("H2", "H", -x, 0.0, z),
    )


def render(basis: str, counterpoise: bool) -> str:
    blocks = []
    for label, element, x, y, z in geometry():
        if element != "C" and not counterpoise:
            continue
        ghost = "\n  Charge\n    0.0" if element != "C" else ""
        blocks.append(
            f"""  Basis set
    {element}.{basis}.
    {label} {x:.12f} {y:.12f} {z:.12f} Angstrom{ghost}
  End of basis"""
        )
    return f"""* Carbon spherical-guess orbital inventory; not a physical result.
&GATEWAY
  Title = carbon {'counterpoise' if counterpoise else 'isolated'} basis inventory
{os.linesep.join(blocks)}
  NoCD

&SEWARD
"""


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--basis", default="ANO-RCC-VTZP")
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.output_root.resolve()
    tasks = []
    for index, counterpoise in enumerate((False, True)):
        label = "carbon_cp" if counterpoise else "carbon_isolated"
        task_root = root / f"{index:04d}_{label}"
        task_root.mkdir(parents=True, exist_ok=True)
        input_path = task_root / "inventory.input"
        input_path.write_text(render(args.basis, counterpoise))
        tasks.append(
            {
                "index": index,
                "label": label,
                "task_root": str(task_root),
                "input_path": str(input_path),
                "input_sha256": sha256(input_path),
            }
        )
    payload = {
        "schema_version": 1,
        "purpose": "basis-specific orbital inventory only",
        "basis": args.basis,
        "tasks": tasks,
        "production_eligible": False,
    }
    temporary = root / "manifest.json.next"
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, root / "manifest.json")
    print(root / "manifest.json")


if __name__ == "__main__":
    main()
