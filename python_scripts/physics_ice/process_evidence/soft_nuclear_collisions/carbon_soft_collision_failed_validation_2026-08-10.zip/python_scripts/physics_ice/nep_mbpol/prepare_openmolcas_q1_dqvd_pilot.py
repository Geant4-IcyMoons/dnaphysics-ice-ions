#!/usr/bin/env python3
"""Prepare Boys-limit DQPhi diabatization of common-CAS q=1 manifolds."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import os
from pathlib import Path

from soft_dft.geometry import ORIENTATIONS, build_scan_geometry


BASIS = "ANO-RCC-VDZP"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".next")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def render_input(separation: float, jobiph: Path) -> str:
    orientation = next(item for item in ORIENTATIONS if item.name == "oxygen_back")
    geometry = build_scan_geometry(orientation, separation, "C")
    coordinates = "\n".join(
        f"    {element:2s} {x: .12f} {y: .12f} {z: .12f}"
        for element, x, y, z in geometry.coordinates_angstrom
    )
    return f"""* Validation-only Boys-limit DQPhi diabatization of common CAS(3,4).
&GATEWAY
  Title = C--H2O common-CAS DQPhi pilot, R={separation:.1f} A
  Coord = 4
    Angstrom
{coordinates}
  Basis = {BASIS}
  Group = C1
  NoCD
  EPOT
    1
    0.0 0.0 0.0

&SEWARD

>>COPY {jobiph} JOB001
&RASSI
  NROFJOBIPHS = 1 6
    1 2 3 4 5 6
  IPHNAMES
    JOB001
  MEIN
  MEES
  CIPRINT
  DQVD
  ALPHA = 0.0
  BETA = 0.0
"""


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--common-20-root", type=Path, required=True)
    parser.add_argument("--common-20-job-id", required=True)
    parser.add_argument("--common-20-task-index", type=int, default=5)
    parser.add_argument("--common-12-root", type=Path, required=True)
    parser.add_argument("--common-12-job-id", required=True)
    parser.add_argument("--common-12-task-index", type=int, default=5)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.output_root.resolve()
    tasks = []
    for index, (separation, source_root, job_id, task_index) in enumerate(
        (
            (
                20.0,
                args.common_20_root.resolve(),
                args.common_20_job_id,
                args.common_20_task_index,
            ),
            (
                12.0,
                args.common_12_root.resolve(),
                args.common_12_job_id,
                args.common_12_task_index,
            ),
        )
    ):
        jobiph = (
            source_root / f"{task_index:04d}_common_cas6_r{int(separation)}A" / "attempts"
            / f"{job_id}.pbs02" / "scratch" / "pilot" / "pilot.JobIph"
        )
        if not jobiph.is_file():
            raise SystemExit(f"Missing common-CAS JOBIPH at {separation:.0f} A")
        task_root = root / f"{index:04d}_dqvd_r{int(separation)}A"
        task_root.mkdir(parents=True, exist_ok=True)
        input_path = task_root / "dqvd.input"
        input_path.write_text(render_input(separation, jobiph), encoding="utf-8")
        tasks.append(
            {
                "index": index,
                "separation_angstrom": separation,
                "task_root": str(task_root),
                "input_path": str(input_path),
                "input_sha256": sha256(input_path),
                "jobiph": str(jobiph),
                "jobiph_sha256": sha256(jobiph),
                "accepted_diabatization": False,
            }
        )
    atomic_json(
        root / "manifest.json",
        {
            "schema_version": 1,
            "method": "OpenMolcas DQPhi with alpha=beta=0 (Boys limit)",
            "tasks": tasks,
            "production_eligible": False,
        },
    )
    print(root / "manifest.json")


if __name__ == "__main__":
    main()
