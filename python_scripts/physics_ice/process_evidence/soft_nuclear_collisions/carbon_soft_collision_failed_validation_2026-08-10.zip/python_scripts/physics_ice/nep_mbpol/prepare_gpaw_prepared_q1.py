#!/usr/bin/env python3
"""Prepare the immutable four-component GPAW q=1 manifest."""

from __future__ import annotations

import argparse
from pathlib import Path

from soft_dft.gpaw_prepared_q1 import PreparedQ1Settings, build_manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--charge-coefficient-hartree", type=float, default=0.1)
    parser.add_argument("--spin-coefficient-hartree", type=float, default=0.1)
    args = parser.parse_args()
    settings = PreparedQ1Settings(
        charge_coefficient_hartree=args.charge_coefficient_hartree,
        spin_coefficient_hartree=args.spin_coefficient_hartree,
    )
    path = build_manifest(args.output_root, settings)
    print(f"manifest={path}")
    print("tasks=4")
    print("production_eligible=false")


if __name__ == "__main__":
    main()
