#!/usr/bin/env python3
from argparse import ArgumentParser
from pathlib import Path
import sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from soft_dft.gpaw_gmf_anchor import execute
p = ArgumentParser(); p.add_argument("--manifest", type=Path, required=True)
a = p.parse_args(); print(execute(a.manifest))
