#!/usr/bin/env python3
"""Prepare the independent GPAW q/orientation cDFT pilot manifest."""

from __future__ import annotations

import argparse
from dataclasses import replace
from pathlib import Path

from ion_ice import PROCESS_EVIDENCE_ROOT
from soft_dft.geometry import ORIENTATIONS
from soft_dft.gpaw_cdft import (
    DEFAULT_GPAW_CDFT_SETTINGS,
    SCF_PROFILES,
    build_pilot_manifest,
    load_pilot_manifest,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--projectile", default="C")
    parser.add_argument("--charges", nargs="+", type=int, default=(1, 2))
    parser.add_argument(
        "--orientations",
        nargs="+",
        choices=[item.name for item in ORIENTATIONS],
        default=[item.name for item in ORIENTATIONS],
    )
    parser.add_argument("--separation-angstrom", type=float, default=12.0)
    parser.add_argument("--scf-profile", choices=SCF_PROFILES, default="default")
    parser.add_argument(
        "--output-root",
        type=Path,
        default=(
            PROCESS_EVIDENCE_ROOT
            / "soft_nuclear_collisions"
            / "validation"
            / "runs"
            / "gpaw_cdft_carbon_12A_pilot"
        ),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    from soft_dft.config import load_builtin_projectile

    manifest_path = build_pilot_manifest(
        args.output_root,
        projectile=load_builtin_projectile(args.projectile),
        charges=args.charges,
        orientations=args.orientations,
        separation_angstrom=args.separation_angstrom,
        settings=replace(
            DEFAULT_GPAW_CDFT_SETTINGS, scf_profile=args.scf_profile
        ),
    )
    manifest = load_pilot_manifest(manifest_path)
    print(f"manifest={manifest_path}")
    print(f"task_count={manifest['task_count']}")
    print("scientific_status=numerical_cdft_pilot")
    print("production_eligible=false")


if __name__ == "__main__":
    main()
