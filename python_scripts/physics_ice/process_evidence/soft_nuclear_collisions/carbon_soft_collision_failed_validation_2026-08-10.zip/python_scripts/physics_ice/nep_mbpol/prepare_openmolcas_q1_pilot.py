#!/usr/bin/env python3
"""Prepare the fail-closed orbital inventory for the OpenMolcas q=1 pilot."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import os
from pathlib import Path

from soft_dft.geometry import ORIENTATIONS, build_scan_geometry


REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
EXPECTED_OPENMOLCAS_COMMIT = "8355057f32d65706a35996b5ab07cac2962bb728"
BASIS = "ANO-RCC-VDZP"
WORKFLOW_SOURCES = (
    Path(__file__).resolve(),
    REPOSITORY_ROOT / "pbs" / "run_openmolcas_q1_inventory.pbs",
    REPOSITORY_ROOT / "pbs" / "install_openmolcas.pbs",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".next")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def render_inventory_input(separation: float) -> str:
    orientation = next(item for item in ORIENTATIONS if item.name == "oxygen_back")
    geometry = build_scan_geometry(orientation, separation, "C")
    coordinates = "\n".join(
        f"    {element:2s} {x: .12f} {y: .12f} {z: .12f}"
        for element, x, y, z in geometry.coordinates_angstrom
    )
    return f"""* OpenMolcas q=1 orbital inventory; never a physical state result.
&GATEWAY
  Title = C+--H2O oxygen-back, R={separation:.1f} A, orbital inventory
  Coord = 4
    Angstrom
{coordinates}
  Basis = {BASIS}
  Group = C1
  NoCD

&SEWARD

&GUESSORB
  PRMO = 4 5.0
  PRPOPULATION
  GAPTHR = 0.5

* This UHF calculation inventories a numerical starting orbital set only.
* It is not accepted as an entrance or transfer diabat.
&SCF
  UHF
  Charge = 1
  Spin = 2
  ITERATIONS = 250
  THRESHOLDS = 1.0d-10 1.0d-6 1.0d-6 1.0d-6
  PRORBITALS = 2 1.0d99
"""


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.output_root.resolve()
    tasks = []
    for index, separation in enumerate((20.0, 12.0)):
        task_root = root / f"{index:04d}_oxygen_back_r{int(separation)}A"
        task_root.mkdir(parents=True, exist_ok=True)
        input_path = task_root / "inventory.input"
        input_path.write_text(render_inventory_input(separation), encoding="utf-8")
        tasks.append(
            {
                "index": index,
                "separation_angstrom": separation,
                "task_root": str(task_root),
                "input_path": str(input_path),
                "input_sha256": sha256(input_path),
                "accepted_state": False,
                "purpose": "orbital_inventory_only",
            }
        )
    manifest = {
        "schema_version": 1,
        "method": "OpenMolcas UHF orbital inventory before GASSCF construction",
        "openmolcas_version": "v26.06",
        "expected_openmolcas_commit": EXPECTED_OPENMOLCAS_COMMIT,
        "basis": BASIS,
        "total_charge": 1,
        "multiplicity": 2,
        "orientation": "oxygen_back",
        "execution_order": [20.0, 12.0],
        "source": {
            str(path.relative_to(REPOSITORY_ROOT)): sha256(path)
            for path in WORKFLOW_SOURCES
        },
        "tasks": tasks,
        "production_eligible": False,
    }
    manifest_path = root / "manifest.json"
    atomic_json(manifest_path, manifest)
    print(manifest_path)


if __name__ == "__main__":
    main()
