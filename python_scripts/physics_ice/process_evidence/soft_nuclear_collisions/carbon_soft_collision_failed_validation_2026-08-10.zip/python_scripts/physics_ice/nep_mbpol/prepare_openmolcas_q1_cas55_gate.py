#!/usr/bin/env python3
"""Prepare independent 20 A common-orbital CAS(5,5) asymptotic gates."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import os
from pathlib import Path

from soft_dft.geometry import ORIENTATIONS, build_scan_geometry


BASIS = "ANO-RCC-VDZP"
EXPECTED_OPENMOLCAS_COMMIT = "8355057f32d65706a35996b5ab07cac2962bb728"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def render(orbitals: Path, manifold: str, *, preordered: bool) -> str:
    orientation = next(item for item in ORIENTATIONS if item.name == "oxygen_back")
    geometry = build_scan_geometry(orientation, 20.0, "C")
    coordinates = "\n".join(
        f"    {element:2s} {x: .12f} {y: .12f} {z: .12f}"
        for element, x, y, z in geometry.coordinates_angstrom
    )
    ciroot = {
        "common": "12 12 1",
        "entrance": "3 12; 1 2 3; 1 1 1",
        "transfer": "3 12; 4 5 6; 1 1 1",
    }[manifold]
    alter = "" if preordered else "  ALTER = 1; 1 4 6\n"
    return f"""* Validation-only q1 CAS(5,5) {manifold} state-average gate.
&GATEWAY
  Title = C H2O CAS55 gate at R 20 Angstrom
  Coord = 4
    Angstrom
{coordinates}
  Basis = {BASIS}
  Group = C1
  NoCD

&SEWARD

>>COPY {orbitals} INPORB
&RASSCF
  Title = q1 CAS55 {manifold} state average
  EXPERT
  LUMORB
  Spin = 2
  NACTEL
    5 0 0
  INACTIVE
    5
  RAS2
    5
{alter}  SUPSYM
    5
    1 7
    2 6 12
    2 8 14
    2 9 15
    2 10 16
  ORDER = 0
  ITERATIONS = 300 150
  CIROOT = {ciroot}
  TDM
  PRWF = 0.001
  ORBLISTING = ALL
"""


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--orbitals", type=Path, action="append", required=True)
    parser.add_argument("--labels", action="append", required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--manifold-averages", action="store_true")
    parser.add_argument("--preordered", action="store_true")
    args = parser.parse_args()
    if len(args.orbitals) != len(args.labels) or len(args.orbitals) < 2:
        raise SystemExit("At least two independently prepared orbital files are required")
    root = args.output_root.resolve()
    tasks = []
    variants = ("entrance", "transfer") if args.manifold_averages else ("common",)
    for path, label in zip(args.orbitals, args.labels, strict=True):
        path = path.resolve()
        if not path.is_file():
            raise SystemExit(f"Missing source orbitals: {path}")
        for manifold in variants:
            index = len(tasks)
            task_root = root / f"{index:04d}_{label}_{manifold}_cas55_r20A"
            task_root.mkdir(parents=True, exist_ok=True)
            input_path = task_root / "pilot.input"
            input_path.write_text(render(path, manifold, preordered=args.preordered))
            tasks.append({
                "index": index,
                "label": label,
                "component": f"{manifold}_cas55_12roots",
                "manifold_average": manifold,
                "orbitals_preordered_cas55": args.preordered,
                "separation_angstrom": 20.0,
                "task_root": str(task_root),
                "input_path": str(input_path),
                "input_sha256": sha256(input_path),
                "inventory_orbitals": str(path),
                "inventory_orbitals_sha256": sha256(path),
                "accepted_state": False,
            })
    payload = {
        "schema_version": 1,
        "method": "CAS(5,5) manifold state averages in one common configuration space",
        "active_orbitals": ["C_2s", "H2O_1b1", "C_2p_z", "C_2p_x", "C_2p_y"],
        "basis": BASIS,
        "expected_openmolcas_commit": EXPECTED_OPENMOLCAS_COMMIT,
        "tasks": tasks,
        "production_eligible": False,
    }
    temporary = root / "manifest.json.next"
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, root / "manifest.json")
    print(root / "manifest.json")


if __name__ == "__main__":
    main()
