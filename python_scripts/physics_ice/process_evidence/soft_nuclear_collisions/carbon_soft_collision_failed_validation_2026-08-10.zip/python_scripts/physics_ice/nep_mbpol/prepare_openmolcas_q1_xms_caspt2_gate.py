#!/usr/bin/env python3
"""Prepare the matched 20 A XMS-CASPT2 supermolecule/fragment gate."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import math
import os
from pathlib import Path


BASIS = "ANO-RCC-VDZP"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def caspt2_block(nroots: int, frozen: int) -> str:
    roots = " ".join(str(index) for index in range(1, nroots + 1))
    multistate = f"  XMULTISTATE = {nroots} {roots}\n" if nroots > 1 else ""
    return f"""&CASPT2
  Title = q1 asymptotic dynamic correlation gate
  FROZEN = {frozen}
{multistate}  IPEA = 0.25
  MAXITER = 100
  CONVERGENCE = 1.0d-9
"""


def super_gateway() -> str:
    # Match the fixed NIST TIP4P/2005 pilot geometry used to create the
    # validated CASSCF JOBIPH files, without importing the broader soft-DFT
    # package (which unnecessarily pulls SciPy into this manifest preparer).
    oh = 0.9572
    half_angle = math.radians(104.52 / 2.0)
    hx = oh * math.sin(half_angle)
    hz = oh * math.cos(half_angle)
    geometry = (
        ("C", 0.0, 0.0, -20.0),
        ("O", 0.0, 0.0, 0.0),
        ("H", hx, 0.0, hz),
        ("H", -hx, 0.0, hz),
    )
    coordinates = "\n".join(
        f"    {element:2s} {x: .12f} {y: .12f} {z: .12f}"
        for element, x, y, z in geometry
    )
    return f"""&GATEWAY
  Title = C H2O XMS CASPT2 gate at R 20 Angstrom
  Coord = 4
    Angstrom
{coordinates}
  Basis = {BASIS}
  Group = C1
  NoCD

&SEWARD
"""


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--super-jobiph", type=Path, action="append", required=True)
    parser.add_argument("--super-label", action="append", required=True)
    parser.add_argument("--carbon-cp-attempt", type=Path, required=True)
    parser.add_argument("--water-cp-attempt", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    if len(args.super_jobiph) != 2 or len(args.super_label) != 2:
        raise SystemExit("Exactly two independent supermolecule JOBIPH files are required")

    specifications: list[tuple[str, Path, str, int, int]] = []
    for label, path in zip(args.super_label, args.super_jobiph):
        specifications.append((f"super_{label}", path.resolve(), super_gateway(), 6, 2))
    for fragment, attempt, states, frozen in (
        ("carbon", args.carbon_cp_attempt.resolve(), ("cation", "neutral"), 1),
        ("water", args.water_cp_attempt.resolve(), ("neutral", "cation"), 1),
    ):
        source_input = attempt / "fragment.input"
        if not source_input.is_file():
            raise SystemExit(f"Missing fragment input: {source_input}")
        # Retain only GATEWAY/SEWARD.  Fragment inputs contain their original
        # RASSCF workflow after the first COPY directive; replaying it would
        # terminate before the new CASPT2 block.
        gateway = source_input.read_text().split(">>COPY", 1)[0].rstrip() + "\n"
        for state in states:
            jobiph = attempt / "scratch" / "fragment" / f"fragment_{state}.JobIph"
            nroots = 3 if fragment == "carbon" else 1
            specifications.append((f"{fragment}_{state}_cp", jobiph, gateway, nroots, frozen))

    root = args.output_root.resolve()
    tasks = []
    for index, (label, jobiph, gateway, nroots, frozen) in enumerate(specifications):
        if not jobiph.is_file():
            raise SystemExit(f"Missing JOBIPH: {jobiph}")
        task_root = root / f"{index:04d}_{label}"
        task_root.mkdir(parents=True, exist_ok=True)
        input_path = task_root / "caspt2.input"
        input_path.write_text(
            gateway + f"\n>>COPY {jobiph} JOBIPH\n" + caspt2_block(nroots, frozen)
        )
        tasks.append(
            {
                "index": index,
                "label": label,
                "task_root": str(task_root),
                "input_path": str(input_path),
                "input_sha256": sha256(input_path),
                "jobiph": str(jobiph),
                "jobiph_sha256": sha256(jobiph),
                "nroots": nroots,
                "frozen_core_orbitals": frozen,
                "accepted": False,
            }
        )
    payload = {
        "schema_version": 1,
        "method": "XMS-CASPT2 (single-state CASPT2 for one-root water fragments)",
        "ipea_shift_hartree": 0.25,
        "intruder_shift": "none; reject or diagnose any intruder warning",
        "basis": BASIS,
        "tasks": tasks,
        "production_eligible": False,
    }
    temporary = root / "manifest.json.next"
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, root / "manifest.json")
    print(root / "manifest.json")


if __name__ == "__main__":
    main()
