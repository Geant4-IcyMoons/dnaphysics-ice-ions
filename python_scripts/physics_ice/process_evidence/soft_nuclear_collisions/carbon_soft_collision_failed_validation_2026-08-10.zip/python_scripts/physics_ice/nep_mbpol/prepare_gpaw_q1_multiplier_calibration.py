#!/usr/bin/env python3
"""Prepare the five-task GPAW q=1 multiplier-calibration manifest."""

from __future__ import annotations
import argparse
from pathlib import Path
from soft_dft.gpaw_prepared_q1 import build_multiplier_calibration_manifest

parser = argparse.ArgumentParser()
parser.add_argument("--output-root", type=Path, required=True)
parser.add_argument("--reference-task-root", type=Path, required=True)
parser.add_argument("--retention-bundle", type=Path)
parser.add_argument("--gmf-anchor-result", type=Path)
args = parser.parse_args()
print(build_multiplier_calibration_manifest(
    args.output_root, args.reference_task_root, args.retention_bundle,
    args.gmf_anchor_result))
