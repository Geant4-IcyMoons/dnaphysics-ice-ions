#!/usr/bin/env python3
from argparse import ArgumentParser
from pathlib import Path
from soft_dft.gpaw_gmf_fixed_scan import build_manifest

parser = ArgumentParser()
parser.add_argument("--output-root", type=Path, required=True)
parser.add_argument("--retention-bundle", type=Path, required=True)
parser.add_argument("--carbon-fragment", type=Path, required=True)
parser.add_argument("--water-fragment", type=Path, required=True)
args = parser.parse_args()
print(build_manifest(args.output_root, args.retention_bundle,
                     args.carbon_fragment, args.water_fragment))
