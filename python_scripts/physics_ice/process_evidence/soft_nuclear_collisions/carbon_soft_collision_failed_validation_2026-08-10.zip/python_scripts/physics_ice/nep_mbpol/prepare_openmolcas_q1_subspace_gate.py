#!/usr/bin/env python3
"""Prepare a unitary-invariant six-state reproducibility gate."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import os
from pathlib import Path

from soft_dft.geometry import ORIENTATIONS, build_scan_geometry


BASIS = "ANO-RCC-VDZP"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--jobiph-a", type=Path, required=True)
    parser.add_argument("--jobiph-b", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--separation", type=float, required=True)
    parser.add_argument("--nroots", type=int, default=6)
    args = parser.parse_args()
    jobiphs = (args.jobiph_a.resolve(), args.jobiph_b.resolve())
    if not all(path.is_file() for path in jobiphs):
        raise SystemExit("Both accepted six-root JOBIPH files are required")
    orientation = next(item for item in ORIENTATIONS if item.name == "oxygen_back")
    geometry = build_scan_geometry(orientation, args.separation, "C")
    coordinates = "\n".join(
        f"    {element:2s} {x: .12f} {y: .12f} {z: .12f}"
        for element, x, y, z in geometry.coordinates_angstrom
    )
    root = args.output_root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    input_path = root / "subspace.input"
    if args.nroots < 1:
        raise SystemExit("--nroots must be positive")
    roots = " ".join(str(index) for index in range(1, args.nroots + 1))
    input_path.write_text(
        f"""* Six-state subspace and one-particle-density reproducibility gate.
&GATEWAY
  Title = q1 six state subspace gate at R {args.separation:.1f} Angstrom
  Coord = 4
    Angstrom
{coordinates}
  Basis = {BASIS}
  Group = C1
  NoCD

&SEWARD

>>COPY {jobiphs[0]} JOB001
>>COPY {jobiphs[1]} JOB002
&RASSI
  NROFJOBIPHS = 2 {args.nroots} {args.nroots}
    {roots}
    {roots}
  IPHNAMES
    JOB001
    JOB002
  TRD1
"""
    )
    manifest = {
        "schema_version": 1,
        "method": "RASSI six-state cross-overlap and one-particle transition-density gate",
        "separation_angstrom": args.separation,
        "nroots": args.nroots,
        "input_path": str(input_path),
        "input_sha256": sha256(input_path),
        "jobiphs": [str(path) for path in jobiphs],
        "jobiph_sha256": [sha256(path) for path in jobiphs],
        "output_root": str(root),
        "accepted": False,
        "production_eligible": False,
    }
    temporary = root / "manifest.json.next"
    temporary.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, root / "manifest.json")
    print(root / "manifest.json")


if __name__ == "__main__":
    main()
