#!/usr/bin/env python3
from argparse import ArgumentParser
from pathlib import Path
import sys

SCRIPT_DIRECTORY = Path(__file__).resolve().parent
if str(SCRIPT_DIRECTORY) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIRECTORY))

from soft_dft.gpaw_mom_retention import execute
p = ArgumentParser(); p.add_argument("--manifest", type=Path, required=True); p.add_argument("--task-index", type=int, required=True)
args = p.parse_args(); print(execute(args.manifest, args.task_index))
