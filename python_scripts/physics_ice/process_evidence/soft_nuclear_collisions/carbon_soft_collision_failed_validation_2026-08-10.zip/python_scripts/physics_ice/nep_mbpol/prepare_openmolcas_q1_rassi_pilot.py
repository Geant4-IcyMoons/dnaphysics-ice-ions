#!/usr/bin/env python3
"""Prepare nonorthogonal RASSI coupling pilots for q=1 C--H2O states."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import os
from pathlib import Path

from soft_dft.geometry import ORIENTATIONS, build_scan_geometry


REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
BASIS = "ANO-RCC-VDZP"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".next")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def render_input(separation: float, entrance: Path, transfer: Path) -> str:
    orientation = next(item for item in ORIENTATIONS if item.name == "oxygen_back")
    geometry = build_scan_geometry(orientation, separation, "C")
    coordinates = "\n".join(
        f"    {element:2s} {x: .12f} {y: .12f} {z: .12f}"
        for element, x, y, z in geometry.coordinates_angstrom
    )
    return f"""* Validation-only RASSI coupling of occupation-restricted GASSCF states.
&GATEWAY
  Title = C+--H2O RASSI pilot, R={separation:.1f} A
  Coord = 4
    Angstrom
{coordinates}
  Basis = {BASIS}
  Group = C1
  NoCD

&SEWARD

>>COPY {entrance} JOB001
>>COPY {transfer} JOB002
&RASSI
  NROFJOBIPHS = 2 3 1
    1 2 3
    1
  IPHNAMES
    JOB001
    JOB002
"""


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--gasscf-20-root", type=Path, required=True)
    parser.add_argument("--gasscf-20-job-id", required=True)
    parser.add_argument("--gasscf-12-root", type=Path, required=True)
    parser.add_argument("--gasscf-12-job-id", required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()

    tasks = []
    root = args.output_root.resolve()
    for index, (separation, source_root, job_id) in enumerate(
        (
            (20.0, args.gasscf_20_root.resolve(), args.gasscf_20_job_id),
            (12.0, args.gasscf_12_root.resolve(), args.gasscf_12_job_id),
        )
    ):
        entrance = (
            source_root / f"0004_entrance_manifold_r{int(separation)}A"
            / "attempts" / f"{job_id}[4].pbs02" / "scratch" / "pilot" / "pilot.JobIph"
        )
        transfer = (
            source_root / f"0003_transfer_lowest_r{int(separation)}A"
            / "attempts" / f"{job_id}[3].pbs02" / "scratch" / "pilot" / "pilot.JobIph"
        )
        if not entrance.is_file() or not transfer.is_file():
            raise SystemExit(f"Missing GASSCF state files at {separation:.0f} A")
        task_root = root / f"{index:04d}_rassi_r{int(separation)}A"
        task_root.mkdir(parents=True, exist_ok=True)
        input_path = task_root / "rassi.input"
        input_path.write_text(render_input(separation, entrance, transfer), encoding="utf-8")
        tasks.append(
            {
                "index": index,
                "separation_angstrom": separation,
                "task_root": str(task_root),
                "input_path": str(input_path),
                "input_sha256": sha256(input_path),
                "entrance_jobiph": str(entrance),
                "entrance_jobiph_sha256": sha256(entrance),
                "transfer_jobiph": str(transfer),
                "transfer_jobiph_sha256": sha256(transfer),
                "accepted_coupling": False,
            }
        )
    manifest = {
        "schema_version": 1,
        "method": "OpenMolcas RASSI over nonorthogonal occupation-restricted GASSCF states",
        "tasks": tasks,
        "production_eligible": False,
    }
    manifest_path = root / "manifest.json"
    atomic_json(manifest_path, manifest)
    print(manifest_path)


if __name__ == "__main__":
    main()
