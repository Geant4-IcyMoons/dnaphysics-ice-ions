#!/usr/bin/env python3
"""Execute one restart-safe GPAW cDFT manifest task under MPI."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from soft_dft.gpaw_cdft import execute_pilot_task  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--task-index", type=int, required=True)
    parser.add_argument(
        "--fresh",
        action="store_true",
        help="Ignore an exact-signature checkpoint and start from a fresh density.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    result = execute_pilot_task(
        args.manifest.resolve(), args.task_index, resume=not args.fresh
    )
    try:
        from gpaw.mpi import world
    except ImportError:
        world = None
    if world is None or world.rank == 0:
        print(
            json.dumps(
                {
                    "task_id": result["task_id"],
                    "numerical_gate_passed": result["numerical_gate_passed"],
                    "physical_state_status": result["physical_state_status"],
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
