#!/usr/bin/env python3
from argparse import ArgumentParser
from pathlib import Path
from soft_dft.gpaw_gmf_anchor import build_manifest
p = ArgumentParser(); p.add_argument("--output-root", type=Path, required=True); p.add_argument("--retention-bundle", type=Path, required=True)
a = p.parse_args(); print(build_manifest(a.output_root, a.retention_bundle))
