#!/usr/bin/env python3
"""Prepare a bounded XMS-CASPT2 shift matrix for validated fragment JOBIPH files."""

from __future__ import annotations

from argparse import ArgumentParser
import hashlib
import json
import os
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def caspt2_block(nroots: int, frozen: int, ipea: float, imaginary: float) -> str:
    roots = " ".join(str(index) for index in range(1, nroots + 1))
    multistate = f"  XMULTISTATE = {nroots} {roots}\n" if nroots > 1 else ""
    imaginary_line = f"  IMAGINARY = {imaginary:.6f}\n" if imaginary > 0.0 else ""
    return f"""&CASPT2
  Title = q1 VTZP fragment shift-sensitivity gate
  FROZEN = {frozen}
{multistate}  IPEA = {ipea:.6f}
{imaginary_line}  MAXITER = 100
  CONVERGENCE = 1.0d-9
"""


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("--carbon-cp-attempt", type=Path, required=True)
    parser.add_argument("--water-cp-attempt", type=Path, required=True)
    parser.add_argument("--basis", required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()

    fragments = (
        ("carbon", args.carbon_cp_attempt.resolve(), "cation", 3, 1),
        ("carbon", args.carbon_cp_attempt.resolve(), "neutral", 3, 1),
        ("water", args.water_cp_attempt.resolve(), "neutral", 1, 1),
        ("water", args.water_cp_attempt.resolve(), "cation", 1, 1),
    )
    settings = ((0.25, 0.0), (0.0, 0.0), (0.25, 0.1), (0.0, 0.1))
    root = args.output_root.resolve()
    tasks = []
    for fragment, attempt, state, nroots, frozen in fragments:
        source_input = attempt / "fragment.input"
        gateway = source_input.read_text().split(">>COPY", 1)[0].rstrip() + "\n"
        jobiph = attempt / "scratch" / "fragment" / f"fragment_{state}.JobIph"
        if not jobiph.is_file():
            raise SystemExit(f"Missing JOBIPH: {jobiph}")
        for ipea, imaginary in settings:
            index = len(tasks)
            label = (
                f"{fragment}_{state}_ipea{ipea:.2f}_imag{imaginary:.1f}"
                .replace(".", "p")
            )
            task_root = root / f"{index:04d}_{label}"
            task_root.mkdir(parents=True, exist_ok=True)
            input_path = task_root / "caspt2.input"
            input_path.write_text(
                gateway
                + f"\n>>COPY {jobiph} JOBIPH\n"
                + caspt2_block(nroots, frozen, ipea, imaginary)
            )
            tasks.append(
                {
                    "index": index,
                    "label": label,
                    "fragment": fragment,
                    "state": state,
                    "ipea_hartree": ipea,
                    "imaginary_shift_hartree": imaginary,
                    "task_root": str(task_root),
                    "input_path": str(input_path),
                    "input_sha256": sha256(input_path),
                    "jobiph": str(jobiph),
                    "jobiph_sha256": sha256(jobiph),
                    "nroots": nroots,
                    "frozen_core_orbitals": frozen,
                    "accepted": False,
                }
            )
    payload = {
        "schema_version": 1,
        "purpose": "fragment-only XMS-CASPT2 IPEA/imaginary-shift sensitivity",
        "basis": args.basis,
        "settings": [
            {"ipea_hartree": ipea, "imaginary_shift_hartree": imaginary}
            for ipea, imaginary in settings
        ],
        "tasks": tasks,
        "production_eligible": False,
    }
    temporary = root / "manifest.json.next"
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, root / "manifest.json")
    print(root / "manifest.json")


if __name__ == "__main__":
    main()
