#!/usr/bin/env python3
"""Run one constrained-first GPAW q=1 component collectively under MPI."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys


SCRIPT_DIRECTORY = Path(__file__).resolve().parent
if str(SCRIPT_DIRECTORY) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIRECTORY))

from soft_dft.gpaw_prepared_q1 import execute_task


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--task-index", type=int, required=True)
    args = parser.parse_args()
    result = execute_task(args.manifest, args.task_index)
    print(
        f"component={result['component']} "
        f"numerical_gate_passed={str(result['numerical_gate_passed']).lower()}"
    )


if __name__ == "__main__":
    main()
