"""PWBA projectile kernels."""
