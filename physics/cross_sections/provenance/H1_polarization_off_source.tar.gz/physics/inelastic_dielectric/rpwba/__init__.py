"""RPWBA projectile kernels."""
