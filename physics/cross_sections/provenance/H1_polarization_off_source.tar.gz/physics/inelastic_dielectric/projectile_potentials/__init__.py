"""projectile potentials package."""
