"""finite q package."""
