"""inelastic dielectric package."""
