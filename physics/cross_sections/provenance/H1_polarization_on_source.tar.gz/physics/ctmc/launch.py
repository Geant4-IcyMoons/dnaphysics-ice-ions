"""Load the sole immutable production engine for a signed campaign."""
import importlib.util
import sys
from pathlib import Path


def install(root):
    root=Path(root).resolve()
    path=root/'source/qualify.py'
    existing=sys.modules.get('qualify')
    if existing is not None:
        if Path(existing.__file__).resolve()!=path:
            raise ValueError('A process cannot mix production campaigns')
        engine=existing
    else:
        spec=importlib.util.spec_from_file_location('qualify',path)
        engine=importlib.util.module_from_spec(spec)
        sys.modules[spec.name]=engine
        spec.loader.exec_module(engine)
    engine.verify(root)
    engine.load_runtime(root/'source')
    return engine


if __name__ in ('__main__','__mp_main__'):
    if '--root' not in sys.argv:
        raise SystemExit('Supply --root for a prepared production campaign')
    Q=install(sys.argv[sys.argv.index('--root')+1])
    if __name__=='__main__':
        Q.main()
