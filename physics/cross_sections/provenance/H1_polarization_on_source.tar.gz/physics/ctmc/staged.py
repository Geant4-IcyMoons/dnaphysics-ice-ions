"""Finite CTMC pilot studies followed by independent production samples.

Published CTMC practice motivates short convergence studies and estimated
Monte Carlo errors. The 5% numerical comparison rule is a documented practical
choice, not a universal tolerance or a simultaneous confidence guarantee.
"""
import math

import numpy as np

WORKFLOW_NAME = "literature_pilot_production_v1"
STAGES = ("bmax", "flight", "solver", "production")


def validate_workflow(manifest):
    workflow = manifest["workflow"]
    if workflow.get("name") != WORKFLOW_NAME or workflow.get("phase") != "production":
        raise ValueError("Unknown CTMC production workflow")
    if not manifest["energies"] or len(set(manifest["energies"])) != len(manifest["energies"]):
        raise ValueError("A fixed, distinct energy grid is required")
    if manifest.get("initialization") != "projectile_ion_com_balanced":
        raise ValueError("This production workflow retains COM-balanced initialization")


def stages(manifest, adaptive_stages=None):
    validate_workflow(manifest)
    return STAGES


def experiment_alpha(manifest, stage):
    if stage not in STAGES:
        raise ValueError("Stage is not part of the finite production workflow")
    # Only zero-event limits use this conventional pointwise error probability.
    return 1 - manifest["policy"]["confidence"]


def zero_event_upper(n, support, alpha=.05):
    """Exact zero-count probability limit times a nonnegative packet support.

    For independent packets, the indicator of a nonzero outcome is Bernoulli
    even if the packet magnitude is weighted. Its zero-count upper probability
    is 1-alpha**(1/n). This is a fixed-sample, one-sided limit, not an anytime
    bound. Independence is between sampled packets, not electrons in a packet.
    """
    if n != int(n) or n < 1 or not 0 < alpha < 1 or not math.isfinite(support) or support < 0:
        raise ValueError("Invalid zero-event limit inputs")
    return support * -math.expm1(math.log(alpha) / n)


def _supports(q, manifest, exp):
    values = []
    for stratum in range(len(exp["targets"])):
        low, high = q.measurement_support(exp, stratum, manifest["nuclear_charge"])
        area = math.pi * (exp["edges"][stratum+1]**2 - exp["edges"][stratum]**2) * q.C.BOHR2_CM2
        values.append((low * area, high * area))
    return values


def zero_rate_limits(q, manifest, exp, stratum_means):
    """Report limits for entirely unobserved rates, never zero uncertainty."""
    arms = len(exp["arms"])
    means = np.asarray(stratum_means, dtype=float)
    supports = _supports(q, manifest, exp)
    result = [[None] * len(q.MEASURE_NAMES) for _ in range(arms)]
    alpha = experiment_alpha(manifest, exp["stage"])
    for arm in range(arms):
        for observable in range(len(q.MEASURE_NAMES)):
            active = [s for s, (_, high) in enumerate(supports) if high[arm, observable] > 0]
            if active and all(means[s, arm, observable] == 0 for s in active):
                # A small fixed allocation across independent strata bounds their
                # sum. No allocation across cases, observables or future looks.
                result[arm][observable] = sum(zero_event_upper(exp["targets"][s],
                    supports[s][1][arm, observable], alpha / len(active)) for s in active)
    return result


def tail_evidence(q, manifest, exp, stratum_means, variances, *, targets=None):
    """Report sampled outer-annulus contributions and sparse-tail diagnostics.

    The release test uses observed changes and ordinary standard errors after
    a predeclared outer-annulus sample count. Fixed-count zero-event formulas
    are reported as diagnostics, not imposed as an absolute omitted-tail gate.
    The comparison therefore establishes observed convergence, without claiming
    that the unmeasured tail is bounded by 5% with specified confidence.
    """
    if exp["stage"] != "bmax":
        return None
    if len(exp["arms"]) != 2 or stratum_means is None:
        raise ValueError("The cutoff pilot needs two arms and per-annulus moments")
    from scipy.special import ndtri
    samples = list(exp["targets"] if targets is None else targets)
    means = np.asarray(stratum_means, dtype=float)
    variances = np.asarray(variances, dtype=float)
    indices = q.production_indices(exp["charge"], manifest["nuclear_charge"])
    supports = _supports(q, manifest, exp)
    outer = [s for s in range(len(samples))
             if exp["edges"][s] >= exp["arms"][0]["bmax"]
             and exp["edges"][s+1] <= exp["arms"][1]["bmax"]]
    if not outer:
        raise ValueError("The cutoff pilot must sample an added annulus")
    alpha = experiment_alpha(manifest, "bmax")
    z = float(ndtri(1-alpha))
    baseline = means[:, 0, indices].sum(axis=0)
    tails, errors, upper, zero_limits = [], [], [], []
    for observable in indices:
        seen = [s for s in outer if means[s, 1, observable] > 0]
        empty = [s for s in outer if means[s, 1, observable] == 0 and supports[s][1][1, observable] > 0]
        value = float(sum(means[s, 1, observable] for s in outer))
        se = float(math.sqrt(max(0., sum(variances[s, 1, observable] for s in seen))))
        unseen = sum(zero_event_upper(samples[s], supports[s][1][1, observable], alpha / len(empty)) for s in empty)
        tails.append(value); errors.append(se); zero_limits.append(unseen)
        upper.append(value + z * se + unseen)
    limit = manifest["policy"]["numerical_relative"] * baseline
    enough = all(samples[s] >= manifest["policy"]["cutoff_tail_samples"] for s in outer)
    return dict(status="reported" if enough else "needs_samples", sample_requirement_met=enough,
        required_samples_per_outer_annulus=manifest["policy"]["cutoff_tail_samples"],
        baseline_mean=baseline.tolist(), tail_mean=tails, tail_standard_error=errors,
        tail_upper=upper, zero_event_upper=zero_limits, allowed_tail=limit.tolist(), samples=samples,
        observables=[q.MEASURE_NAMES[i] for i in indices], nominal_pointwise_confidence=1-alpha,
        method="observed_cutoff_convergence_with_reported_zero_event_limits_v1",
        scope="Finite tested annulus; observed differences and ordinary standard errors determine convergence after the declared sample count. Zero-count upper estimates are reported diagnostics, not release gates. No absolute omitted-tail, simultaneous, repeated-look or infinite-domain guarantee")


def _rounded_target(value, initial, maximum, block_size):
    if not math.isfinite(value) or value >= maximum:
        return maximum
    if value <= initial:
        return initial
    return min(maximum, block_size * math.ceil(value / block_size))


def sampling_allocation(q, manifest, exp, mean, variances, stratum_means=None, tail=None):
    """One fixed enlargement planned from pilot variance and measured cost.

    For each required estimator, Neyman allocation minimizes the estimated
    total cost for its desired variance. Taking the componentwise maximum of
    those allocations satisfies all estimated variance constraints. Rounded
    sample counts and explicit caps preserve the deterministic task ledger.
    An unobserved required rate receives the production floor, not an invented
    positive denominator or an unbounded rare-event search.
    """
    policy = manifest["policy"]
    arms = len(exp["arms"])
    indices = q.production_indices(exp["charge"], manifest["nuclear_charge"])
    n = np.asarray(exp["targets"], dtype=float)
    maximum = policy["production_max_samples"] if arms == 1 else policy["max_samples_per_annulus"]
    progressive = maximum is None
    maximum = math.inf if progressive else int(maximum)
    initial = int(policy["initial_samples"])
    minimum = initial
    if arms == 1:
        minimum = int(policy["production_min_samples"])
        minimum = min(maximum, max(initial, minimum))
    targets = np.maximum(n, minimum)
    tolerance = policy["statistical_relative" if arms == 1 else "numerical_relative"]
    scale = np.asarray(mean)[0, indices]
    observed_scale = np.max(np.asarray(mean)[:arms, indices], axis=0)
    if arms > 1:
        scale = np.minimum(scale, np.asarray(mean)[1, indices])
        # A rare event in only one arm still supplies a planning scale. Using
        # the positive observed arm avoids terminating before the one permitted
        # enlargement; numerical acceptance continues to use the smaller arm.
        scale = np.where(scale > 0, scale, observed_scale)
    stream = 0 if arms == 1 else arms
    seconds = exp.get("_seconds_per_sample")
    calibrated = (seconds is not None and len(seconds) == len(n)
        and all(v is not None and math.isfinite(v) and v > 0 for v in seconds))
    costs = np.asarray(seconds if calibrated else
        [max(1, q.task_cost(manifest, exp, s, 1)) for s in range(len(n))])
    raw_variance = np.asarray(variances) * n[:, None, None]
    followup = exp.get("production_followup")
    if followup:
        raw_variance = raw_variance.copy()
        scale = scale.copy()
        for position, observable in enumerate(indices):
            if q.MEASURE_NAMES[observable] not in followup["observables"] or observed_scale[position] > 0: continue
            scale[position] = followup["mean"][observable]
            # Equal-marginal, independent-arm variance is a planning proxy until
            # the paired study observes events. It never enters its error bars.
            prior = np.asarray(followup["raw_variances"])
            raw_variance[:len(prior), stream, observable] = 2*prior[:,0,observable]
    for observable, reference in zip(indices, scale):
        if reference <= 0:
            continue
        normalized = raw_variance[:, stream, observable] / (tolerance * reference)**2
        optimal = np.sqrt(normalized / costs) * np.sum(np.sqrt(normalized * costs))
        targets = np.maximum(targets, optimal)
    maxima = np.full(len(n), maximum)
    if exp["stage"] == "bmax":
        tail_samples = int(policy["cutoff_tail_samples"])
        for stratum in range(len(n)):
            if exp["edges"][stratum] >= exp["arms"][0]["bmax"]:
                targets[stratum] = max(targets[stratum], tail_samples)
                maxima[stratum] = max(maximum, tail_samples)
    if progressive:
        # A fixed reference prevents the fallback threshold from moving at each look.
        reference = np.asarray(exp.get("reference_targets", exp["targets"]), dtype=float)
        projected_multiplier = float(np.sum(targets) / np.sum(reference))
        effective = tolerance if projected_multiplier <= policy["fallback_multiplier"] else policy["fallback_relative"]
        if effective > tolerance:
            targets = np.maximum(n, targets * (tolerance/effective)**2)
        # Never freeze an entire huge estimate into the task ledger. Retain at
        # least the production floor when designing a fresh independent cohort.
        cap = np.maximum(n + policy["block_size"], np.ceil(n*(1+policy["batch_growth"])))
        if arms == 1: cap = np.maximum(cap, minimum)
        targets = np.minimum(np.maximum(targets, minimum), cap)
        if exp["stage"] == "bmax":
            for st in range(len(n)):
                if exp["edges"][st] >= exp["arms"][0]["bmax"]:
                    targets[st] = max(targets[st], policy["cutoff_tail_samples"])
        # An inconclusive contrast still needs information even when a plug-in
        # variance target is met, or a required production rate is unobserved.
        targets = np.maximum(targets, n)
        if np.all(targets <= n): targets = np.maximum(n+policy["block_size"], np.ceil(n*(1+policy["batch_growth"])))
        planned = [int(policy["block_size"] * math.ceil(v/policy["block_size"])) for v in targets]
        return None, dict(planned_targets=planned, mode="progressive_variance_batches",
            reference_targets=reference.astype(int).tolist(), projected_five_percent_multiplier=projected_multiplier,
            effective_statistical_relative=effective, cost_unit="measured_cpu_seconds" if calibrated else "electron_collisions",
            unobserved_required_rates=[q.MEASURE_NAMES[i] for i,v in zip(indices,observed_scale) if v<=0],
            scope="Repeated variance-guided batches; estimated errors at data-dependent stopping, no nominal repeated-look confidence guarantee")
    planned = [_rounded_target(value, initial, int(cap), int(policy["block_size"]))
               for value, cap in zip(targets, maxima)]
    return None, dict(planned_targets=planned,
        mode="single_fixed_variance_plan", cost_unit="measured_cpu_seconds" if calibrated else "electron_collisions",
        unobserved_required_rates=[q.MEASURE_NAMES[i] for i, value in zip(indices, observed_scale) if value <= 0],
        scope="One pilot-based sample plan with declared limits. Observed final errors are reported; the plan is not a precision guarantee")


def capture_discordance_guard(q, manifest, exp, stratum_means, stratum_nonzero):
    """Exact paired Bernoulli evidence before a capture-driven refinement.

    SC and TI are mutually exclusive, so their sum is binary. Conditional on
    each stratum's discordant count, equal marginal probabilities imply fair
    discordant directions (exact McNemar/binomial test). A Bonferroni adjustment
    across all sampled strata requires evidence in at least one stratum. This
    supplements, rather than replaces, the weighted overall change criterion.
    These fixed-look diagnostics are not sequential confidence guarantees.
    """
    if stratum_nonzero is None or len(exp['arms']) != 2:
        return None
    from scipy.stats import binomtest
    counts=np.asarray(stratum_nonzero)
    if counts.shape != np.asarray(stratum_means).shape:
        raise ValueError('Invalid discordance count dimensions')
    rows=[]
    for st,n in enumerate(exp['targets']):
        area=math.pi*(exp['edges'][st+1]**2-exp['edges'][st]**2)*q.C.BOHR2_CM2
        discordant=int(counts[st,2,7])
        net=float(stratum_means[st][2][7])/area*n
        signed=int(round(net))
        if (discordant != counts[st,2,7] or not 0<=discordant<=n
            or abs(net-signed)>1e-6 or abs(signed)>discordant or (discordant+signed)%2):
            raise ValueError('Capture moments disagree with binary paired counts')
        positive=(discordant+signed)//2
        pv=float(binomtest(positive,discordant,.5).pvalue) if discordant else 1.
        rows.append(dict(stratum=st,positive=positive,negative=discordant-positive,pvalue=pv))
    adjusted=min(1.,len(rows)*min(x['pvalue'] for x in rows))
    return dict(strata=rows,adjusted_pvalue=adjusted,
        supports_refinement=adjusted < 1-manifest['policy']['confidence'],
        scope='Exact paired Bernoulli tests, Bonferroni across sampled strata; additional rejection guard only, no adaptive coverage or convergence certificate')


def assess_moments(q, manifest, exp, mean, variances, covariances, *, stratum_means=None, stratum_nonzero=None):
    """Assess a numerical pilot or independent fixed-size production cohort."""
    validate_workflow(manifest)
    arms = len(exp["arms"])
    if arms != (1 if exp["stage"] == "production" else 2):
        raise ValueError("Production has one arm; each numerical pilot has two")
    mean = np.asarray(mean, dtype=float)
    variances = np.asarray(variances, dtype=float)
    if (stratum_means is None or mean.shape != (2*arms-1, len(q.MEASURE_NAMES))
        or variances.shape != (len(exp["targets"]), *mean.shape)
        or not np.isfinite(mean).all() or not np.isfinite(variances).all() or np.any(variances < 0)
        or np.any(mean[:arms] < 0) or np.asarray(stratum_means).shape != variances.shape
        or not np.isfinite(stratum_means).all() or np.any(np.asarray(stratum_means)[:, :arms] < 0)):
        raise ValueError("Invalid stratified CTMC moments")
    variance = variances.sum(axis=0)
    error = np.sqrt(variance)
    indices = q.production_indices(exp["charge"], manifest["nuclear_charge"])
    selected, allocation = sampling_allocation(q, manifest, exp, mean, variances, stratum_means)
    progressive = manifest["policy"]["max_samples_per_annulus"] is None
    statistical_tol = allocation.get("effective_statistical_relative", manifest["policy"]["statistical_relative"])
    tol = manifest["policy"]["numerical_relative"]
    changes, noise = np.abs(mean[arms:]), error[arms:]
    scale = np.minimum(mean[0, indices], mean[1, indices]) if arms > 1 else mean[0, indices]
    precision = (mean[0, indices] > 0) & (error[0, indices] <= statistical_tol * mean[0, indices])
    tail = tail_evidence(q, manifest, exp, stratum_means, variances)
    numerical_status = {}
    capture_guard = None
    numerical_qualification = None
    if arms > 1:
        unobserved = (mean[0, indices] == 0) & (mean[1, indices] == 0)
        stable = (scale > 0) & (changes[0, indices] <= tol*scale) & (noise[0, indices] <= (statistical_tol if progressive else tol)*scale)
        changed = changes[0, indices] > tol*scale + 2*noise[0, indices]
        if 7 in indices and changed[list(indices).index(7)]:
            capture_guard=capture_discordance_guard(q,manifest,exp,stratum_means,stratum_nonzero)
            if capture_guard is not None:
                changed[list(indices).index(7)] &= capture_guard['supports_refinement']
        for i, empty, good, bad in zip(indices, unobserved, stable, changed):
            numerical_status[q.MEASURE_NAMES[i]] = ("unobserved_rate" if empty else
                "pass" if good else "resolved_change" if bad else "unresolved_comparison")
        # An unobserved rate may proceed to fresh production with an explicit
        # numerical limitation. It never acquires a convergence certificate.
        must_observe = np.array([q.MEASURE_NAMES[i] in exp.get("production_followup",{}).get("observables",[]) for i in indices])
        passed = bool(np.all(stable | (unobserved & ~must_observe)))
        rejected = bool(np.any(changed))
        numerical_qualification = bool(np.all(stable))
        if tail is not None:
            passed = passed and tail["sample_requirement_met"]
            numerical_qualification = numerical_qualification and tail["sample_requirement_met"]
    else:
        if "planned_targets" not in exp:
            raise ValueError("Production requires a sample plan frozen from the independent solver pilot")
        passed = False
        rejected = False
    planned = exp.get("planned_targets")
    if planned is not None and list(exp["targets"]) != list(planned):
        raise ValueError("Final sample cohort differs from its saved plan")
    if arms == 1 and planned is not None:
        status = "needs_samples" if progressive and not np.all(precision) else "production_complete"
    elif passed:
        status = "pass"
    elif rejected:
        status = "resolved_change"
    elif not progressive and (planned is not None or allocation["planned_targets"] == list(exp["targets"])):
        status = "sampling_limit"
    else:
        status = "needs_samples"
    covariance = np.zeros((arms, 2, 2))
    covariance[:, 0, 0] = variance[:arms, 6]
    covariance[:, 1, 1] = variance[:arms, 7]
    covariance[:, 0, 1] = covariance[:, 1, 0] = np.sum(covariances, axis=0)
    report = dict(status=status, effective_statistical_relative=statistical_tol, mean=mean[:arms].tolist(),
        lower=np.maximum(0., mean[:arms]-error[:arms]).tolist(), upper=(mean[:arms]+error[:arms]).tolist(),
        standard_error=error[:arms].tolist(), rate_covariance=covariance.tolist(),
        pair_change_upper=changes.tolist(), pair_change_lower=changes.tolist(), pair_standard_error=noise.tolist(),
        change_upper=changes.sum(axis=0).tolist(), change_lower=changes.sum(axis=0).tolist(),
        next_stratum=selected, allocation=allocation, planned_targets=allocation["planned_targets"] if planned is None else planned,
        samples=list(exp["targets"]), measurement_names=list(q.MEASURE_NAMES),
        precision_met=bool(np.all(precision)), precision_by_observable={q.MEASURE_NAMES[i]: bool(ok) for i, ok in zip(indices, precision)},
        zero_upper_limit=zero_rate_limits(q, manifest, exp, stratum_means),
        zero_upper_limit_scope=("Data-dependent sampling: conventional zero-count diagnostics, no nominal confidence coverage at stopping" if progressive else "Fixed-sample one-sided limits conditional on the independent production plan; each rate separately" if arms == 1 else
            "Conventional zero-count formula; final pilot size depends on initial data, so nominal fixed-size coverage is not asserted there"),
        confidence_scope="Estimated Monte Carlo standard errors. Numerical pilots compare measured changes and paired errors; no simultaneous or repeated-look coverage is claimed")
    if arms == 1:
        report["stratum_means"] = np.asarray(stratum_means).tolist()
        report["stratum_raw_variances"] = (variances*np.asarray(exp["targets"])[:,None,None]).tolist()
    if arms > 1:
        report.update(numerical_status_by_observable=numerical_status,
            numerical_qualification_met=numerical_qualification,
            unresolved_observables=[name for name, state in numerical_status.items() if state != "pass"],
            numerical_scope="Observed convergence of resolved rates at the tested settings. Both-arm unobserved rates may proceed to production but remain numerically unqualified")
    if capture_guard is not None:
        report["capture_discordance_guard"] = capture_guard
    if tail is not None:
        report["tail_evidence"] = tail
    if exp["stage"] == "solver":
        production = dict(exp, stage="production", arms=exp["arms"][:1])
        _, design = sampling_allocation(q, manifest, production, mean[:1],
            variances[:, :1], np.asarray(stratum_means)[:, :1])
        report["production_targets"] = design["planned_targets"]
    return report


def equilibrium_fractions(increase, decrease):
    """Stationary birth/death fractions evaluated as normalized log products."""
    increase, decrease = np.asarray(increase, dtype=float), np.asarray(decrease, dtype=float)
    if (increase.ndim != 1 or increase.shape != decrease.shape
        or not np.isfinite(increase).all() or not np.isfinite(decrease).all()
        or np.any(increase <= 0) or np.any(decrease <= 0)):
        raise ValueError("Equilibrium requires positive finite adjacent rates")
    logs = np.r_[0., np.cumsum(np.log(increase) - np.log(decrease))]
    weights = np.exp(logs - np.max(logs))
    return weights / weights.sum()


def fraction_statistics(f, rates, covariances):
    """First-order propagated errors retaining up/down packet covariance."""
    f = np.asarray(f); rates = np.asarray(rates); n = len(f)
    gradient = np.zeros((n, n, 2))
    for j in range(n-1):
        contrast = (np.arange(n) > j) - sum(f[j+1:])
        gradient[:, j, 0] = f * contrast / rates[j, 0]
        gradient[:, j+1, 1] = -f * contrast / rates[j+1, 1]
    covariance = np.einsum("iqk,qkl,jql->ij", gradient, np.asarray(covariances), gradient)
    error = np.sqrt(np.maximum(0., np.diag(covariance))); charges = np.arange(n)
    return dict(mean=f.tolist(), standard_error=error.tolist(), covariance=covariance.tolist(),
        mean_charge=float(charges @ f), mean_charge_standard_error=float(np.sqrt(max(0., charges @ covariance @ charges))),
        total_variation_error_scale=float(.5 * sum(error)),
        scope="First-order delta-method estimated errors; unreliable for poorly resolved rates and not a confidence bound or release gate")


def assess_fractions(q, db, manifest, energies):
    fractions = {}
    for energy in energies:
        cases = [q.get(db, "cases", q.case_key(energy, j)) for j in range(manifest["nuclear_charge"]+1)]
        if any(not c.get("certificate") for c in cases):
            continue
        rates = np.array([c["certificate"]["mean"][6:] for c in cases])
        if np.any(rates[:-1, 0] <= 0) or np.any(rates[1:, 1] <= 0):
            fractions[float(energy).hex()] = dict(status="unresolved_rates", mean=None,
                reason="At least one necessary rate is unobserved; zero-rate substitution cannot establish equilibrium")
            continue
        f = equilibrium_fractions(rates[:-1, 0], rates[1:, 1])
        result = fraction_statistics(f, rates, [c["certificate"]["rate_covariance"] for c in cases])
        result["precision_met"] = all(c["certificate"].get("precision_met", False) for c in cases)
        result["numerical_qualification_met"] = all(c["certificate"].get("numerical_qualification_met", False) for c in cases)
        result["status"] = "pass" if result["precision_met"] and result["numerical_qualification_met"] else "estimated_with_limits"
        fractions[float(energy).hex()] = result
    q.put(db, "meta", "fractions", fractions)






