"""Restart-safe COM CTMC: focused convergence trials and fixed-sample production."""
from __future__ import annotations

import argparse
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from contextlib import contextmanager
from dataclasses import asdict, dataclass, replace
import fcntl
import hashlib
import importlib
import importlib.util
import json
import math
import multiprocessing
import os
from pathlib import Path
import shlex
import shutil
import signal
import sqlite3
import subprocess
import sys
import time
import zlib

for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
              "NUMBA_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_name] = "1"
import numpy as np
from tqdm import tqdm

SCHEMA = 4
NAMES = ("SC", "TI", "SL", "LI", "SI", "DI")
# These are bounds on shell-local IEVM weights, not normalized probabilities.
RANGES = np.array([1., 1., 1., 5., 5., 5.])
PRODUCTION_NAMES = ("increase", "decrease")
MEASURE_NAMES = NAMES + PRODUCTION_NAMES
MEASURE_RANGES = np.array([1., 1., 1., 5., 5., 5., 6., 1.])
AXES = ("bmax", "flight", "solver")
STAGES = (*AXES, "production")
RUNTIME_FILES = ("charge_exchange_ctmc.py", "ctmc_numba_backend.py", "constants.py")
C = None
_STOP = False
_CANCEL_FLAGS = None
_CANCEL_SLOT = None
EXECUTION_REVISION = None
CONTINUATION_REVISION = None
ASSESSMENT_REVISION = "literature_capture_guard_v5"
TERMINAL_CASE_STATES = ("numerical_limit", "sampling_limit", "budget_exhausted",
    "execution_error", "initialization_failure")
RUNTIME = dict(control_interval=1., status_interval=10., orphan_interval=15.,
               pool_recoveries=3, max_audits_per_shard=4,
               control_cooldown_factor=4., audit_read_batch=256,
               integration_segment_steps=100000, packet_seconds=60.)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    try:
        with tmp.open("w") as stream:
            stream.write(canonical(value) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


@dataclass(frozen=True)
class Controls:
    bmax: float
    incoming: float
    outgoing: float
    minimum_time: float
    radial: int
    rtol: float
    atol: float
    minimum_radius: float
    energy_drift: float
    maximum_steps: int

    def __post_init__(self):
        if any(not math.isfinite(v) or v <= 0 for v in asdict(self).values()):
            raise ValueError("Controls must be finite and positive")
        if self.radial != int(self.radial) or self.radial < 128 or self.maximum_steps != int(self.maximum_steps):
            raise ValueError("Invalid radial resolution or integration budget")
        if self.rtol / 10 < 128*np.finfo(float).eps or max(self.energy_drift,self.rtol,self.atol) >= 1:
            raise ValueError("Invalid integration tolerance")

    def refined(self, axis, steps=1):
        value = self
        for _ in range(steps):
            if axis == 'bmax':
                value = replace(value, bmax=value.bmax*2)
            elif axis == 'flight':
                value = replace(value, incoming=value.incoming*2, outgoing=value.outgoing*2,
                                minimum_time=value.minimum_time*2)
            elif axis == 'solver':
                value = replace(value, rtol=value.rtol/10, atol=value.atol/10,
                                radial=value.radial*2, minimum_radius=value.minimum_radius/10)
            else:
                raise ValueError(f'Unknown numerical check {axis}')
        return value


@dataclass(frozen=True)
class Policy:
    confidence: float = .95  # Fixed-look diagnostic confidence, not simultaneous coverage.
    numerical_relative: float = .05
    statistical_relative: float = .05
    initial_samples: int = 512
    block_size: int = 1
    max_samples_per_annulus: int | None = 4096
    cutoff_tail_samples: int = 10000
    production_min_samples: int = 2048
    production_max_samples: int | None = 16384
    max_axis_levels: int = 3
    max_trajectories: int | None = 250000000
    batch_growth: float = .20
    fallback_relative: float = .10
    fallback_multiplier: float = 11.
    basis: str = "Small convergence trials followed by independent fixed-sample production; 5% estimated Monte Carlo standard-error target, no simultaneous confidence or physical-error guarantee."

    def __post_init__(self):
        if not 0 < self.confidence < 1: raise ValueError('Invalid pointwise confidence')
        if not 0 < self.numerical_relative < 1 or not 0 < self.statistical_relative < 1:
            raise ValueError('Invalid accuracy target')
        for k in ('initial_samples','block_size','max_samples_per_annulus','production_min_samples',
                  'production_max_samples','max_axis_levels','max_trajectories','cutoff_tail_samples'):
            v=getattr(self,k)
            if v is None and k in ('max_samples_per_annulus','production_max_samples','max_trajectories'): continue
            if isinstance(v,bool) or v != int(v) or v < (0 if k=='max_axis_levels' else 1):
                raise ValueError(f'Invalid budget {k}')
        if self.initial_samples < 2 or (self.max_samples_per_annulus is not None and self.max_samples_per_annulus < self.initial_samples):
            raise ValueError('Invalid pilot sample bounds')
        if self.production_min_samples < 2 or (self.production_max_samples is not None and self.production_max_samples < self.production_min_samples):
            raise ValueError('Invalid production sample bounds')
        if not (0 < self.batch_growth <= 1 and self.statistical_relative <= self.fallback_relative < 1 and self.fallback_multiplier > 1):
            raise ValueError("Invalid progressive sampling policy")
        if any(v % self.block_size for v in (self.initial_samples,self.max_samples_per_annulus,
                self.production_min_samples,self.production_max_samples,self.cutoff_tail_samples) if v is not None) or not self.basis.strip():
            raise ValueError('Sample budgets must be block aligned and documented')


def load_runtime(directory):
    """Load one immutable kernel and its deterministic continuation in each process."""
    global C, EXECUTION_REVISION, CONTINUATION_REVISION
    directory=Path(directory).resolve()
    if C is not None:
        if Path(C.__file__).resolve().parent != directory:
            raise ValueError('A process cannot mix CTMC source snapshots')
        return C
    for name in ('constants','charge_exchange_ctmc','ctmc_numba_backend'):
        existing=sys.modules.get(name)
        if existing is not None and Path(existing.__file__).resolve().parent != directory:
            raise ValueError(f'Conflicting preloaded module: {name}')
    sys.path.insert(0,str(directory))
    C=importlib.import_module('charge_exchange_ctmc')
    path=Path(__file__).with_name('continuation.py')
    spec=importlib.util.spec_from_file_location('ctmc_continuation_'+file_hash(path)[:12],path)
    continuation=importlib.util.module_from_spec(spec);spec.loader.exec_module(continuation)
    import functools
    C.simulate_one_trajectory_segment=functools.partial(continuation.simulate_one_trajectory_segment,
                                                     C,cancel_check=check_cancelled)
    C.warm_native_backend=functools.partial(continuation.warm_native_backend,C)
    CONTINUATION_REVISION=digest({**{name:file_hash(directory/name) for name in RUNTIME_FILES},'continuation.py':file_hash(path)})
    EXECUTION_REVISION=digest(dict(driver=file_hash(__file__),continuation=CONTINUATION_REVISION))
    return C


def prepare_native_runtime(root, manifest):
    """Serialize cache compilation across allocations before starting workers."""
    if "PBS_JOBID" not in os.environ:
        raise RuntimeError("Native runtime preparation requires a PBS allocation")
    C.select_projectile(manifest["projectile"])
    with (Path(root)/"native_cache.lock").open("a+") as lock:
        fcntl.lockf(lock,fcntl.LOCK_EX)
        return C.warm_native_backend()


def verify(root):
    root = Path(root)
    manifest = json.loads((root / "manifest.json").read_text())
    if manifest["schema"] != SCHEMA or digest({k: v for k, v in manifest.items() if k != "signature"}) != manifest["signature"]:
        raise ValueError("Invalid campaign signature")
    for name, expected in manifest["sources"].items():
        if file_hash(root / "source" / name) != expected:
            raise ValueError(f"Changed frozen dependency: {name}")
    if file_hash(__file__) != manifest["sources"]["qualify.py"]:
        raise ValueError("Use this campaign's frozen source/qualify.py to resume")
    versions = {name: importlib.import_module(name).__version__ for name in manifest["software"]}
    if versions != manifest["software"] or sys.version != manifest["python"]:
        raise ValueError("Python/scientific-package versions changed; resume refused")
    return manifest


@contextmanager
def database(root, *, blocking=True):
    # DELETE journal plus an external lock: no SQLite WAL on the shared filesystem.
    with (Path(root) / "database.lock").open("a+") as lock:
        fcntl.lockf(lock, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        db = sqlite3.connect(Path(root) / "campaign.sqlite", timeout=60)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA synchronous=FULL")
        try:
            with db:
                yield db
        finally:
            db.close()


def put(db, table, identity, value):
    db.execute(f"INSERT INTO {table}(id,payload) VALUES (?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload WHERE payload!=excluded.payload", (identity, canonical(value)))


def get(db, table, identity):
    row = db.execute(f"SELECT payload FROM {table} WHERE id=?", (identity,)).fetchone()
    return None if row is None else json.loads(row[0])


def initialize_runtime(db):
    """Indexed work queues and incrementally maintained trajectory counters."""
    statements = (
        "CREATE INDEX IF NOT EXISTS tasks_failed ON tasks(experiment) WHERE state='failed'",
        "CREATE INDEX IF NOT EXISTS tasks_owners ON tasks(owner) WHERE state='running'",
        "CREATE INDEX IF NOT EXISTS tasks_pending_experiment ON tasks(experiment) WHERE state='ready'",
        "CREATE INDEX IF NOT EXISTS tasks_ready_experiment ON tasks(experiment,start,stratum) WHERE state='ready'",
        "CREATE INDEX IF NOT EXISTS tasks_ready_resume ON tasks(resuming,start,experiment,stratum) WHERE state='ready'",
        "CREATE TABLE IF NOT EXISTS task_progress(task TEXT PRIMARY KEY,experiment TEXT NOT NULL,started REAL NOT NULL,updated REAL NOT NULL,segments INTEGER NOT NULL DEFAULT 0,seconds REAL NOT NULL DEFAULT 0,payload TEXT)",
        "CREATE INDEX IF NOT EXISTS task_progress_experiment ON task_progress(experiment)",
        "CREATE TABLE IF NOT EXISTS audits(id TEXT PRIMARY KEY,experiment TEXT,targets TEXT,state TEXT,owner TEXT,result BLOB)",
        "CREATE INDEX IF NOT EXISTS audits_work ON audits(state,id)",
        "CREATE TABLE IF NOT EXISTS task_counts(stage TEXT,state TEXT,n INTEGER,cost INTEGER,PRIMARY KEY(stage,state))")
    for statement in statements: db.execute(statement)
    if 'resume_updated' not in {row[1] for row in db.execute('PRAGMA table_info(tasks)')}:
        db.execute('ALTER TABLE tasks ADD COLUMN resume_updated REAL')
    if not db.execute("SELECT 1 FROM sqlite_master WHERE type='index' AND name='tasks_ready_resume_updated'").fetchone():
        # Persist the existing checkpoint order, including interrupted work
        # that may later be reclaimed. No task or trajectory identity changes.
        db.execute('UPDATE tasks SET resume_updated=(SELECT updated FROM task_progress WHERE task=tasks.id) WHERE EXISTS(SELECT 1 FROM task_progress WHERE task=tasks.id)')
        db.execute("CREATE INDEX tasks_ready_resume_updated ON tasks(resume_updated,id) WHERE state='ready' AND resuming=1 AND resume_updated IS NOT NULL")
    # This indexed cache follows the timing ledger in the same transaction.
    # It also stays valid when a cancelled or orphaned task becomes ready.
    for name, event, assignment, identity in (
        ('insert', 'INSERT', 'NEW.updated', 'NEW.task'),
        ('update', 'UPDATE OF updated', 'NEW.updated', 'NEW.task'),
        ('delete', 'DELETE', 'NULL', 'OLD.task'),
    ):
        db.execute(f'CREATE TRIGGER IF NOT EXISTS task_progress_resume_{name} AFTER {event} ON task_progress BEGIN UPDATE tasks SET resume_updated={assignment} WHERE id={identity}; END')
    if db.execute("SELECT 1 FROM sqlite_master WHERE type='trigger' AND name='count_task_insert'").fetchone():
        return
    for operation in ('INSERT','DELETE','UPDATE OF state,cost,experiment'):
        name=operation.split()[0].lower(); statements=[]
        if name!='insert':
            statements.append("UPDATE task_counts SET n=n-1,cost=cost-OLD.cost WHERE stage=(SELECT json_extract(payload,'$.stage') FROM experiments WHERE id=OLD.experiment) AND state=OLD.state;")
        if name!='delete':
            statements.append("INSERT INTO task_counts VALUES((SELECT json_extract(payload,'$.stage') FROM experiments WHERE id=NEW.experiment),NEW.state,1,NEW.cost) ON CONFLICT(stage,state) DO UPDATE SET n=n+1,cost=cost+NEW.cost;")
        db.execute(f"CREATE TRIGGER count_task_{name} AFTER {operation} ON tasks BEGIN {' '.join(statements)} END")


def staged_workflow(manifest):
    """Optional workflow code is frozen and hashed with the shared engine."""
    if "workflow" not in manifest:
        return None
    path = Path(__file__).with_name("staged.py")
    name = "ctmc_staged_" + file_hash(path)[:16]
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name]


def case_key(energy, charge):
    return f"{float(energy).hex()}:{charge}"


def starting_controls(manifest, energy):
    controls=dict(manifest['controls'])
    if manifest.get('energy_scaled_flight',True):
        # Tested starting proposals within the published launch-distance range.
        flight=10000. if energy <= 25. else 1000.
        controls.update(incoming=flight,outgoing=flight,minimum_time=flight)
    return controls


def add_energy(db, manifest, energy):
    for charge in range(manifest['nuclear_charge']+1):
        key=case_key(energy,charge)
        if get(db,'cases',key) is None:
            put(db,'cases',key,dict(energy=float(energy),charge=charge,
                controls=starting_controls(manifest,energy),levels={a:0 for a in AXES},
                experiments={},status='pending',preflight=None))


def prepare(root, runtime, projectile, energies, controls, policy, seed, *, execution_check=False, workflow=None, energy_scaled_flight=True):
    root,runtime=Path(root).resolve(),Path(runtime).resolve()
    if root.exists(): raise ValueError('Campaign exists; resume instead')
    energies=sorted(float(e) for e in energies)
    if not energies or len(set(energies))!=len(energies) or any(not math.isfinite(e) or e<=0 for e in energies):
        raise ValueError('Invalid fixed energy grid')
    if seed < 0 or seed != int(seed): raise ValueError('Invalid random seed')
    kernel=load_runtime(runtime)
    spec=kernel.select_projectile(projectile)
    if len(kernel.WATER_ORBITALS)!=5 or any(o.active_electrons!=2 for o in kernel.WATER_ORBITALS):
        raise ValueError('Estimator requires five two-electron water orbitals')
    inputs={name:runtime/name for name in RUNTIME_FILES}
    inputs.update({name:Path(__file__).with_name(name) for name in ('qualify.py','staged.py','continuation.py','progress.py','launch.py','supervise.py')})
    hashes={name:file_hash(path) for name,path in inputs.items()}
    manifest=dict(schema=SCHEMA,projectile=spec.key,nuclear_charge=spec.nuclear_charge,
        purpose='execution_check' if execution_check else 'production',energies=energies,
        controls=asdict(controls),energy_scaled_flight=energy_scaled_flight,policy=asdict(policy),seed=seed,
        sources=hashes,source_origin=str(runtime),python=sys.version,
        software={name:importlib.import_module(name).__version__ for name in ('numpy','scipy','numba','tqdm')},
        initialization='projectile_ion_com_balanced',ensemble='independent_isotropic_sensitivity',
        estimator='Independent-electron IEVM/IPM packets at common area-stratified impact parameter',
        workflow=workflow or dict(name='literature_pilot_production_v1',phase='production'),
        acceptance='Focused convergence trials, then independent fixed-sample production; standard errors and unresolved limits reported. No campaign-wide confidence or physical-model guarantee.')
    staged_workflow(manifest).validate_workflow(manifest)
    manifest['signature']=digest(manifest)
    (root/'source').mkdir(parents=True)
    for name,path in inputs.items():
        shutil.copy2(path,root/'source'/name)
        if file_hash(root/'source'/name)!=hashes[name]: raise ValueError('Source changed during snapshot')
    with database(root) as db:
        for table in ('cases','experiments','meta'):
            db.execute(f'CREATE TABLE {table}(id TEXT PRIMARY KEY,payload TEXT NOT NULL)')
        db.execute("CREATE TABLE tasks(id TEXT PRIMARY KEY,experiment TEXT NOT NULL,stratum INTEGER NOT NULL,start INTEGER NOT NULL,count INTEGER NOT NULL,cost INTEGER NOT NULL,state TEXT NOT NULL,owner TEXT,result BLOB,resuming INTEGER NOT NULL DEFAULT 0)")
        db.execute('CREATE INDEX tasks_work ON tasks(state,start,experiment,stratum)')
        db.execute('CREATE INDEX tasks_experiment ON tasks(experiment,stratum,start)')
        initialize_runtime(db)
        put(db,'meta','signature',manifest['signature'])
        for energy in energies: add_energy(db,manifest,energy)
    atomic_json(root/'manifest.json',manifest)
    return manifest


def active_indices(q, z):
    return [i for i, name in enumerate(NAMES) if not
            (q == 0 and name in ("SC", "TI") or q == z and name in ("SL", "LI"))]


def event_weights(target, lost):
    """Unbiased IEVM/IPM products at fixed b, from independent electron draws.

    Target labels: 0 retained, 1 ionized, 2 captured. Shell occupancies are
    exactly two in this model. Loss occupancy may be 0 through 6 (C/Li/O/S).
    """
    target, lost = np.asarray(target), np.asarray(lost)
    if target.shape != (5, 2) or not np.isin(target, (0, 1, 2)).all() or not np.isin(lost, (0, 1)).all():
        raise ValueError("Invalid independent-electron events")
    ni, nc = int(np.count_nonzero(target == 1)), int(np.count_nonzero(target == 2))
    si = int(np.count_nonzero(((target[:, 0] == 1) & (target[:, 1] == 0)) |
                             ((target[:, 1] == 1) & (target[:, 0] == 0))))
    di = int(np.count_nonzero(np.all(target == 1, axis=1)))
    sl = int(np.sum(lost) == 1)
    return np.array([int(nc == 1 and ni == 0), int(nc == 1 and ni == 1), sl, si * sl, si, di], dtype=np.int8)


def annulus_edges(controls, stage):
    b=float(controls.bmax)
    # Numerical quadrature strata resolve the compact inner-shell region.
    edges=[0.]+[v for v in (1.,5.,10.,20.) if v < b]+[b]
    if stage=='bmax': edges.append(2*b)
    return edges


def make_experiment(db, manifest, key, case, stage):
    controls=Controls(**case['controls'])
    arms=[asdict(controls)]
    if stage!='production': arms.append(asdict(controls.refined(stage)))
    edges=annulus_edges(controls,stage)
    identity=digest(dict(case=key,controls=asdict(controls),stage=stage))
    existing=get(db,'experiments',identity)
    if existing is not None:
        verify_design(manifest,existing)
        case['experiments'][stage]=identity
        return existing
    targets=[manifest['policy']['initial_samples']]*(len(edges)-1)
    if stage=='bmax': targets[-1]=manifest['policy']['cutoff_tail_samples']
    planned=None
    if stage=='production':
        pilot=get(db,'experiments',case['experiments']['solver'])
        targets=list(pilot['report']['production_targets'])
        planned=list(targets)
        case['frozen_settings']=dict(controls=case['controls'],checks=dict(case['experiments']),
                                    production_samples=list(targets),frozen_at=time.time())
    exp=dict(id=identity,case=key,charge=case['charge'],energy=case['energy'],stage=stage,
        arms=arms,edges=edges,targets=targets,scheduled=[0]*len(targets),completed=[0]*len(targets),
        status='sampling',report=None,planned_targets=planned,reference_targets=list(targets))
    verify_design(manifest,exp)
    put(db,'experiments',identity,exp)
    case['experiments'][stage]=identity
    return exp


def verify_design(manifest, exp):
    controls=Controls(**exp['arms'][0]);stage=exp['stage'];policy=Policy(**manifest['policy'])
    if stage not in STAGES or exp['case']!=case_key(exp['energy'],exp['charge']):
        raise ValueError('Invalid experiment case/stage')
    if exp['energy'] not in manifest['energies'] or not 0 <= exp['charge'] <= manifest['nuclear_charge']:
        raise ValueError('Case lies outside fixed production grid')
    if exp['id']!=digest(dict(case=exp['case'],controls=asdict(controls),stage=stage)):
        raise ValueError('Changed experiment identity')
    base=Controls(**starting_controls(manifest,exp['energy']))
    groups={'bmax':('bmax',),'flight':('incoming','outgoing','minimum_time'),
            'solver':('rtol','atol','radial','minimum_radius')}
    for axis,names in groups.items():
        possibilities=[]
        for level in range(policy.max_axis_levels+1):
            try: candidate=base.refined(axis,level)
            except ValueError: break
            possibilities.append(tuple(getattr(candidate,k) for k in names))
        if tuple(getattr(controls,k) for k in names) not in possibilities:
            raise ValueError('Controls outside declared refinement range')
    if controls.energy_drift!=base.energy_drift or controls.maximum_steps!=base.maximum_steps:
        raise ValueError('Changed conservation or integration limit')
    arms=[asdict(controls)]+([] if stage=='production' else [asdict(controls.refined(stage))])
    if exp['arms']!=arms or exp['edges']!=annulus_edges(controls,stage):
        raise ValueError('Changed numerical contrast/impact geometry')
    cap=policy.production_max_samples if stage=='production' else policy.max_samples_per_annulus
    floor=policy.production_min_samples if stage=='production' else policy.initial_samples
    limits=[cap if cap is not None else math.inf]*len(exp['targets'])
    if stage=='bmax': limits[-1]=max(limits[-1],policy.cutoff_tail_samples)
    if len(exp['targets'])!=len(exp['edges'])-1 or any(n!=int(n) or not floor<=n<=limit or n%policy.block_size for n,limit in zip(exp['targets'],limits)):
        raise ValueError('Invalid fixed sample target')
    if exp.get('planned_targets') is not None and exp['targets']!=exp['planned_targets']:
        raise ValueError('A frozen sample target changed')


def config_for(manifest, controls, reference=False):
    k = Controls(**controls)
    return C.CTMCConfig(backend="scipy" if reference else "numba", trajectories=1,
        trajectory_chunk_size=1, target_bmax_au=(k.bmax,) * 5,
        loss_bmax_au=(k.bmax,) * manifest["nuclear_charge"], radial_grid_points=k.radial,
        start_separation_au=(k.incoming,), boundary_extension_factor=2,
        maximum_boundary_extensions=Policy(**manifest.get('policy', {})).max_axis_levels,
        minimum_integration_time_au=(k.minimum_time,), rtol=k.rtol, atol=k.atol,
        retry_rtol=k.rtol, retry_atol=k.atol, max_step_au=math.inf,
        minimum_radius_au=k.minimum_radius, maximum_relative_energy_drift=k.energy_drift,
        max_failure_fraction=0, maximum_integration_steps=k.maximum_steps, seed=manifest["seed"],
        projectile=manifest["projectile"], initial_ensemble=manifest["ensemble"],
        projectile_loss_initialization=manifest["initialization"], channel_scope="all",
        expanded_impact_domain=True, terminal_core_distance_au=(k.outgoing,))


def phase_rng(manifest, exp, stratum, sample, channel, electron):
    # Arm/worker/job/count deliberately absent: paired phases and exact resume.
    return np.random.default_rng(np.random.SeedSequence(
        [manifest["seed"], *[int(exp["id"][i:i + 8], 16) for i in range(0, 64, 8)],
         stratum, sample, channel, electron]))


def initial_state_audit(manifest, case):
    """Mechanical COM/binding/CDF checks, not a claim of quantum-model validity."""
    C.select_projectile(manifest["projectile"])
    cfg = config_for(manifest, case["controls"])
    q = case["charge"]
    maximum = {name: 0. for name in ("com_position", "com_velocity", "binding_relative")}
    channels = [("target", o.binding_eV) for o in C.WATER_ORBITALS]
    if q < manifest["nuclear_charge"]:
        channels.append(("projectile", C.PROJECTILE_OUTER_ORBITAL[q].binding_eV))
    for channel, (bound, binding) in enumerate(channels):
        target, projectile = C._trajectory_cores(q, bound)
        core = target if bound == "target" else projectile
        mass = C.WATER_MASS_AU if bound == "target" else C.PROJECTILE_MASS_AU
        radii, cdf = C._microcanonical_radius_cdf(core.nuclear_charge, core.spectators, round(binding, 10), cfg.radial_grid_points)
        if not (np.isfinite(cdf).all() and np.all(np.diff(cdf) >= 0) and cdf[0] == 0 and cdf[-1] == 1 and np.all(np.diff(radii) > 0)):
            raise ValueError("Invalid radial sampler CDF")
        for sample in range(16):
            b = cfg.target_bmax_au[0] * sample / 16
            state = C._build_initial_relative_state(energy_keV_u=case["energy"], impact_parameter_au=b,
                separation_au=cfg.start_separation_au[0], bound_to=bound, binding_eV=binding,
                target_core=target, projectile_core=projectile, radial_grid_points=cfg.radial_grid_points,
                rng=np.random.default_rng(np.random.SeedSequence([manifest["seed"], q, channel, sample])),
                initial_ensemble=cfg.initial_ensemble, projectile_loss_initialization=cfg.projectile_loss_initialization)
            fraction = C.ELECTRON_MASS_AU / (mass + C.ELECTRON_MASS_AU)
            direction = 1 if bound == "target" else -1
            expected_r = direction * np.array([b, 0., -cfg.start_separation_au[0]])
            expected_v = direction * np.array([0., 0., C.projectile_velocity_au(case["energy"])])
            maximum["com_position"] = max(maximum["com_position"], float(np.max(abs(state[:3] - fraction * state[3:6] - expected_r))))
            maximum["com_velocity"] = max(maximum["com_velocity"], float(np.max(abs(state[6:9] - fraction * state[9:12] - expected_v))))
            energy = C._electron_core_energy_relative(state, 0, core, mass, cfg.minimum_radius_au)
            maximum["binding_relative"] = max(maximum["binding_relative"], abs(energy + binding / C.EV_PER_HARTREE) / (binding / C.EV_PER_HARTREE))
    eps = 256 * np.finfo(float).eps
    if maximum["com_position"] > eps * max(1, cfg.start_separation_au[0], cfg.target_bmax_au[0]) or maximum["com_velocity"] > eps * max(1, C.projectile_velocity_au(case["energy"])) or maximum["binding_relative"] > 1e-7:
        raise ValueError(f"Initial-state invariant failed: {maximum}")
    return dict(status="pass", maxima=maximum, states=16 * len(channels),
                scope="COM, binding and CDF implementation checks; radial/flight/solver accuracy require collision contrasts")


def task_cost(manifest, exp, stratum, count):
    charge=exp['charge']
    loss=0 if charge==manifest['nuclear_charge'] else C.PROJECTILES[manifest['projectile']].outer_orbitals[charge].active_electrons
    arms=1 if exp['stage']=='bmax' else sum(exp['edges'][stratum]<arm['bmax'] for arm in exp['arms'])
    return count*(10+loss)*arms


def reserved_cost(db):
    # Only never-started superseded blocks release their allocation. Cancelled
    # partial packets retain the full reservation because their flow cost is unknown.
    return (db.execute("SELECT COALESCE(SUM(cost),0) FROM task_counts WHERE state!='superseded'").fetchone()[0]
            + (get(db, "meta", "external_reserved_trajectories") or 0))


def schedule(db, manifest, exp):
    if exp['targets']==exp['scheduled']: return
    policy=Policy(**manifest['policy'])
    added=sum(task_cost(manifest,exp,s,n-exp['scheduled'][s]) for s,n in enumerate(exp['targets']))
    if policy.max_trajectories is not None and reserved_cost(db)+added>policy.max_trajectories:
        exp.update(status='budget_exhausted',reason='Declared total electron-flow budget exhausted')
        put(db,'experiments',exp['id'],exp); return
    for s,target in enumerate(exp['targets']):
        for start in range(exp['scheduled'][s],target,policy.block_size):
            count=min(policy.block_size,target-start)
            db.execute("INSERT INTO tasks(id,experiment,stratum,start,count,cost,state) VALUES (?,?,?,?,?,?,'ready')",
                (f"{exp['id']}:{s}:{start:012d}",exp['id'],s,start,count,task_cost(manifest,exp,s,count)))
        exp['scheduled'][s]=target
    put(db,'experiments',exp['id'],exp)


def execute(task, exp, manifest, runtime):
    """One bounded block. Failed samples are explicit; no surviving-only mean."""
    load_runtime(runtime)
    verify_design(manifest, exp)
    C.select_projectile(manifest["projectile"])
    q = exp["charge"]
    cfgs = [config_for(manifest, arm, exp["stage"] == "reference" and i == 1) for i, arm in enumerate(exp["arms"])]
    values = np.zeros((task["count"], len(cfgs), len(NAMES)), dtype=np.int8)
    attempts, max_drift = 0, 0.
    location = {}
    started = time.monotonic()
    signature = digest(dict(task=task["id"], experiment=exp["id"],
                            manifest=manifest["signature"], execution=CONTINUATION_REVISION or EXECUTION_REVISION))
    checkpoint = None
    if task.get("result"):
        saved = json.loads(zlib.decompress(task["result"]))
        checkpoint = saved.get("continuation")
    if checkpoint is not None and (checkpoint.get("signature") != signature
            or checkpoint.get("schema") != 1):
        raise ValueError("Incompatible trajectory continuation")
    completed = [] if checkpoint is None else checkpoint["completed"]
    cached = {tuple(item[:4]): item[4:] for item in completed}
    if len(cached) != len(completed):
        raise ValueError("Duplicate continued electron")
    active = None if checkpoint is None else checkpoint.get("active")
    coordinate, state = None, None
    last_work = {}
    def pause(coordinate=None, state=None):
        return dict(yielded=dict(schema=1, signature=signature, task=task["id"],
                    completed=completed, active=None if coordinate is None else
                    dict(coordinate=list(coordinate), state=state)),
                    runtime=dict(seconds=time.monotonic()-started, location=location,
                                 work=last_work, revision=EXECUTION_REVISION))
    try:
        for offset in range(task["count"]):
            sample = task["start"] + offset
            u = phase_rng(manifest, exp, task["stratum"], sample, 999, 0).random()
            lo, hi = exp["edges"][task["stratum"]:task["stratum"] + 2]
            b = math.sqrt(lo * lo + u * (hi * hi - lo * lo))
            for arm, cfg in enumerate(cfgs):
                if b > exp["arms"][arm]["bmax"]:
                    continue
                if exp["stage"] == "bmax" and arm > 0 and b <= exp["arms"][arm - 1]["bmax"]:
                    values[offset, arm] = values[offset, arm - 1]
                    continue
                targets = np.zeros((5, 2), dtype=np.int8)
                occupancy = 0 if q == manifest["nuclear_charge"] else C.PROJECTILE_OUTER_ORBITAL[q].active_electrons
                lost = np.zeros(occupancy, dtype=np.int8)
                channels = [("target", j, o.binding_eV, 2) for j, o in enumerate(C.WATER_ORBITALS)]
                if occupancy:
                    channels.append(("projectile", 5, C.PROJECTILE_OUTER_ORBITAL[q].binding_eV, occupancy))
                for bound, channel, binding, electrons in channels:
                    for electron in range(electrons):
                        check_cancelled()
                        state = None
                        location = dict(sample=sample, arm=arm, channel=channel, electron=electron, impact_au=b)
                        coordinate = (offset, arm, channel, electron)
                        if coordinate in cached:
                            outcome, success, drift = cached[coordinate]
                        else:
                            if time.monotonic()-started >= RUNTIME["packet_seconds"]:
                                return pause(None if active is None else active["coordinate"],
                                             None if active is None else active["state"])
                            kwargs = dict(energy_keV_u=exp["energy"], charge_state=q,
                                impact_parameter_au=b, bound_to=bound, binding_eV=binding,
                                start_separation_au=cfg.start_separation_au[0], minimum_integration_time_au=cfg.minimum_integration_time_au[0],
                                config=cfg, rng=phase_rng(manifest, exp, task["stratum"], sample, channel, electron),
                                minimum_terminal_core_separation_au=cfg.terminal_core_distance_au[0],
                                retain_ambiguous_endpoint=True)
                            if hasattr(C, "simulate_one_trajectory_segment"):
                                if active is not None and tuple(active["coordinate"]) != coordinate:
                                    raise ValueError("Continuation electron order changed")
                                state = None if active is None else active["state"]
                                while True:
                                    check_cancelled()
                                    part = C.simulate_one_trajectory_segment(**kwargs, continuation=state,
                                        segment_steps=RUNTIME["integration_segment_steps"])
                                    last_work = part.get("work", {})
                                    if part["status"] == "done":
                                        outcome, success, drift = part["result"]
                                        active = None
                                        break
                                    if part["status"] != "yielded":
                                        raise ValueError("Invalid integration segment status")
                                    state = part["continuation"]
                                    if time.monotonic()-started >= RUNTIME["packet_seconds"]:
                                        return pause(coordinate, state)
                            else:
                                raise RuntimeError("The production runtime requires deterministic segmented integration")
                            if success and math.isfinite(drift):
                                completed.append([*coordinate, outcome, bool(success), float(drift)])
                        attempts += 1
                        if not success or outcome not in ("ionized", "captured_projectile", "retained_target") or not math.isfinite(drift):
                            return dict(failure=location | dict(outcome=outcome, drift=drift if math.isfinite(drift) else None), attempts=attempts)
                        max_drift = max(max_drift, drift)
                        if bound == "target":
                            targets[channel, electron] = {"retained_target": 0, "ionized": 1, "captured_projectile": 2}[outcome]
                        else:
                            lost[electron] = outcome == "ionized"
                values[offset, arm] = event_weights(targets, lost)
                if q == 0:
                    values[offset, arm, :2] = 0
        result = dict(values=values.tolist(), attempts=attempts, maximum_energy_drift=max_drift)
        if hasattr(C, "simulate_one_trajectory_segment"):
            result["runtime"] = dict(seconds=time.monotonic()-started, location=location,
                                     work=last_work, revision=EXECUTION_REVISION)
        return result
    except Exception as exc:
        import traceback
        # Keep successful electrons and the last bounded solver state. A runtime
        # exception is repairable; it must not erase the packet's restart data.
        saved = pause(coordinate if state is not None else None, state)["yielded"]
        return dict(failure=location | dict(outcome="execution_error", error=f"{type(exc).__name__}: {exc}",
                    traceback=traceback.format_exc(limit=8)), attempts=attempts, continuation=saved)


class SupersededTrajectory(BaseException):
    """Control flow, never a physical integration failure."""


def initialize_cancellation(flags):
    global _CANCEL_FLAGS
    _CANCEL_FLAGS = flags


def check_cancelled():
    if _CANCEL_FLAGS is not None and _CANCEL_SLOT is not None and _CANCEL_FLAGS[_CANCEL_SLOT]:
        raise SupersededTrajectory()


def execute_cancellable(task, exp, manifest, runtime):
    """Poll shared memory at electron boundaries and SciPy RHS evaluations.

    Native kernels finish their current electron before polling. No signal,
    process termination, or surviving-only packet estimate is involved.
    """
    global _CANCEL_SLOT
    load_runtime(runtime)
    _CANCEL_SLOT = task.get("cancel_slot")
    original = C.solve_ivp
    def solve(*args, **kwargs):
        fun = args[0] if args else kwargs["fun"]
        def rhs(*a):
            check_cancelled()
            return fun(*a)
        if args:
            args = (rhs, *args[1:])
        else:
            kwargs["fun"] = rhs
        return original(*args, **kwargs)
    C.solve_ivp = solve
    try:
        check_cancelled()
        started = time.monotonic()
        result = execute(task, exp, manifest, runtime)
        if hasattr(C, "simulate_one_trajectory_segment") and isinstance(result, dict):
            result.setdefault("runtime", dict(seconds=time.monotonic()-started,
                location=result.get("failure", {}), revision=EXECUTION_REVISION))
        return result
    except SupersededTrajectory:
        return dict(cancelled="superseded_design")
    finally:
        C.solve_ivp = original
        _CANCEL_SLOT = None


def needed_experiments(db):
    needed=set()
    for row in db.execute('SELECT payload FROM cases'):
        case=json.loads(row[0])
        if case['status'] not in TERMINAL_CASE_STATES and case['status'] not in ('complete','qualified'):
            needed.update(case['experiments'].values())
    return needed


def production_indices(charge, nuclear_charge):
    return ([6] if charge == 0 else [7] if charge == nuclear_charge else [6,7])


def measurement_support(exp, stratum, nuclear_charge):
    """Exact packet support, including shared-cutoff and absent-channel zeros."""
    arms = len(exp["arms"])
    low = np.zeros((2*arms-1,len(MEASURE_NAMES)))
    high = np.tile(MEASURE_RANGES,(2*arms-1,1))
    low[arms:] = -MEASURE_RANGES
    outside = [exp["edges"][stratum] >= arm["bmax"] for arm in exp["arms"]]
    for arm,absent in enumerate(outside):
        if absent:
            low[arm] = high[arm] = 0
    for pair in range(arms-1):
        shared_inside = (exp["stage"] == "bmax" and exp["edges"][stratum+1] <= exp["arms"][pair]["bmax"])
        if shared_inside or (outside[pair] and outside[pair+1]):
            low[arms+pair] = high[arms+pair] = 0
        elif exp["stage"] == "bmax" or outside[pair]:
            low[arms+pair] = 0
        elif outside[pair+1]:
            high[arms+pair] = 0
    inactive = sorted(set(range(len(NAMES)))-set(active_indices(exp["charge"],nuclear_charge)))
    inactive += sorted({6,7}-set(production_indices(exp["charge"],nuclear_charge)))
    low[:,inactive] = high[:,inactive] = 0
    return low,high


def assess_experiment(db, manifest, exp, *, force=False):
    """Assess complete deterministic cohorts outside the trajectory dispatch lock."""
    verify_design(manifest,exp)
    failures=[json.loads(zlib.decompress(r[0])) for r in db.execute("SELECT result FROM tasks WHERE experiment=? AND state='failed'",(exp['id'],))]
    if failures: return dict(status='trajectory_failure',failures=failures)
    if exp['completed']!=exp['targets']: return dict(status='sampling')
    if not force and exp['report'] is not None and exp['report'].get('samples')==exp['targets']:
        return exp['report']
    if not force and get(db,'meta','async_audits'):
        identity=digest(dict(experiment=exp['id'],targets=exp['targets'],assessment=ASSESSMENT_REVISION,
                             followup=exp.get('production_followup')))
        db.execute("INSERT OR IGNORE INTO audits(id,experiment,targets,state) VALUES (?,?,?,'ready')",(identity,exp['id'],canonical(exp['targets'])))
        return dict(status='sampling',audit=identity)
    arms=len(exp['arms']);strata=len(exp['targets'])
    means=[];moment_variances=[];rate_covariances=[];nonzeros=[]
    for s,target in enumerate(exp['targets']):
        cursor=0;after=(-1,'')
        total=np.zeros((2*arms-1,len(MEASURE_NAMES)),dtype=np.int64)
        squares=np.zeros_like(total);nonzero=np.zeros_like(total);cross=np.zeros(arms,dtype=np.int64)
        low,high=measurement_support(exp,s,manifest['nuclear_charge'])
        while True:
            batch=db.execute('SELECT * FROM tasks WHERE experiment=? AND stratum=? AND (start,id)>(?,?) AND start<? ORDER BY start,id LIMIT ?',
                (exp['id'],s,*after,target,RUNTIME['audit_read_batch'])).fetchall()
            if not batch: break
            for row in batch:
                if row['state']!='done': return dict(status='sampling')
                if row['start']!=cursor or cursor+row['count']>target: raise ValueError('Noncontiguous sample cohort')
                data=json.loads(zlib.decompress(row['result']))
                if data['attempts']!=row['cost']: raise ValueError('Trajectory accounting mismatch')
                raw=np.asarray(data['values'])
                if raw.shape!=(row['count'],arms,len(NAMES)) or not np.isfinite(raw).all() or np.any(raw<0) or np.any(raw>RANGES) or np.any(raw!=np.floor(raw)):
                    raise ValueError('Invalid CTMC packet')
                raw=raw.astype(np.int64)
                x=np.concatenate((raw,(raw[...,2]+raw[...,3])[...,None],(raw[...,0]+raw[...,1])[...,None]),axis=-1)
                y=np.concatenate((x,np.diff(x,axis=1)),axis=1)
                if np.any(y<low) or np.any(y>high): raise ValueError('Packet violates known support')
                total+=y.sum(axis=0);squares+=(y*y).sum(axis=0);nonzero+=np.count_nonzero(y,axis=0)
                cross+=(x[...,6]*x[...,7]).sum(axis=0);cursor+=row['count']
            after=(batch[-1]['start'],batch[-1]['id'])
        if cursor!=target: return dict(status='sampling')
        mean=total/target
        variance=np.maximum(0.,(squares-total.astype(float)*total/target)/(target-1))
        area=math.pi*(exp['edges'][s+1]**2-exp['edges'][s]**2)*C.BOHR2_CM2
        means.append(mean*area);moment_variances.append(variance/target*area**2);nonzeros.append(nonzero)
        rate_covariances.append((cross-total[:arms,6].astype(float)*total[:arms,7]/target)/(target-1)/target*area**2)
    timing=list(db.execute("SELECT t.stratum,SUM(p.seconds)/SUM(t.count) FROM task_progress p INDEXED BY task_progress_experiment CROSS JOIN tasks t ON t.id=p.task WHERE p.experiment=? AND t.state='done' GROUP BY t.stratum",(exp['id'],)))
    if len(timing)==strata and all(value>0 for _,value in timing):
        exp=dict(exp,_seconds_per_sample=[dict(timing)[i] for i in range(strata)])
    return dict(staged_workflow(manifest).assess_moments(sys.modules[__name__],manifest,exp,np.sum(means,axis=0),
        moment_variances,rate_covariances,stratum_means=means,stratum_nonzero=nonzeros),
        assessment_revision=ASSESSMENT_REVISION,execution_revision=EXECUTION_REVISION)


def more_samples(db, manifest, exp):
    progressive = manifest['policy']['max_samples_per_annulus'] is None
    plan=exp['report']['allocation']['planned_targets']
    if plan is None or plan==exp['targets'] or (not progressive and exp.get('planned_targets') is not None):
        exp['status']='sampling_limit'
    else:
        exp.setdefault('reference_targets',list(exp['targets']))
        exp['sampling_rounds']=exp.get('sampling_rounds',0)+1
        exp['planned_targets']=list(plan)
        exp['targets']=list(plan)
        exp['status']='sampling'
        schedule(db,manifest,exp)
    put(db,'experiments',exp['id'],exp)


def advance_controls(case, axis, policy):
    if axis not in AXES or case["levels"][axis] >= policy.max_axis_levels:
        case["status"] = "numerical_limit"
        case["reason"] = f"Cannot refine {axis} within the declared limits"
        return
    try:
        case["controls"] = asdict(Controls(**case["controls"]).refined(axis))
    except ValueError as exc:
        case["status"], case["reason"] = "numerical_limit", str(exc)
        return
    case["levels"][axis] += 1
    case.pop("certificate", None)
    case.update(experiments={}, preflight=None, status="pending")
    # Old experiments stay in the ledger; none is reused for a changed model/domain.


def reopen_unobserved_checks(db, manifest, case, production, report):
    """Use production only to plan fresh comparison samples at identical controls."""
    pending=[]
    for stage in AXES:
        exp=get(db,'experiments',case['experiments'][stage])
        check=exp.get('report') or {}
        names=[name for name,state in check.get('numerical_status_by_observable',{}).items()
               if state=='unobserved_rate' and report['mean'][0][MEASURE_NAMES.index(name)]>0]
        if not names: continue
        if exp['arms'][0]!=production['arms'][0]: raise ValueError('Follow-up baseline settings differ')
        pending.append((stage,exp,names))
    if not pending: return False
    if 'stratum_means' not in report:
        # Old production cohorts need one new asynchronous moment audit, never
        # a replay of their completed trajectories.
        production.update(status='sampling',report=None)
        put(db,'experiments',production['id'],production)
        case.update(status='sampling',stage='production')
        return True
    for stage,exp,names in pending:
        exp['production_followup']=dict(production=production['id'],observables=names,
            mean=report['mean'][0],stratum_means=report['stratum_means'],
            raw_variances=report['stratum_raw_variances'],
            scope='Production-guided planning only; comparison estimates retain their own samples')
        exp.update(status='sampling',report=None)
        put(db,'experiments',exp['id'],exp)
    case.update(status='sampling',stage=pending[0][0])
    return True


def assess_case(db, manifest, key, case, *, force=False):
    if case['status'] in TERMINAL_CASE_STATES or case['status']=='qualified': return
    if case['status']=='complete' and case.get('certificate',{}).get('numerical_qualification_met'): return
    policy=Policy(**manifest['policy'])
    if case['preflight'] is None:
        try: case['preflight']=initial_state_audit(manifest,case)
        except (ValueError,RuntimeError) as exc:
            case.update(status='initialization_failure',reason=str(exc));return
    for stage in STAGES:
        try:
            exp=get(db,'experiments',case['experiments'][stage]) if stage in case['experiments'] else make_experiment(db,manifest,key,case,stage)
        except ValueError as exc:
            case.update(status='numerical_limit',reason=str(exc));return
        if exp['status'] in ('budget_exhausted','sampling_limit'):
            case.update(status=exp['status'],failed_stage=stage);return
        schedule(db,manifest,exp)
        if exp['status']=='budget_exhausted':
            case.update(status='budget_exhausted',failed_stage=stage);return
        report=assess_experiment(db,manifest,exp,force=force)
        exp['report'],exp['status']=report,report['status'];put(db,'experiments',exp['id'],exp)
        if report['status']=='trajectory_failure':
            outcomes={r['failure']['outcome'] for r in report['failures']}
            if outcomes=={'ambiguous_bound'}:
                case.update(status='numerical_limit', failed_stage=stage,
                    reason='Ambiguous endpoint remains after bounded continuation of the same collision')
            elif stage!='production' and outcomes <= {'energy_conservation_failure','integration_failure'}:
                advance_controls(case,'solver',policy)
            else: case.update(status='execution_error',reason=report,failed_stage=stage)
            return
        if report['status']=='resolved_change':
            advance_controls(case,stage,policy);return
        if report['status']=='needs_samples':
            more_samples(db,manifest,exp);case['status']=exp['status'];return
        if report['status'] in ('sampling_limit','execution_error'):
            case.update(status=report['status'],reason=report,failed_stage=stage);return
        if stage=='production' and report['status']=='production_complete':
            precise=bool(report['precision_met'])
            if precise and reopen_unobserved_checks(db,manifest,case,exp,report): return
            checks={name:get(db,'experiments',case['experiments'][name])['report'] for name in AXES}
            numerical=all(r.get('numerical_qualification_met',False) for r in checks.values())
            unresolved=sorted({name for r in checks.values() for name in r.get('unresolved_observables',[])})
            case['status']='qualified' if precise and numerical else 'complete'
            case['certificate']=dict(controls=case['controls'],experiments=dict(case['experiments']),
                mean=report['mean'][0],standard_error=report['standard_error'][0],
                rate_covariance=report['rate_covariance'][0],precision_met=precise,
                numerical_qualification_met=numerical,numerically_unresolved_observables=unresolved,
                precision_by_observable=report['precision_by_observable'],
                zero_upper_limit=report.get('zero_upper_limit'),
                effective_statistical_relative=report.get('effective_statistical_relative',policy.statistical_relative),
                scope='Tested numerical settings and estimated Monte Carlo errors; production streams start independently of pilots but sample size is data-dependent. No repeated-look confidence or physical-model certification.')
            return
        if report['status']!='pass':
            case.update(status='sampling',stage=stage);return


def advance(db, manifest, *, force=False):
    for row in db.execute('SELECT id,payload FROM cases ORDER BY id').fetchall():
        case=json.loads(row['payload'])
        assess_case(db,manifest,row['id'],case,force=force)
        put(db,'cases',row['id'],case)
    prune_inactive_work(db)
    return summary(db,manifest)


def prune_inactive_work(db):
    needed=needed_experiments(db)
    for row in db.execute("SELECT DISTINCT experiment FROM tasks WHERE state='ready'").fetchall():
        if row[0] not in needed:
            db.execute("UPDATE tasks SET state='superseded' WHERE experiment=? AND state='ready' AND resuming=0",(row[0],))
            db.execute("UPDATE tasks SET state='cancelled' WHERE experiment=? AND state='ready' AND resuming=1",(row[0],))
    for row in db.execute("SELECT DISTINCT experiment FROM audits WHERE state='ready'").fetchall():
        if row[0] not in needed: db.execute("UPDATE audits SET state='superseded' WHERE experiment=? AND state='ready'",(row[0],))


def commit_result(db, task, result, owner):
    row = db.execute("SELECT * FROM tasks WHERE id=?", (task["id"],)).fetchone()
    if row["state"] != "running" or row["owner"] != owner:
        raise ValueError("Stale or duplicate task completion")
    result = dict(result)
    telemetry = result.pop("runtime", None)
    if telemetry is not None:
        seconds = float(telemetry["seconds"])
        if not math.isfinite(seconds) or seconds < 0:
            raise ValueError("Invalid integration timing")
        now = time.time()
        db.execute("INSERT INTO task_progress(task,experiment,started,updated,segments,seconds,payload) VALUES (?,?,?,?,1,?,?) ON CONFLICT(task) DO UPDATE SET updated=excluded.updated,segments=segments+1,seconds=seconds+excluded.seconds,payload=excluded.payload",
                   (row["id"],row["experiment"],now-seconds,now,seconds,canonical(telemetry)))
    if "yielded" in result:
        state = result["yielded"]
        if (set(result) != {"yielded"} or state.get("task") != row["id"]
                or state.get("schema") != 1 or len(state["completed"]) > row["cost"]):
            raise ValueError("Invalid partial trajectory packet")
        db.execute("UPDATE tasks SET state='ready',owner=NULL,resuming=1,result=? WHERE id=?",
                   (zlib.compress(canonical(dict(continuation=state)).encode()),row["id"]))
        return
    if "cancelled" in result:
        if (result != dict(cancelled="superseded_design")
                or row["experiment"] in needed_experiments(db)):
            raise ValueError("Cancellation of required work refused")
        # A distinct terminal state retains the full reservation in the budget:
        # the exact interrupted flow count is unknown. No partial sample enters
        # inference, including when older workers read this shared checkpoint.
        db.execute("UPDATE tasks SET state='cancelled',result=? WHERE id=?",
                   (zlib.compress(canonical(result).encode()), row["id"]))
        count = get(db, "meta", "cooperatively_cancelled_blocks") or 0
        put(db, "meta", "cooperatively_cancelled_blocks", count+1)
        return
    failed = "failure" in result
    if failed and result["failure"].get("outcome") == "execution_error":
        if "continuation" not in result and row["result"]:
            previous = json.loads(zlib.decompress(row["result"]))
            if "continuation" in previous:
                result["continuation"] = previous["continuation"]
        put(db,"meta","last_worker_error",dict(owner=owner,task=row["id"],
            failure=result["failure"],time=time.time()))
        put(db,"meta","stop_requested",True)
    if not failed and result.get("attempts") != row["cost"]:
        raise ValueError("Trajectory accounting mismatch")
    db.execute("UPDATE tasks SET state=?,result=? WHERE id=?",
        ("failed" if failed else "done", zlib.compress(canonical(result).encode()), row["id"]))
    exp = get(db, "experiments", row["experiment"])
    if not failed:
        exp["completed"][row["stratum"]] += row["count"]
        put(db, "experiments", exp["id"], exp)


def execute_audit(task, exp, manifest, root):
    """Heavy statistical work runs in a compute worker, outside the dispatch lock."""
    root = Path(root)
    load_runtime(root / "source")
    C.select_projectile(manifest["projectile"])
    with sqlite3.connect(f"file:{root / 'campaign.sqlite'}?mode=ro",uri=True,timeout=60) as db:
        db.row_factory = sqlite3.Row
        return assess_experiment(db,manifest,exp,force=True)


def commit_audit(db, task, report, owner):
    row = db.execute("SELECT * FROM audits WHERE id=?",(task["id"],)).fetchone()
    if row["state"] != "running" or row["owner"] != owner:
        raise ValueError("Stale audit completion")
    exp = get(db,"experiments",row["experiment"])
    current = canonical(exp["targets"]) == row["targets"]
    db.execute("UPDATE audits SET state=?,result=? WHERE id=?",
               ("done" if current else "superseded",zlib.compress(canonical(report).encode()),row["id"]))
    if current:
        exp["report"] = report
        if report.get("status") == "execution_error":
            case = get(db,"cases",exp["case"])
            case.update(status="execution_error",reason=report)
            put(db,"cases",exp["case"],case)
        put(db,"experiments",exp["id"],exp)


def reclaim_orphans(db, root, current_owner):
    """A vanished parent cannot keep a task lease alive; no clock-based stealing."""
    has_audits = db.execute("SELECT 1 FROM sqlite_master WHERE name='audits'").fetchone()
    sql = "SELECT DISTINCT owner FROM tasks WHERE state='running'"
    if has_audits:
        sql += " UNION SELECT DISTINCT owner FROM audits WHERE state='running'"
    for row in db.execute(sql).fetchall():
        owner = row[0]
        if owner == current_owner:
            continue
        with (Path(root) / f"worker_{owner}.lock").open("a+") as lock:
            try:
                fcntl.lockf(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                continue
            db.execute("UPDATE tasks SET state='ready',owner=NULL WHERE state='running' AND owner=?", (owner,))
            if has_audits:
                db.execute("UPDATE audits SET state='ready',owner=NULL WHERE state='running' AND owner=?", (owner,))


def summary(db, manifest):
    cases=[json.loads(r[0]) for r in db.execute('SELECT payload FROM cases ORDER BY id')]
    completed=sum(c['status'] in ('complete','qualified') for c in cases)
    qualified=sum(c['status']=='qualified' for c in cases)
    finished=bool(cases and all(c['status'] in (*TERMINAL_CASE_STATES,'complete','qualified') for c in cases))
    counts=dict(db.execute('SELECT state,SUM(n) FROM task_counts GROUP BY state HAVING SUM(n)>0'))
    calls=db.execute("SELECT COALESCE(SUM(cost),0) FROM task_counts WHERE state='done'").fetchone()[0]
    worker_error=get(db,'meta','last_worker_error')
    return dict(signature=manifest['signature'],status='complete' if finished else 'execution_error' if worker_error else 'running',
        workflow='production',campaign_complete=finished,completed_cases=completed,qualified_cases=qualified,total_cases=len(cases),
        production_table_ready=qualified==len(cases) and bool(cases) and manifest['purpose']=='production',
        physical_model_validated=False,tasks=counts,audits=dict(db.execute('SELECT state,COUNT(*) FROM audits GROUP BY state')),
        reserved_trajectories=reserved_cost(db),completed_trajectories=calls,completed_collision_trajectories=calls,
        worker_error=worker_error,stop_requested=bool(get(db,'meta','stop_requested')),cases=cases,limits='Finite tested cutoffs and fixed energy grid; ordinary standard errors, pointwise zero-event upper limits, and explicit unresolved cases. No simultaneous confidence or physical-model certificate.')


def _stop(signum, frame):
    global _STOP
    _STOP = True


def controller_tick(root, manifest, owner, *, force=False):
    """Elect one short-lived coordinator; collision/statistical work stays in workers."""
    with (Path(root) / "controller.lock").open("a+") as lock:
        try:
            fcntl.lockf(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        now = time.time()
        try:
            with database(root, blocking=force) as db:
                previous = get(db,"meta","runtime_health") or {}
                cooldown = max(RUNTIME["control_interval"],RUNTIME["control_cooldown_factor"]*previous.get("control_seconds",0))
                if not force and now-previous.get("last_control",0) < cooldown:
                    return False
                begin = time.monotonic()
                if now-previous.get("last_orphan_check",0) >= RUNTIME["orphan_interval"]:
                    reclaim_orphans(db,root,owner)
                    previous["last_orphan_check"] = now
                # Preserve other cases and their queued checkpoints when the
                # runtime itself fails; numerical failures retain normal policy.
                report = summary(db,manifest) if get(db,"meta","last_worker_error") else advance(db,manifest)
                health = dict(last_control=time.time(),last_orphan_check=previous.get("last_orphan_check",now),
                              control_seconds=time.monotonic()-begin,control_cooldown=cooldown,coordinator=owner)
                health["workers"] = {row[0][7:]:json.loads(row[1]) for row in db.execute("SELECT id,payload FROM meta WHERE id LIKE 'worker:%'")}
                put(db,"meta","runtime_health",health)
                report["runtime"] = health
                if force or now-previous.get("last_status",0) >= RUNTIME["status_interval"]:
                    atomic_json(Path(root)/"status.json",report)
                    health["last_status"] = now
                else:
                    health["last_status"] = previous.get("last_status",0)
                put(db,"meta","runtime_health",health)
        except BlockingIOError:
            return False
        return True


def collision_backlog(db):
    return db.execute("SELECT COALESCE(SUM(n),0) FROM task_counts WHERE state IN ('ready','running')").fetchone()[0]


def checkpoint_order(db):
    """Cache a deterministic order by samples still needed at the current look.

    Refresh at the existing status interval, not on every task claim. Running
    samples count as outstanding: a large in-flight batch is not almost done
    merely because it has few unstarted tasks. Ordering never changes samples.
    """
    cached = get(db, "meta", "checkpoint_dispatch_order")
    now = time.time()
    if cached is not None and now-cached["updated"] < RUNTIME["status_interval"]:
        return cached["experiments"]
    candidates = []
    for row in db.execute("SELECT payload FROM cases").fetchall():
        case = json.loads(row[0])
        if case["status"] in TERMINAL_CASE_STATES or case["status"] in ("qualified", "complete"):
            continue
        for stage, eid in case["experiments"].items():
            exp = get(db, "experiments", eid)
            remaining = sum(exp["targets"])-sum(exp["completed"])
            if remaining > 0 and exp["status"] not in ("pass", "budget_exhausted", "sampling_limit"):
                candidates.append((remaining, eid))
    order = [eid for _, eid in sorted(candidates)]
    put(db, "meta", "checkpoint_dispatch_order", dict(updated=now, experiments=order))
    return order


def claim_trajectory_tasks(db, worker_id, slots, *, admission_slots=None):
    """Share workers between resumptions, near-complete cohorts and fresh work."""
    if slots <= 0:
        return []
    rows = []
    remaining = slots-len(rows)
    resume_slots = remaining//2
    if remaining == 1:
        turn = get(db, "meta", "continuation_dispatch_turn")
        resume_slots = int(turn is not False)
        put(db, "meta", "continuation_dispatch_turn", not bool(resume_slots))
    # Rotate yielded packets by their last checkpoint time. The other half of
    # the queue remains available to fresh work and finishing checkpoints.
    resumes = db.execute("SELECT * FROM tasks INDEXED BY tasks_ready_resume_updated WHERE state='ready' AND resuming=1 AND resume_updated IS NOT NULL ORDER BY resume_updated,id LIMIT ?", (resume_slots,)).fetchall() if resume_slots else []
    for row in resumes:
        db.execute("UPDATE tasks SET state='running',owner=? WHERE id=?",(worker_id,row['id']))
    rows.extend(resumes)
    remaining = slots-len(rows)
    priority_slots = (remaining+1)//2
    if remaining == 1:
        turn = get(db, "meta", "checkpoint_dispatch_turn")
        priority_slots = int(turn is not False)
        put(db, "meta", "checkpoint_dispatch_turn", not bool(priority_slots))
    if priority_slots:
        for eid in checkpoint_order(db):
            selected = db.execute("SELECT * FROM tasks INDEXED BY tasks_ready_experiment WHERE experiment=? AND state='ready' AND resuming=0 ORDER BY start,stratum LIMIT ?",
                                  (eid, priority_slots)).fetchall()
            if not selected:
                continue
            # Cached priority may outlive a refinement. Check current ownership
            # of the design before promoting any queued row.
            exp = get(db, "experiments", eid)
            case = get(db, "cases", exp["case"])
            if (case["status"] in TERMINAL_CASE_STATES or case["status"] in ("qualified", "complete")
                    or case["experiments"].get(exp["stage"]) != eid):
                continue
            for row in selected:
                db.execute("UPDATE tasks SET state='running',owner=? WHERE id=?", (worker_id,row['id']))
            rows.extend(selected)
            priority_slots -= len(selected)
            if not priority_slots:
                break
    rest = db.execute("SELECT * FROM tasks WHERE state='ready' AND resuming=0 ORDER BY start,experiment,stratum LIMIT ?", (slots-len(rows),)).fetchall()
    for row in rest:
        db.execute("UPDATE tasks SET state='running',owner=? WHERE id=?", (worker_id,row['id']))
    rows.extend(rest)
    # When fresh work is exhausted, allow continuations to fill the allocation.
    extra = db.execute("SELECT * FROM tasks INDEXED BY tasks_ready_resume WHERE state='ready' ORDER BY resuming,start,experiment,stratum LIMIT ?", (slots-len(rows),)).fetchall() if slots > len(rows) else []
    for row in extra:
        db.execute("UPDATE tasks SET state='running',owner=? WHERE id=?",(worker_id,row['id']))
    return rows + list(extra)


def collect_finished_tasks(pending):
    """Collect only ready futures, retaining successes around a pool failure."""
    from concurrent.futures.process import BrokenProcessPool
    finished, pool_error = [], None
    for future in [f for f in pending if f.done()]:
        task = pending.pop(future)
        try:
            result = future.result()
        except BrokenProcessPool as exc:
            pool_error = pool_error or repr(exc)
            continue
        except Exception as exc:
            result = (dict(status="execution_error", error=repr(exc)) if task["kind"] == "audit"
                      else dict(failure=dict(outcome="execution_error", error=repr(exc)), attempts=0))
        finished.append((task, result))
    return finished, pool_error


def run(root, workers, worker_id, *, max_seconds=0, allocation_phase="manual", admission_workers=None):
    """Dispatch, recover bounded worker failures and advance one shared campaign."""
    from concurrent.futures.process import BrokenProcessPool
    global _STOP
    if "PBS_JOBID" not in os.environ:
        raise RuntimeError("Trajectory execution requires a PBS compute allocation")
    if workers < 1 or workers > int(os.environ.get("PBS_NCPUS",os.cpu_count() or 1)):
        raise ValueError("Worker count exceeds the allocation")
    if admission_workers is None:
        admission_workers = 0
    if not isinstance(admission_workers,int) or not 0 <= admission_workers <= workers:
        raise ValueError("Admission worker reservation exceeds the allocation")
    if not math.isfinite(max_seconds) or max_seconds < 0:
        raise ValueError("Invalid per-invocation time limit")
    if not worker_id or any(ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for ch in worker_id):
        raise ValueError("Use an alphanumeric worker identifier")
    _STOP = False
    root = Path(root).resolve()
    manifest = verify(root)
    load_runtime(root/"source")
    for sig in (signal.SIGUSR1,signal.SIGTERM,signal.SIGINT):
        signal.signal(sig,_stop)
    started, capacity, repairs = time.monotonic(),workers,0
    with (root/f"worker_{worker_id}.lock").open("a+") as owner_lock:
        fcntl.lockf(owner_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        native_cache = prepare_native_runtime(root,manifest)
        with database(root) as db:
            initialize_runtime(db)
            if native_cache is not None:
                put(db,"meta","native_cache:"+native_cache["cpu"],dict(native_cache,
                    revision=CONTINUATION_REVISION,updated=time.time()))
            put(db,"meta","async_audits",True)
            for table in ("tasks","audits"):
                db.execute(f"UPDATE {table} SET state='ready',owner=NULL WHERE state='running' AND owner=?",(worker_id,))
            reclaim_orphans(db,root,worker_id)
        controller_tick(root,manifest,worker_id,force=True)
        context = multiprocessing.get_context("spawn")
        with tqdm(unit="flow/collision",desc="CTMC completed electron trajectories",mininterval=10) as bar:
            while True:
                cancel_flags = context.RawArray('b', capacity)
                pool = ProcessPoolExecutor(max_workers=capacity,mp_context=context,
                    initializer=initialize_cancellation, initargs=(cancel_flags,))
                pending, pool_error = {},None
                heartbeat, committed, cancellation_check = 0.,0,0.
                try:
                    while not _STOP or pending:
                        if max_seconds and time.monotonic()-started >= max_seconds:
                            _STOP = True
                        finished, pool_error = collect_finished_tasks(pending)
                        # A full pool with no completions needs no shared-filesystem
                        # transaction until its heartbeat or cancellation check is due.
                        now = time.monotonic()
                        if (not finished and not pool_error and len(pending) == capacity
                                and now-heartbeat < RUNTIME["status_interval"]
                                and now-cancellation_check < RUNTIME["status_interval"]):
                            wait(pending, timeout=1., return_when=FIRST_COMPLETED)
                            continue
                        jobs = []
                        with database(root) as db:
                            # More workers can finish while this parent waits for
                            # the ledger. Reclaim those slots in this transaction.
                            later, later_error = collect_finished_tasks(pending)
                            finished.extend(later)
                            pool_error = pool_error or later_error
                            # Commit completed packets and refill freed workers in
                            # one transaction, including during a stop or pool failure.
                            for task,result in finished:
                                if task["kind"]=="audit":
                                    commit_audit(db,task,result,worker_id)
                                else:
                                    commit_result(db,task,result,worker_id)
                                if "yielded" not in result:
                                    committed += 1
                            if time.monotonic()-cancellation_check >= RUNTIME["status_interval"]:
                                needed = needed_experiments(db)
                                for task in pending.values():
                                    if task["kind"] == "trajectory" and task["experiment"] not in needed:
                                        cancel_flags[task["cancel_slot"]] = 1
                                cancellation_check = time.monotonic()
                            if get(db,"meta","stop_requested"):
                                _STOP = True
                            if not _STOP and not pool_error:
                                audit_slots = min(capacity-len(pending),max(0,RUNTIME["max_audits_per_shard"]-sum(t["kind"]=="audit" for t in pending.values())))
                                for row in db.execute("SELECT * FROM audits WHERE state='ready' ORDER BY id LIMIT ?",(audit_slots,)).fetchall():
                                    task = dict(row,kind="audit")
                                    exp = get(db,"experiments",task["experiment"])
                                    if canonical(exp["targets"]) != task["targets"]:
                                        db.execute("UPDATE audits SET state='superseded' WHERE id=?",(task["id"],))
                                        continue
                                    db.execute("UPDATE audits SET state='running',owner=? WHERE id=?",(worker_id,task["id"]))
                                    jobs.append((task,exp))
                                slots = capacity-len(pending)-len(jobs)
                                for row in claim_trajectory_tasks(db,worker_id,slots,admission_slots=0):
                                    exp = get(db,"experiments",row["experiment"])
                                    task = dict(row,kind="trajectory",stage=exp['stage'])
                                    now = time.time()
                                    db.execute("INSERT OR IGNORE INTO task_progress(task,experiment,started,updated) VALUES (?,?,?,?)",
                                               (row["id"],row["experiment"],now,now))
                                    jobs.append((task,exp))
                            if time.monotonic()-heartbeat >= RUNTIME["status_interval"]:
                                put(db,"meta",f"worker:{worker_id}",dict(updated=time.time(),capacity=capacity,in_flight=len(pending)+len(jobs),completed_blocks=committed,pool_repairs=repairs,revision=EXECUTION_REVISION))
                                bar.n = db.execute("SELECT COALESCE(SUM(cost),0) FROM task_counts WHERE state='done'").fetchone()[0]
                                bar.total = reserved_cost(db)
                                bar.refresh()
                                heartbeat = time.monotonic()
                        if pool_error:
                            break
                        for task,exp in jobs:
                            try:
                                if task["kind"] == "trajectory":
                                    used = {t["cancel_slot"] for t in pending.values() if "cancel_slot" in t}
                                    slot = next(i for i in range(capacity) if i not in used)
                                    cancel_flags[slot] = 0
                                    task["cancel_slot"] = slot
                                function = execute_audit if task["kind"]=="audit" else execute_cancellable
                                directory = root if task["kind"]=="audit" else root/"source"
                                pending[pool.submit(function,task,exp,manifest,str(directory))] = task
                            except BrokenProcessPool as exc:
                                pool_error = repr(exc)
                                break
                        if pool_error:
                            break
                        coordinated = controller_tick(root,manifest,worker_id)
                        if not pending:
                            if _STOP:
                                break
                            if not coordinated:
                                coordinated = controller_tick(root,manifest,worker_id)
                            with database(root) as db:
                                active = db.execute("SELECT COALESCE(SUM(n),0) FROM task_counts WHERE state IN ('ready','running','waiting_reuse')").fetchone()[0]
                                active += db.execute("SELECT COUNT(*) FROM audits WHERE state IN ('ready','running')").fetchone()[0]
                            if coordinated and not active:
                                break
                            time.sleep(.25)
                        else:
                            wait(pending,timeout=.25,return_when=FIRST_COMPLETED)
                finally:
                    pool.shutdown(wait=True,cancel_futures=True)
                if pool_error is None:
                    break
                repairs += 1
                with database(root) as db:
                    for table in ("tasks","audits"):
                        db.execute(f"UPDATE {table} SET state='ready',owner=NULL WHERE state='running' AND owner=?",(worker_id,))
                    event = dict(owner=worker_id,error=pool_error,recovery=repairs,next_workers=max(1,capacity//2),time=time.time())
                    history = get(db,"meta","pool_recoveries") or []
                    put(db,"meta","pool_recoveries",history+[event])
                    if repairs > RUNTIME["pool_recoveries"]:
                        put(db,"meta","last_worker_error",event)
                if repairs > RUNTIME["pool_recoveries"] or _STOP:
                    break
                capacity = max(1,capacity//2)
        controller_tick(root,manifest,worker_id,force=True)
    with database(root) as db:
        report = summary(db,manifest)
    atomic_json(root/"status.json",report)
    return report


def export_progress(root):
    path = Path(__file__).with_name("progress.py")
    spec = importlib.util.spec_from_file_location("ctmc_progress", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.export(sys.modules[__name__], root)


def export(root):
    return export_progress(root)


def main(argv=None):
    parser=argparse.ArgumentParser(description='Focused CTMC convergence and fixed-sample production')
    sub=parser.add_subparsers(dest='command',required=True)
    prep=sub.add_parser('prepare');prep.add_argument('--root',required=True);prep.add_argument('--spec',required=True);prep.add_argument('--kernel',required=True);prep.add_argument('--execution-check',action='store_true')
    for command in ('run','status','export'):
        child=sub.add_parser(command);child.add_argument('--root',required=True)
        if command=='run':
            child.add_argument('--workers',type=int,required=True);child.add_argument('--worker-id',required=True)
            child.add_argument('--max-seconds',type=float,default=0);child.add_argument('--allocation-phase',default='manual',choices=['manual'])
    args=parser.parse_args(argv)
    if args.command=='prepare':
        spec=json.loads(Path(args.spec).read_text())
        result=prepare(args.root,args.kernel,spec['projectile'],spec['energies_keV_u'],Controls(**spec['controls']),Policy(**spec['policy']),spec['seed'],execution_check=args.execution_check,energy_scaled_flight=spec.get('energy_scaled_flight',True))
    elif args.command=='run': result=run(args.root,args.workers,args.worker_id,max_seconds=args.max_seconds,allocation_phase=args.allocation_phase)
    elif args.command=='export': result=export(args.root)
    else:
        manifest=verify(args.root)
        with database(args.root) as db: result=summary(db,manifest)
    print(canonical(result))


if __name__ == "__main__":
    main()
