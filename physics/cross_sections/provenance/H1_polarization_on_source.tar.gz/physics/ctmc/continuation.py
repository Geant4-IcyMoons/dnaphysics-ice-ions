"""Checkpoint collision solves without censoring or redrawing slow trajectories.

The native kernels save complete accepted-step state. The independent reference
uses SciPy RK45 and the retained Cartesian equations, including the original
minimum-time interpolation and outward-boundary event. Checkpoints are ordinary
JSON values and remain tied to the complete trajectory configuration.
"""
from __future__ import annotations

from dataclasses import asdict
import copy
import hashlib
import importlib
import json
import math
import time

import numpy as np


def warm_native_backend(kernel, *, backend_module=None):
    """Compile every production argument signature before concurrent workers.

    The PBS controller holds the shared cache lock around this function.
    Compilation uses typed dummy arguments and executes no trajectory.
    Both fresh and resumed signatures are necessary: their optional checkpoint
    arguments have distinct native interfaces. Core arrays match the immutable
    arrays returned by the production kernel.
    """
    from numba import typeof
    from llvmlite.binding import get_host_cpu_name
    from tqdm import tqdm

    if backend_module is None:
        backend_module = importlib.import_module(kernel.integrate_relative_dop853.__module__)
    target, projectile = kernel._trajectory_cores(0, "target")
    common = [np.zeros(12, dtype=np.float64), 1.,
        kernel._cached_core_parameters(target), kernel._cached_core_parameters(projectile),
        1e-8, 1e-10, math.inf, 1e-10,
        float(kernel.WATER_MASS_AU), float(kernel.PROJECTILE_MASS_AU)]
    specifications = []
    for floating, integral in ((None, None),
            (np.zeros(29, dtype=np.float64), np.zeros(5, dtype=np.int64))):
        specifications.append(("_integrate_relative_dop853_segment",
            (*common, 100000, False, 1., 1, floating, integral, 1e-6)))
        specifications.append(("_integrate_relative_dop853_regularized_segment",
            (*common, 1, 1e-6, 100000, False, 1., 1, floating, integral)))
    started = time.monotonic()
    compiled = []
    for name, arguments in tqdm(specifications, desc="CTMC native cache", unit="signature", leave=False):
        signature = tuple(typeof(value) for value in arguments)
        getattr(backend_module, name).compile(signature)
        compiled.append(dict(function=name, signature=str(signature)))
    return dict(cpu=str(get_host_cpu_name()), signatures=compiled,
                seconds=time.monotonic()-started)

VERSION = 2


def _json(value):
    if isinstance(value, np.ndarray):
        return _json(value.tolist())
    if isinstance(value, np.generic):
        return _json(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return "Infinity" if value > 0 else "-Infinity" if value < 0 else "NaN"
    if isinstance(value, dict):
        return {k: _json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json(v) for v in value]
    return value


def _signature(payload):
    return hashlib.sha256(json.dumps(_json(payload), sort_keys=True,
                                    separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _trajectory_payload(*, energy_keV_u, charge_state, impact_parameter_au,
                        bound_to, binding_eV, start_separation_au,
                        minimum_integration_time_au, config,
                        fixed_time_endpoint=False, projectile_velocity_override_au=None,
                        minimum_terminal_core_separation_au=None,
                        garvey_role_term=False, reference_method="RK45"):
    return dict(energy_keV_u=energy_keV_u, charge_state=charge_state,
        impact_parameter_au=impact_parameter_au, bound_to=bound_to, binding_eV=binding_eV,
        start_separation_au=start_separation_au, minimum_integration_time_au=minimum_integration_time_au,
        config=asdict(config), fixed_time_endpoint=fixed_time_endpoint,
        projectile_velocity_override_au=projectile_velocity_override_au,
        minimum_terminal_core_separation_au=minimum_terminal_core_separation_au,
        garvey_role_term=garvey_role_term, reference_method=reference_method)


def upgrade_trajectory_checkpoint(checkpoint, **trajectory_parameters):
    """Explicitly upgrade a reviewed V1 prefix without integrating or redrawing.

    This migration entry verifies the entire old configuration, omitting only
    the new extension-count setting. Ordinary production resume never calls it.
    All existing numerical values and solver state are preserved verbatim.
    """
    payload = _trajectory_payload(**trajectory_parameters)
    previous = dict(payload, config=dict(payload["config"]))
    previous["config"].pop("maximum_boundary_extensions")
    if (checkpoint.get("version") != 1
            or checkpoint.get("signature") != _signature(previous)):
        raise ValueError("Incompatible V1 trajectory checkpoint")
    if ("terminal" in checkpoint or not isinstance(checkpoint.get("work"), dict)
            or "boundary_extensions" in checkpoint["work"]):
        raise ValueError("V1 checkpoint already contains boundary-extension metadata")
    upgraded = copy.deepcopy(checkpoint)
    upgraded.update(version=VERSION, signature=_signature(payload),
                    terminal=payload["minimum_terminal_core_separation_au"])
    upgraded["work"]["boundary_extensions"] = 0
    return upgraded


def _new_work():
    return dict(accepted_steps=0, rejected_steps=0, rhs_evaluations=0,
                restore_rhs_evaluations=0, integrator_attempts=0,
                boundary_extensions=0)


def _add_work(total, new):
    for key in _new_work():
        total[key] += int(new.get(key, 0))


def checkpoint_progress(checkpoint):
    """Small heartbeat view; numerical continuation remains in the checkpoint."""
    solver = checkpoint.get("solver")
    view = dict(integrator_attempt=int(checkpoint["attempt"]),
                initial_energy_au=checkpoint["initial_energy"])
    if solver is None:
        view.update(phase="retry_boundary", physical_time_au=0.)
    elif "floating" in solver:
        view.update(phase="native", physical_time_au=solver["floating"][24],
                    accepted_steps=solver["integral"][0], rejected_steps=solver["integral"][1])
    else:
        view.update(phase="reference_" + solver["phase"],
                    physical_time_au=(solver["solver"]["t"] if solver.get("solver") else solver["elapsed"]))
    return view


_SCIPY_ARRAYS = ("y", "atol", "f", "K", "y_old")
_SCIPY_SCALARS = ("t", "t_old", "t_bound", "direction", "h_abs", "h_previous",
                  "nfev", "njev", "nlu", "status")


def _save_rk45(solver):
    return {name: _json(getattr(solver, name))
            for name in _SCIPY_ARRAYS + _SCIPY_SCALARS}


def _restore_rk45(fun, saved, rtol, atol, max_step):
    from scipy.integrate import RK45
    # Construction binds SciPy's call counters to this process. Its single RHS
    # evaluation is counted separately; the saved numerical state replaces it.
    solver = RK45(fun, saved["t"], np.asarray(saved["y"]), saved["t_bound"],
                  rtol=rtol, atol=atol, max_step=max_step,
                  first_step=min(saved["h_abs"], abs(saved["t_bound"] - saved["t"])))
    extra_rhs = solver.nfev
    for name in _SCIPY_SCALARS:
        setattr(solver, name, saved[name])
    for name in _SCIPY_ARRAYS:
        value = saved[name]
        setattr(solver, name, None if value is None else np.asarray(value, dtype=float))
    return solver, extra_rhs


def _scipy_segment(kernel, initial, minimum_time, target_core, projectile_core,
                   minimum_radius, rtol, atol, max_step, fixed_time, terminal,
                   segment_steps, continuation, cancel_check=None):
    """One bounded RK45 segment, retaining SciPy's accepted state and event root."""
    from scipy.integrate import RK45
    from scipy.integrate._ivp.ivp import solve_event_equation

    work = _new_work()
    def fun(t, y):
        if cancel_check is not None:
            cancel_check()
        return kernel._three_body_rhs(t, y, target_core, projectile_core, minimum_radius)
    positions, velocities = initial[:9].reshape(3, 3), initial[9:].reshape(3, 3)
    displacement = positions[1] - positions[0]
    initial_distance = float(np.linalg.norm(displacement))
    terminal = initial_distance if terminal is None else float(terminal)
    interval = initial_distance / max(float(np.linalg.norm(velocities[1] - velocities[0])),
                                      np.finfo(float).tiny)

    def event(t, y):
        p = y[:9].reshape(3, 3)
        return float(np.linalg.norm(p[1] - p[0]) - terminal)

    saved = continuation or dict(phase="minimum" if minimum_time > 0 else "boundary",
                                  elapsed=0., state=initial.tolist(), solver=None)
    phase, elapsed = saved["phase"], float(saved["elapsed"])
    state = np.asarray(saved["state"], dtype=float)
    solver = None
    if saved.get("solver") is not None:
        solver, extra = _restore_rk45(fun, saved["solver"], rtol, atol, max_step)
        work["restore_rhs_evaluations"] += extra
    remaining = segment_steps
    while True:
        if phase == "boundary":
            if fixed_time or kernel._cores_are_separated_and_receding(state, terminal):
                return dict(status="done", state=state, work=work,
                    continuation=dict(phase="boundary", elapsed=elapsed,
                                      state=state.tolist(), solver=None))
            phase = "flight"
        if remaining <= 0:
            return dict(status="yielded", continuation=dict(phase=phase, elapsed=elapsed,
                        state=state.tolist(), solver=None if solver is None else _save_rk45(solver)),
                        work=work)
        if solver is None:
            end = minimum_time if phase == "minimum" else elapsed + interval
            if not math.isfinite(end) or end <= elapsed:
                return dict(status="done", state=None, work=work)
            solver = RK45(fun, elapsed, state, end, rtol=rtol, atol=atol, max_step=max_step)
            work["rhs_evaluations"] += solver.nfev
        before_nfev = solver.nfev
        previous_t = solver.t
        previous_event = event(solver.t, solver.y) if phase == "flight" else None
        solver.step()
        evaluations = solver.nfev - before_nfev
        work["rhs_evaluations"] += evaluations
        attempts = max(1, evaluations // 6)
        # SciPy step() owns its rejected trials. Yield between complete solver
        # steps, so N+N calls reproduce one 2N-call prefix exactly; telemetry
        # also reports the additional internal rejections.
        remaining -= 1
        if solver.status == "failed":
            work["rejected_steps"] += attempts
            return dict(status="done", state=None, work=work)
        work["accepted_steps"] += 1
        work["rejected_steps"] += max(0, attempts - 1)
        if phase == "flight":
            current_event = event(solver.t, solver.y)
            if previous_event <= 0 and current_event >= 0:
                dense = solver.dense_output()
                event_time = solve_event_equation(event, dense, previous_t, solver.t)
                endpoint = np.asarray(dense(event_time))
                return dict(status="done", state=endpoint, work=work,
                    continuation=dict(phase="boundary", elapsed=event_time,
                                      state=endpoint.tolist(), solver=None))
        if solver.status == "finished":
            elapsed = solver.t
            # solve_ivp(t_eval=[minimum_time]) uses dense interpolation even at
            # t_bound. Preserve its rounding before the next restarted flight.
            state = (np.asarray(solver.dense_output()(solver.t)) if phase == "minimum"
                     else solver.y.copy())
            phase = "boundary" if phase == "minimum" else "flight"
            solver = None
        # While the solver is live, state/elapsed retain the interval start.
        # Its accepted current state is stored separately in solver checkpoint.


def _native_segment(backend, initial, minimum_time, reference_parameters,
                    other_parameters, rtol, atol, max_step, minimum_radius,
                    reference_mass, other_mass, maximum_steps, fixed_time,
                    terminal, sundman_power, energy_drift, segment_steps,
                    continuation):
    # A single scalar interface keeps all workers on the precompiled cache
    # signatures, including manifests that spell an integral time as an int.
    args = [initial, float(minimum_time), reference_parameters, other_parameters,
            float(rtol), float(atol), float(max_step), float(minimum_radius),
            float(reference_mass), float(other_mass)]
    name = "_integrate_relative_dop853_segment"
    if sundman_power:
        name = "_integrate_relative_dop853_regularized_segment"
        args.extend([int(sundman_power), float(energy_drift)])
    args.extend([int(maximum_steps), bool(fixed_time),
                 -1. if terminal is None else float(terminal), int(segment_steps)])
    if continuation is None:
        floating, integral = None, None
        prior_accepted = prior_rejected = 0
    else:
        floating = np.asarray(continuation["floating"], dtype=np.float64)
        integral = np.asarray(continuation["integral"], dtype=np.int64)
        if floating.shape != (29,) or integral.shape != (5,):
            raise ValueError("Malformed native integration checkpoint")
        prior_accepted, prior_rejected = int(integral[0]), int(integral[1])
    kwargs = {} if sundman_power else dict(maximum_relative_energy_drift=float(energy_drift))
    result = getattr(backend, name)(*args, floating, integral, **kwargs)
    status, state, accepted, rejected, floating, integral = result
    work = _new_work()
    work["accepted_steps"] = int(accepted) - prior_accepted
    work["rejected_steps"] = int(rejected) - prior_rejected
    if status == 2:
        return dict(status="yielded", continuation=dict(floating=floating.tolist(),
                     integral=integral.tolist()), work=work)
    return dict(status="done", state=state if status == 1 else None, work=work,
                continuation=None if status != 1 else dict(
                    floating=floating.tolist(), integral=integral.tolist()))


def simulate_one_trajectory_segment(
    kernel, *, energy_keV_u, charge_state, impact_parameter_au, bound_to,
    binding_eV, start_separation_au, minimum_integration_time_au, config, rng,
    fixed_time_endpoint=False, retain_ambiguous_endpoint=False,
    projectile_velocity_override_au=None, minimum_terminal_core_separation_au=None,
    garvey_role_term=False, continuation=None, segment_steps=100000,
    backend_module=None, reference_method="RK45",
    cancel_check=None,
):
    """Advance the identical sampled trajectory, yielding without an outcome.

    A both-bound endpoint can continue outward without rebuilding the incoming
    collision. Olson and Salop (1977), p. 533, extend the few dangling-electron
    trajectories to larger outgoing separations. The configured extension count
    is a resource limit, not a physical-accuracy guarantee; remaining ambiguity
    is returned explicitly. No incomplete state enters an estimator.
    """
    if not isinstance(segment_steps, int) or isinstance(segment_steps, bool) or segment_steps < 1:
        raise ValueError("segment_steps must be a positive integer")
    if not retain_ambiguous_endpoint:
        raise ValueError("Segmented qualification requires retain_ambiguous_endpoint=True")
    if (not isinstance(config.maximum_boundary_extensions, int)
            or isinstance(config.maximum_boundary_extensions, bool)
            or config.maximum_boundary_extensions < 0):
        raise ValueError("maximum_boundary_extensions must be a nonnegative integer")
    if (config.maximum_boundary_extensions and
            (not math.isfinite(config.boundary_extension_factor)
             or config.boundary_extension_factor <= 1)):
        raise ValueError("boundary_extension_factor must exceed one")
    if config.backend == "scipy" and reference_method != "RK45":
        raise ValueError("The independent segmented reference is RK45")
    payload = _trajectory_payload(energy_keV_u=energy_keV_u, charge_state=charge_state,
        impact_parameter_au=impact_parameter_au, bound_to=bound_to, binding_eV=binding_eV,
        start_separation_au=start_separation_au, minimum_integration_time_au=minimum_integration_time_au,
        config=config, fixed_time_endpoint=fixed_time_endpoint,
        projectile_velocity_override_au=projectile_velocity_override_au,
        minimum_terminal_core_separation_au=minimum_terminal_core_separation_au,
        garvey_role_term=garvey_role_term, reference_method=reference_method)
    signature = _signature(payload)
    if continuation is not None:
        if continuation.get("version") != VERSION or continuation.get("signature") != signature:
            raise ValueError("Incompatible trajectory checkpoint")
        saved = dict(continuation)
        saved["work"] = dict(saved["work"])
    else:
        saved = dict(version=VERSION, signature=signature, attempt=0, solver=None,
                     best_state=None, best_drift=None, had_finite_endpoint=False,
                     terminal=minimum_terminal_core_separation_au, work=_new_work())
    q = int(charge_state)
    if bound_to == "projectile" and q not in kernel.PROJECTILE_OUTER_ORBITAL:
        return dict(status="done", result=["retained_target", True, 0.], work=saved["work"])
    target_core, projectile_core = kernel._trajectory_cores(q, bound_to, garvey_role_term)
    reference_core, other_core = ((target_core, projectile_core) if bound_to == "target"
                                  else (projectile_core, target_core))
    reference_mass, other_mass = ((kernel.WATER_MASS_AU, kernel.PROJECTILE_MASS_AU)
                                  if bound_to == "target" else
                                  (kernel.PROJECTILE_MASS_AU, kernel.WATER_MASS_AU))
    if continuation is None:
        initial = kernel._build_initial_relative_state(
            energy_keV_u=energy_keV_u, impact_parameter_au=impact_parameter_au,
            separation_au=start_separation_au, bound_to=bound_to, binding_eV=binding_eV,
            target_core=target_core, projectile_core=projectile_core,
            radial_grid_points=config.radial_grid_points, rng=rng,
            projectile_velocity_override_au=projectile_velocity_override_au,
            initial_ensemble=config.initial_ensemble,
            projectile_loss_initialization=config.projectile_loss_initialization)
        saved["initial"] = initial.tolist()
        saved["initial_energy"] = float(kernel.relative_three_body_energy(
            initial, target_core, projectile_core, config.minimum_radius_au, bound_to))
    initial = np.asarray(saved["initial"], dtype=float)
    if initial.shape != (12,) or not np.isfinite(initial).all():
        raise ValueError("Invalid saved initial state")
    tolerance_pairs = tuple(dict.fromkeys(((config.rtol, config.atol),
        (config.retry_rtol, config.retry_atol), (.1 * config.retry_rtol, .1 * config.retry_atol))))
    ladder = [(0, config.maximum_integration_steps, *pair) for pair in tolerance_pairs]
    if config.backend == "numba":
        ladder.extend((power, config.maximum_integration_steps, *pair)
                      for power in (1, 2) for pair in tolerance_pairs)
        if config.maximum_integration_steps > 0:
            ladder.extend((power, 0, *pair) for power in (1, 2) for pair in tolerance_pairs)
        if backend_module is None:
            backend_module = importlib.import_module(kernel.integrate_relative_dop853.__module__)
    elif config.backend != "scipy":
        raise ValueError(f"Unknown backend {config.backend}")
    remaining = segment_steps
    while True:
        while saved["attempt"] < len(ladder):
            if remaining <= 0:
                return dict(status="yielded", continuation=saved, work=saved["work"])
            power, maximum_steps, rtol, atol = ladder[saved["attempt"]]
            if saved["solver"] is None:
                saved["work"]["integrator_attempts"] += 1
            if config.backend == "numba":
                result = _native_segment(backend_module, initial, minimum_integration_time_au,
                    kernel._cached_core_parameters(reference_core), kernel._cached_core_parameters(other_core),
                    rtol, atol, config.max_step_au, config.minimum_radius_au, reference_mass, other_mass,
                    maximum_steps, fixed_time_endpoint, saved["terminal"],
                    power, config.maximum_relative_energy_drift, remaining, saved["solver"])
            else:
                result = _scipy_segment(kernel, kernel._relative_to_state(initial, bound_to),
                    minimum_integration_time_au, target_core, projectile_core, config.minimum_radius_au,
                    rtol, atol, config.max_step_au, fixed_time_endpoint,
                    saved["terminal"], remaining, saved["solver"], cancel_check)
            _add_work(saved["work"], result["work"])
            remaining -= max(1, result["work"]["accepted_steps"] + result["work"]["rejected_steps"])
            if result["status"] == "yielded":
                saved["solver"] = result["continuation"]
                return dict(status="yielded", continuation=saved, work=saved["work"])
            saved["solver"] = None
            candidate = result["state"]
            if candidate is not None and np.isfinite(candidate).all():
                if config.backend == "scipy":
                    candidate = kernel._state_to_relative_coordinates(candidate, bound_to)
                energy = kernel.relative_three_body_energy(candidate, target_core, projectile_core,
                                                           config.minimum_radius_au, bound_to)
                drift = abs(energy - saved["initial_energy"]) / max(abs(saved["initial_energy"]), 1.)
                saved["had_finite_endpoint"] = True
                if math.isfinite(drift) and (saved["best_drift"] is None or drift <= saved["best_drift"]):
                    saved["best_state"], saved["best_drift"] = candidate.tolist(), float(drift)
                if drift <= config.maximum_relative_energy_drift:
                    break
            saved["attempt"] += 1
        if not saved["had_finite_endpoint"]:
            return dict(status="done", result=["integration_failure", False, math.inf], work=saved["work"])
        if saved["best_drift"] is None or saved["best_drift"] > config.maximum_relative_energy_drift:
            return dict(status="done", result=["energy_conservation_failure", False,
                        math.inf if saved["best_drift"] is None else saved["best_drift"]], work=saved["work"])
        final = np.asarray(saved["best_state"])
        target_index, projectile_index = (0, 1) if bound_to == "target" else (1, 0)
        et = kernel._electron_core_energy_relative(final, target_index, target_core,
                                                   kernel.WATER_MASS_AU, config.minimum_radius_au)
        ep = kernel._electron_core_energy_relative(final, projectile_index, projectile_core,
                                                   kernel.PROJECTILE_MASS_AU, config.minimum_radius_au)
        outcome = ("ionized" if et > 0 and ep > 0 else
                   "captured_projectile" if ep <= 0 and et > 0 else
                   "retained_target" if et <= 0 and ep > 0 else "ambiguous_bound")
        if (outcome != "ambiguous_bound" or fixed_time_endpoint
                or saved["work"]["boundary_extensions"] >= config.maximum_boundary_extensions):
            return dict(status="done", result=[outcome, True, saved["best_drift"]], work=saved["work"])
        # The minimum-time endpoint can already lie beyond the requested
        # distance. Extend from the actual separation to guarantee progress.
        distance = float(np.linalg.norm(final[:3]))
        terminal = max(distance, saved["terminal"] or 0.) * config.boundary_extension_factor
        if not math.isfinite(terminal) or terminal <= distance:
            return dict(status="done", result=[outcome, True, saved["best_drift"]], work=saved["work"])
        if result.get("continuation") is None:
            raise ValueError("An ambiguous endpoint lacks its accepted solver checkpoint")
        saved.update(terminal=terminal, solver=result["continuation"],
                     best_state=None, best_drift=None, had_finite_endpoint=False)
        saved["work"]["boundary_extensions"] += 1
