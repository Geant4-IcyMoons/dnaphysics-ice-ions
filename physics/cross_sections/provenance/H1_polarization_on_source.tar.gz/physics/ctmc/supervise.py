"""Keep useful, checkpointed CTMC workers admitted through supported PBS queues.

This controller owns allocation only. The signed production engine owns case
advancement, numerical checks, random streams, and the trajectory budget.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys
import time

SCHEMA = 2
TERMINAL = {"F", "X"}
WAITING = {"Q", "H", "W", "T"}
ROUTES = {"idle": "idlex", "p72": "publicx"}
PROGRESS_EXPORT_INTERVAL = 60.
MAX_PROGRESS_EXPORT_DEFERRAL = 5 * PROGRESS_EXPORT_INTERVAL


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    with temporary.open("w") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def verify_revision(path, expected_hash=None):
    if expected_hash is not None and file_hash(path) != expected_hash:
        raise ValueError("The allocation's fixed runtime revision changed")
    revision = json.loads(Path(path).read_text())
    if revision.get("schema") != 1 or not revision.get("files"):
        raise ValueError("Invalid frozen runtime revision")
    launcher = str(Path(revision["launcher"]).resolve())
    if launcher not in revision["files"]:
        raise ValueError("Launcher is absent from the frozen hashes")
    for filename, expected in revision["files"].items():
        if not Path(filename).is_absolute() or file_hash(filename) != expected:
            raise ValueError(f"Runtime revision hash mismatch: {filename}")
    return revision


def install_engine(revision, root):
    spec = importlib.util.spec_from_file_location("ctmc_production_launcher", revision["launcher"])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.install(Path(root))


@contextmanager
def exclusive(path):
    with Path(path).open("a+") as stream:
        fcntl.lockf(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


def stop_requested(path, record):
    return bool(record.get("stop_requested") or Path(path).with_suffix(".stop").exists()
                or (Path(record["production_root"])/"STOP").exists())


def request_stop(path):
    """A durable sentinel cannot be lost to a concurrent journal replacement."""
    path = Path(path).resolve()
    record = json.loads(path.read_text())
    if record.get("schema") != SCHEMA:
        raise ValueError("Unsupported allocation journal")
    sentinel = path.with_suffix(".stop")
    with sentinel.open("a") as stream:
        stream.flush()
        os.fsync(stream.fileno())
    return dict(stop_requested=True, sentinel=str(sentinel))


def initialize(production_root, revision_path, predecessors, *, total_cpus=10000,
               workers=256, memory_gb=128, queues=("idle", "p72"), min_workers=16,
               worker_step=4, max_worker_failures=20, walltime_seconds=72*3600,
               poll_seconds=20, max_submissions_per_tick=8, journal=None):
    """Write a reviewable journal; this function never submits or cancels jobs."""
    root, revision_path = Path(production_root).resolve(), Path(revision_path).resolve()
    verify_revision(revision_path)
    integers = (total_cpus, workers, memory_gb, min_workers, worker_step,
                max_worker_failures, max_submissions_per_tick)
    if any(isinstance(x, bool) or not isinstance(x, int) or x < 1 for x in integers):
        raise ValueError("Invalid CPU allocation or failure limit")
    if min_workers > workers or not 1800 < walltime_seconds <= 72*3600:
        raise ValueError("Invalid worker bounds or walltime")
    if not 1 <= poll_seconds <= 60 or not queues or any(q not in ROUTES for q in queues):
        raise ValueError("Unsupported queue route or polling interval")
    path = Path(journal).resolve() if journal else root.parent/"runtime/rolling_pool.json"
    if path.exists():
        raise ValueError("Allocation journal exists; resume the controller instead")
    manifest = json.loads((root/"manifest.json").read_text())
    workflow = manifest.get("workflow", {})
    if not isinstance(workflow, dict) or workflow.get("name") != "literature_pilot_production_v1":
        raise ValueError("Supervisor requires a literature_pilot_production_v1 checkpoint")
    path.parent.mkdir(parents=True, exist_ok=True)
    (root/"logs").mkdir(exist_ok=True)
    record = dict(schema=SCHEMA, created=time.time(), updated=time.time(), status="prepared",
        production_root=str(root), signature=manifest["signature"], revision=str(revision_path),
        revision_sha256=file_hash(revision_path), predecessors=list(dict.fromkeys(predecessors)),
        predecessors_verified=False, settings=dict(total_cpus=total_cpus, workers=workers,
            memory_gb=memory_gb, queues=list(dict.fromkeys(queues)), min_workers=min_workers,
            worker_step=worker_step, max_worker_failures=max_worker_failures,
            walltime_seconds=walltime_seconds, poll_seconds=poll_seconds,
            max_submissions_per_tick=max_submissions_per_tick), slots=[], worker_failures=[],
        controller_submissions=[], stop_requested=False)
    atomic_json(path, record)
    return path


def memory_gib(value):
    match = re.fullmatch(r"([0-9.]+)([kmgt]?b)", str(value).lower())
    if not match:
        raise ValueError(f"Unrecognized PBS memory value: {value}")
    return float(match[1])*{"b":2**-30, "kb":2**-20, "mb":2**-10, "gb":1, "tb":1024}[match[2]]


def free_hosts(nodes):
    """Use vnode restrictions, never a host's misleading '<various>' summary."""
    hosts = {}
    for name, node in nodes.items():
        state = node.get("state", "")
        if any(s in state for s in ("down", "offline", "stale", "unknown", "resv-exclusive")):
            continue
        available, assigned = node.get("resources_available", {}), node.get("resources_assigned", {})
        cpus = max(0, int(available.get("ncpus", 0))-int(assigned.get("ncpus", 0)))
        memory = max(0., memory_gib(available.get("mem", "0b"))-memory_gib(assigned.get("mem", "0b")))
        allowed = available.get("allowed_queues", "").split(",")
        routes = tuple(route for route, queue in ROUTES.items() if queue in allowed)
        if not cpus or not routes:
            continue
        # Different access restrictions on vnodes of one host stay separate.
        key = (available.get("host", name), routes)
        host = hosts.setdefault(key, dict(host=key[0], queues=list(routes), cpus=0, memory_gb=0.))
        host["cpus"] += cpus
        host["memory_gb"] += memory
    return list(hosts.values())


class PBS:
    @staticmethod
    def query(command):
        response = subprocess.run(command, capture_output=True, text=True, timeout=30)
        if response.returncode:
            raise RuntimeError("Cannot reconcile PBS: " + response.stderr.strip())
        return json.loads(response.stdout)

    def jobs(self, ids=None):
        if ids == []:
            return {}
        command = ["qstat", "-x", "-f", "-F", "json", *ids] if ids is not None else [
            "qstat", "-t", "-f", "-F", "json"]
        result = self.query(command).get("Jobs", {})
        if ids is not None and any(job not in result for job in ids):
            raise RuntimeError("PBS omitted a recorded job; reconciliation required")
        return result

    def capacity(self, routes):
        queues = self.query(["qstat", "-Qf", "-F", "json"])["Queue"]
        jobs = self.jobs()
        admission = {}
        for route in routes:
            destination = ROUTES[route]
            if queues[route].get("route_destinations") != destination:
                raise RuntimeError(f"PBS route {route} changed destination")
            if any(str(queues[q].get(k)).lower() != "true" for q in (route, destination)
                   for k in ("enabled", "started")):
                admission[route] = dict(available=0, reason="queue_disabled")
                continue
            threshold = queues[destination].get("queued_jobs_threshold", "")
            match = re.search(r"u:PBS_GENERIC=(\d+)", threshold)
            if not match:
                raise RuntimeError(f"Unrecognized admission limit for {destination}")
            limit = int(match[1])
            queued = sum(1 for key, job in jobs.items() if "[]" not in key
                and job.get("Job_Owner", "").startswith(os.environ["USER"]+"@")
                and job.get("queue") in (route, destination) and job.get("job_state") in WAITING)
            admission[route] = dict(limit=limit, queued=queued, available=max(0, limit-queued))
        nodes = self.query(["pbsnodes", "-av", "-F", "json"])["nodes"]
        return dict(admission=admission, hosts=free_hosts(nodes))

    def submit(self, command, script):
        return subprocess.run(command, input=script, capture_output=True, text=True, timeout=60)

    def retire(self, job_id, queued):
        return subprocess.run(["qdel", job_id] if queued else ["qsig", "-s", "SIGUSR1", job_id],
            capture_output=True, text=True, timeout=30)


def save(path, record):
    record["updated"] = time.time()
    atomic_json(path, record)


def submit_once(path, record, receipt, scheduler):
    """Persist intent before submission. An ambiguous receipt is never retried."""
    if receipt.get("status"):
        raise RuntimeError("Submission already attempted; inspect its receipt")
    receipt.update(status="submission_attempted", attempted=time.time())
    save(path, record)
    try:
        response = scheduler.submit(receipt["command"], receipt["script"])
    except (subprocess.TimeoutExpired, OSError) as exc:
        receipt.update(status="submission_ambiguous", error=repr(exc))
        save(path, record)
        raise RuntimeError("Ambiguous PBS submission; automatic retry refused") from exc
    receipt.update(returncode=response.returncode, stdout=response.stdout, stderr=response.stderr)
    job_id = response.stdout.strip()
    if response.returncode:
        receipt["status"] = "submission_failed"
    elif not job_id or len(job_id.split()) != 1 or "." not in job_id:
        receipt["status"] = "submission_ambiguous"
    else:
        receipt.update(status="submitted", job_id=job_id, job_state="Q")
    save(path, record)
    if receipt["status"] != "submitted":
        raise RuntimeError("PBS submission did not produce an unambiguous job receipt")


def walltime(seconds):
    return f"{seconds//3600:02d}:{seconds//60%60:02d}:{seconds%60:02d}"


def worker_receipt(path, record, slot, program):
    generation = slot["allocations_used"]
    worker_id = f"production_{slot['id']}_{generation}"
    args = [sys.executable, "-B", str(program), "worker", "--journal", str(path),
        "--slot", str(slot["id"]), "--allocation", str(generation), "--worker-id", worker_id]
    command = ["qsub", "-N", "CTMC_prod", "-q", slot["queue"], "-r", "y", "-l",
        f"select=1:ncpus={slot['workers']}:mem={slot['memory_gb']}gb", "-l",
        f"walltime={walltime(record['settings']['walltime_seconds'])}", "-j", "oe", "-o",
        str(Path(record["production_root"])/"logs")]
    return dict(allocation=generation, worker_id=worker_id, workers=slot["workers"],
        memory_gb=slot["memory_gb"], queue=slot["queue"], production_root=record["production_root"],
        program_sha256=file_hash(program), command=command,
        script="#!/bin/bash\nset -euo pipefail\nexec " + shlex.join(args) + "\n")


def active_receipts(record):
    return [s for slot in record["slots"] for s in slot["submissions"]
            if s.get("status") == "submitted" and not s.get("terminal")]


def reconcile(path, record, scheduler):
    if any(s.get("status") != "submitted" for slot in record["slots"] for s in slot["submissions"]):
        raise RuntimeError("An unresolved worker submission requires inspection")
    if not record["predecessors_verified"]:
        previous = scheduler.jobs(record["predecessors"])
        if any(v["job_state"] not in TERMINAL for v in previous.values()):
            record["status"] = "waiting_for_predecessors"
            save(path, record)
            return False
        record["predecessors_verified"] = True
        record["predecessor_states"] = {k:v["job_state"] for k,v in previous.items()}
    receipts = active_receipts(record)
    jobs = scheduler.jobs([s["job_id"] for s in receipts])
    for receipt in receipts:
        job = jobs[receipt["job_id"]]
        receipt["job_state"] = job["job_state"]
        if job["job_state"] in TERMINAL:
            receipt.update(terminal=True, finished=time.time(), exit_status=job.get("Exit_status"))
            if job.get("Exit_status") != 0 and not receipt.get("retirement_attempted"):
                record["worker_failures"].append(dict(job_id=receipt["job_id"],
                    exit_status=job.get("Exit_status"), time=time.time()))
    record["running_worker_cpus"] = sum(s["workers"] for s in active_receipts(record) if s["job_state"] == "R")
    record["allocated_worker_cpus"] = sum(s["workers"] for s in active_receipts(record))
    save(path, record)
    return True


def fit(host, settings, remaining):
    memory_per_cpu = settings["memory_gb"]/settings["workers"]
    cpus = min(host["cpus"], remaining, settings["workers"], int(host["memory_gb"]/memory_per_cpu))
    if cpus >= settings["min_workers"]:
        cpus -= cpus % settings["worker_step"]
    elif cpus != remaining:
        return 0
    return cpus if cpus and host["memory_gb"] >= max(2, math.ceil(cpus*memory_per_cpu)) else 0


def replenish(path, record, scheduler, program, useful_workers=None):
    settings, active = record["settings"], active_receipts(record)
    reserved = sum(s["workers"] for s in active)
    if reserved > settings["total_cpus"]:
        raise RuntimeError("Recorded CPU allocation exceeds the approved cap")
    target = settings["total_cpus"] if useful_workers is None else min(settings["total_cpus"], useful_workers)
    if reserved >= target:
        return
    capacity = scheduler.capacity(settings["queues"])
    admission, hosts = capacity["admission"], capacity["hosts"]
    record["admission"] = admission
    # Queued requests are already reserved against the CPU cap. Conservatively
    # subtract their possible placements from this snapshot of currently free nodes.
    for receipt in active:
        if receipt.get("job_state") not in WAITING:
            continue
        candidates = [h for h in hosts if receipt["queue"] in h["queues"]
            and h["cpus"] >= receipt["workers"] and h["memory_gb"] >= receipt["memory_gb"]]
        if candidates:
            h = min(candidates, key=lambda h:h["cpus"])
            h["cpus"] -= receipt["workers"]
            h["memory_gb"] -= receipt["memory_gb"]
    for _ in range(settings["max_submissions_per_tick"]):
        remaining = target-reserved
        if not remaining:
            break
        candidates = [(fit(h, settings, remaining), -settings["queues"].index(route), route, h)
            for h in hosts for route in settings["queues"] if route in h["queues"]
            and admission[route]["available"] > 0 and (route != "p72" or remaining >= 8)]
        candidates = [c for c in candidates if c[0]]
        if candidates:
            n, _, route, host = max(candidates, key=lambda c:(c[0], c[1]))
        else:
            # Keep one modest request waiting in each admitted route, so the
            # scheduler can start us when a node frees between polling intervals.
            routes = [q for q in settings["queues"] if admission[q]["available"] > 0 and (q != "p72" or remaining >= 8)
                and not any(s["queue"] == q and s.get("job_state") in WAITING for s in active_receipts(record))]
            if not routes:
                break
            route, host = routes[0], None
            n = min(32, settings["workers"], remaining)
        slot = next((s for s in record["slots"] if s["submissions"][-1].get("terminal")), None)
        if slot is None:
            slot = dict(id=len(record["slots"]), allocations_used=0, submissions=[])
            record["slots"].append(slot)
        memory = max(2, math.ceil(settings["memory_gb"]*n/settings["workers"]))
        slot.update(workers=n, memory_gb=memory, queue=route)
        receipt = worker_receipt(path, record, slot, program)
        slot["submissions"].append(receipt)
        slot["allocations_used"] += 1
        submit_once(path, record, receipt, scheduler)
        reserved += n
        admission[route]["available"] -= 1
        if host is not None:
            host["cpus"] -= n
            host["memory_gb"] -= memory
    record["allocated_worker_cpus"] = reserved
    save(path, record)


def request_drain(path, record, scheduler):
    for receipt in active_receipts(record):
        state = receipt.get("job_state")
        if state not in WAITING | {"R"} or receipt.get("retirement_attempted"):
            continue
        receipt["retirement_attempted"] = time.time()
        save(path, record)
        response = scheduler.retire(receipt["job_id"], queued=state != "R")
        receipt["retirement_result"] = dict(returncode=response.returncode,
            stdout=response.stdout, stderr=response.stderr)
        save(path, record)
        if response.returncode:
            state = scheduler.jobs([receipt["job_id"]])[receipt["job_id"]]["job_state"]
            if state in TERMINAL:
                receipt.update(terminal=True, finished=time.time(), retirement_reconciled=True)
                save(path, record)
            elif state != "E":
                raise RuntimeError("Cannot verify retirement; reconcile PBS before retrying")


def fresh_status(root, signature):
    """Read recent atomic coordinator output without entering the task ledger."""
    try:
        report = json.loads((Path(root)/"status.json").read_text())
    except (OSError, ValueError):
        return None
    if not isinstance(report, dict) or report.get("signature") != signature:
        return None
    runtime = report.get("runtime")
    last_control = runtime.get("last_control") if isinstance(runtime, dict) else None
    if (isinstance(last_control, bool) or not isinstance(last_control, (int, float))
            or not math.isfinite(last_control) or not 0 <= time.time()-last_control <= 60):
        return None
    if report.get("status") not in {"running", "complete", "execution_error", "infeasible", "budget_exhausted", "blocked"}:
        return None
    if any(not isinstance(report.get(k), bool) for k in ("stop_requested", "campaign_complete", "production_table_ready")):
        return None
    for field in ("qualified_cases", "total_cases", "completed_collision_trajectories"):
        value = report.get(field)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            return None
    if report["qualified_cases"] > report["total_cases"] or "worker_error" not in report:
        return None
    for table in ("tasks", "audits"):
        counts = report.get(table)
        if not isinstance(counts, dict) or any(not isinstance(k, str) or isinstance(n, bool)
                or not isinstance(n, int) or n < 0 for k, n in counts.items()):
            return None
    return report


def phase_report(q, root):
    manifest = q.verify(root)
    report = fresh_status(root, manifest["signature"])
    if report is not None:
        return report
    q.controller_tick(root, manifest, "production_controller", force=True)
    with q.database(root) as db:
        report = q.summary(db, manifest)
        report["stop_requested"] = bool(q.get(db, "meta", "stop_requested"))
    return report


def try_export_progress(q, root, *, blocking=False):
    """Defer routine exports; an overdue export takes an ordinary ledger turn."""
    with (Path(root)/"database.lock").open("a+") as lock:
        try:
            fcntl.lockf(lock, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        except BlockingIOError:
            return False
        try:
            # The engine's lock is process-owned, so its nested acquisition is
            # immediate. Its database context retains normal commit semantics.
            q.export_progress(root)
        finally:
            fcntl.lockf(lock, fcntl.LOCK_UN)
    return True


def decision(report):
    if report.get("stop_requested"):
        return "stopped"
    if report.get("production_table_ready"):
        return "qualified"
    if report.get("campaign_complete") or report.get("status") == "complete":
        return "complete"
    if report.get("worker_error") or report.get("status") in {"infeasible", "budget_exhausted", "blocked", "execution_error"}:
        return "blocked"
    actionable = sum(report.get(table, {}).get(state, 0)
        for table in ("tasks", "audits") for state in ("ready", "running", "waiting_reuse"))
    return "running" if actionable else "blocked"


def tick(path, record, scheduler, program, q):
    record["stop_requested"] = stop_requested(path, record)
    if not reconcile(path, record, scheduler):
        return record["status"]
    root = Path(record["production_root"])
    report = phase_report(q, root)
    if time.time()-record.get("last_progress_export", 0) >= PROGRESS_EXPORT_INTERVAL:
        deferred_since = record.get("progress_export_deferred", {}).get("since", time.time())
        try:
            exported = try_export_progress(q, root,
                blocking=time.time()-deferred_since >= MAX_PROGRESS_EXPORT_DEFERRAL)
        except Exception as exc:
            record["progress_export_error"] = dict(time=time.time(), error=repr(exc))
            record["last_progress_export"] = time.time()
            print("CTMC provisional export failed: " + repr(exc), file=sys.stderr, flush=True)
        else:
            if exported:
                record.pop("progress_export_error", None)
                record.pop("progress_export_deferred", None)
                record["last_progress_export"] = time.time()
            else:
                record["progress_export_deferred"] = dict(time=time.time(), since=deferred_since,
                    reason="database_busy")
    action = "stopped" if record.get("stop_requested") else decision(report)
    if len(record["worker_failures"]) >= record["settings"]["max_worker_failures"]:
        action = "worker_failure_limit"
    record["phase_report"] = {k:report.get(k) for k in ("qualified_cases", "total_cases",
        "completed_collision_trajectories", "tasks", "audits", "worker_error", "limits", "status")}
    record["status"] = action
    save(path, record)
    if action == "running":
        useful = sum(report.get(table, {}).get(state, 0)
            for table in ("tasks", "audits") for state in ("ready", "running"))
        replenish(path, record, scheduler, program, useful_workers=useful)
        return action
    request_drain(path, record, scheduler)
    if active_receipts(record):
        return "draining"
    if action in {"qualified", "complete"}:
        q.export(root)
    return action


def schedule_controller_successor(path, record, scheduler, program):
    current = os.environ["PBS_JOBID"]
    existing = [s for s in record["controller_submissions"] if s.get("predecessor") == current]
    if existing:
        if existing[0].get("status") != "submitted":
            raise RuntimeError("Controller successor submission is ambiguous")
        return
    admission = scheduler.capacity(record["settings"]["queues"])["admission"]
    available = [route for route in record["settings"]["queues"] if admission[route]["available"] > 0]
    if not available:
        raise RuntimeError("No queue headroom for the controller successor")
    route = available[0]
    cpus = 2 if route == "idle" else 8  # p72 has an eight-CPU queue minimum.
    args = [sys.executable, "-B", str(program), "controller", "--journal", str(path)]
    receipt = dict(predecessor=current, command=["qsub", "-N", "CTMC_manage", "-q", route, "-r", "y",
        "-l", f"select=1:ncpus={cpus}:mem=4gb", "-l", "walltime=72:00:00", "-W",
        "depend=afterany:"+current, "-j", "oe", "-o", str(path.parent)],
        script="#!/bin/bash\nset -euo pipefail\nexec " + shlex.join(args) + "\n")
    record["controller_submissions"].append(receipt)
    submit_once(path, record, receipt, scheduler)


def controller(path):
    if "PBS_JOBID" not in os.environ:
        raise RuntimeError("The persistent supervisor requires a PBS compute allocation")
    from tqdm import tqdm
    path, program, scheduler = Path(path).resolve(), Path(__file__).resolve(), PBS()
    started, program_hash = time.monotonic(), file_hash(program)
    with exclusive(path.with_suffix(".lock")):
        record = json.loads(path.read_text())
        if record.get("schema") != SCHEMA:
            raise ValueError("Unsupported allocation journal")
        revision = verify_revision(record["revision"], record["revision_sha256"])
        q = install_engine(revision, record["production_root"])
        if q.verify(Path(record["production_root"]))["signature"] != record["signature"]:
            raise ValueError("Production checkpoint signature changed")
        with tqdm(desc="CTMC cases qualified", total=0, unit="case", mininterval=30) as bar:
            while True:
                if file_hash(program) != program_hash:
                    raise ValueError("Running supervisor source changed")
                record["stop_requested"] = stop_requested(path, record) or json.loads(path.read_text()).get("stop_requested", False)
                verify_revision(record["revision"], record["revision_sha256"])
                result = tick(path, record, scheduler, program, q)
                report = record.get("phase_report", {})
                bar.n, bar.total = report.get("qualified_cases") or 0, report.get("total_cases") or 0
                bar.set_postfix(status=result, running_cpus=record.get("running_worker_cpus", 0),
                    allocated_cpus=record.get("allocated_worker_cpus", 0))
                bar.refresh()
                if result in {"stopped", "blocked", "qualified", "complete", "worker_failure_limit"}:
                    return record
                if time.monotonic()-started >= 70*3600:
                    schedule_controller_successor(path, record, scheduler, program)
                    return record
                time.sleep(record["settings"]["poll_seconds"])


def worker(path, slot_id, allocation, worker_id):
    """Start one persistent pool and drain it before this allocation's walltime."""
    if "PBS_JOBID" not in os.environ:
        raise RuntimeError("Trajectory workers require a PBS compute allocation")
    path, started = Path(path).resolve(), time.monotonic()
    child, stopping = None, False
    def stop(signum, frame):
        nonlocal stopping
        stopping = True
        if child is not None and child.poll() is None:
            child.send_signal(signal.SIGUSR1)
    for sig in (signal.SIGUSR1, signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, stop)
    while True:
        record = json.loads(path.read_text())
        slot = record["slots"][slot_id]
        receipt = next((s for s in slot["submissions"] if s["allocation"] == allocation), None)
        if receipt is None or receipt["worker_id"] != worker_id:
            raise ValueError("Worker allocation is absent from its journal")
        if receipt.get("status") == "submission_attempted" and time.monotonic()-started < 30:
            time.sleep(1)
            continue
        break
    if receipt.get("job_id") != os.environ["PBS_JOBID"]:
        raise ValueError("Worker PBS identity differs from its allocation receipt")
    if receipt.get("program_sha256") != file_hash(__file__):
        raise ValueError("Supervisor source differs from its allocation receipt")
    if receipt["workers"] > int(os.environ.get("PBS_NCPUS", os.cpu_count() or 1)):
        raise ValueError("Worker count exceeds its PBS allocation")
    if stopping or stop_requested(path, record) or record["status"] in {
            "qualified", "complete", "blocked", "stopped", "worker_failure_limit"}:
        return
    revision = verify_revision(record["revision"], record["revision_sha256"])
    seconds = record["settings"]["walltime_seconds"]-(time.monotonic()-started)-900
    if seconds <= 0:
        return
    command = [sys.executable, "-B", revision["launcher"], "run", "--root", record["production_root"],
        "--workers", str(receipt["workers"]), "--worker-id", worker_id,
        "--max-seconds", str(seconds), "--allocation-phase", "manual"]
    child = subprocess.Popen(command)
    if stopping:
        child.send_signal(signal.SIGUSR1)
    while True:
        try:
            code = child.wait(timeout=record["settings"]["poll_seconds"])
            break
        except subprocess.TimeoutExpired:
            if not stopping and stop_requested(path, record):
                stop(None, None)
    if code:
        raise RuntimeError(f"CTMC invocation failed with exit status {code}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    for action in ("controller", "worker", "stop"):
        p = sub.add_parser(action)
        p.add_argument("--journal", required=True, type=Path)
        if action == "worker":
            p.add_argument("--slot", required=True, type=int)
            p.add_argument("--allocation", required=True, type=int)
            p.add_argument("--worker-id", required=True)
    args = parser.parse_args()
    if args.action == "controller":
        controller(args.journal)
    elif args.action == "stop":
        print(json.dumps(request_stop(args.journal)))
    else:
        worker(args.journal, args.slot, args.allocation, args.worker_id)


if __name__ == "__main__":
    main()
