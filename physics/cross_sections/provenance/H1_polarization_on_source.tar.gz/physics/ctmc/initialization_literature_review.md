# CTMC initialization: literature and implementation comparison

Reviewed 2026-09-13. The active implementation combines established
microcanonical phase-space sampling with the standard finite-mass inverse
centre-of-mass transformation for the projectile-bound electron and core.
This is supported at the level of distributions and coordinate equations;
it is not a claim that a published carbon–water calculation duplicates the
complete implementation or establishes its experimental accuracy.

## Explicit sampling precedent

Kovács et al., Physical Review A 94, 012704 (2016), equations (7)–(12),
describe the Reinhold–Falcón construction for a central potential before
extending it to molecular potentials. They specify separate uniformly
distributed position and momentum polar cosines and azimuths, and obtain
radius by inversion of an integrated radial density. The reduced mass is
included in the momentum magnitude and radial integral. This is explicit
published support for independently isotropic angular sampling and inverse
radial-integral sampling.

- DOI: https://doi.org/10.1103/PhysRevA.94.012704
- Author-uploaded full text inspected:
  https://www.researchgate.net/publication/305486365_Ionization_of_small_molecules_induced_byH_He_andNprojectiles_Comparison_of_experiment_with_quantum_and_classical_calculations

Reinhold & Falcón's original reference is Physical Review A 33, 3859–3866
(1986), https://doi.org/10.1103/PhysRevA.33.3859. Its bibliographic record was
verified, but the original publisher PDF was inaccessible in this review.
The equation comparison above therefore uses the accessible 2016 paper's
explicit presentation, not a claimed inspection of the 1986 original.

Sarkadi, Physical Review A 97, 042703 (2018), also explicitly employs the
Reinhold–Falcón procedure for standard microcanonical calculations and studies
modified, energy-mixture ensembles. This is additional use of the method,
not proof that a single classical ensemble is universally most accurate.
Full text inspected: https://real.mtak.hu/90900/1/PhysRevA.97.042703.pdf

## Mapping to the frozen sampler

In `runs/carbon_production/source/charge_exchange_ctmc.py`,
`_microcanonical_radius_cdf` (line 992) constructs a normalized numerical
integral with weight r^2 sqrt(2[E-V(r)]), where E=-I. The published radial
weight includes a constant factor mu^(3/2); it cancels upon normalization
for a fixed electron–core pair. A cached grid, trapezoidal quadrature and
linear inverse interpolation approximate this same CDF. These numerical
choices are implementation details, not new physical distributions.

`sample_bound_electron` (line 1065) samples the position angles independently
of the momentum angles, with each polar cosine uniform on [-1,1] and each
azimuth uniform on [0,2pi). It sets p=sqrt(2 mu [E-V(r)]) and relative
velocity u=p/mu. This matches the central-potential construction above.
The finite grid has numerical error; algebraic equivalence is not an
independent numerical validation of that quadrature.

## COM precedent and algebraic comparison

Whitehead, McCann & Shimamura, Physical Review A 64, 023401 (2001), section II
and equations (2.1)–(2.4), uses Jacobi coordinates built from the mass-weighted
centre of a bound pair, finite reduced masses, and microcanonical initial
bound states. The paper uses orbital variables for Coulomb systems, rather
than our screened-potential inverse-CDF implementation. It establishes the
combination of microcanonical CTMC and finite-mass COM mechanics.
Full text inspected: https://www2.riken.jp/ap/publication/files/whitehead_PRA64.pdf

Our algebraic comparison: for core mass M, electron mass m, sampled relative
position r and relative velocity u, the inverse COM transformation is

    r_core = R - m/(M+m) r       r_e = R + M/(M+m) r
    v_core = V - m/(M+m) u       v_e = V + M/(M+m) u.

These are exactly the projectile-bound initialization equations implemented
at lines 1306–1333 of the frozen kernel. Substitution gives the specified
COM position R and velocity V; the internal momentum sums to zero. This
equivalence is a direct algebraic deduction from the published coordinates,
not a quotation of identical code or a carbon-specific validation.

The label `projectile_ion_com_balanced` applies to the active electron–core
pair in projectile-loss trajectories. It must not be described as a full
simultaneous many-electron carbon COM initialization, or as proof that every
target initialization branch is separately COM balanced.

## Active-run verification and conclusion

The manifest selects `independent_isotropic_sensitivity` and
`projectile_ion_com_balanced`. Frozen `qualify.py` lines 460–461 passes these
settings to the configuration; `continuation.py` lines 359–360 passes them
to trajectory initialization. All frozen source hashes matched the manifest
during this review. Manifest signature:
`9cf49ac4f100c3098534f095a5e74176b8eedd3a197e0bef240c972af1a9afb9`.

Retain the initialization. Its distribution and projectile COM transformation
have an established basis. Do not claim universal superiority over tangent
sampling, exact replication of Liamsuwan, or experimental validation of the
screened potentials, IEVM/IPM approximation and cross sections from this
comparison. No production code, settings or jobs were changed, and no new
collision simulations were performed for this literature review.
