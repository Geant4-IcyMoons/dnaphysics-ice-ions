"""Atomic cross-section and equilibrium products with explicit numerical limits."""
import csv
import io
import json
import os
import time
import zlib
from pathlib import Path


def rows_from_audits(q,cases,experiments,audits):
    latest={}
    for audit in audits:
        report=audit['report']
        if 'mean' not in report or 'standard_error' not in report: continue
        old=latest.get(audit['experiment'])
        if old is None or sum(report['samples'])>sum(old['report']['samples']):
            latest[audit['experiment']]=audit
    rows=[]
    for case in sorted(cases,key=lambda c:(c['energy'],c['charge'])):
        certificate=case.get('certificate',{})
        row=dict(energy_keV_u=case['energy'],charge_state=case['charge'],case_status=case['status'],
            qualification='qualified' if case['status']=='qualified' else 'complete_with_limits' if case['status']=='complete' else 'provisional',
            precision_met=certificate.get('precision_met',False),
            numerical_qualification_met=certificate.get('numerical_qualification_met',False),
            stage='',experiment='',packet_samples='',audit_status='',audit_id='',
            source_assessment_revision='',source_execution_revision='')
        for name in q.MEASURE_NAMES:
            for suffix in ('_cm2','_standard_error_cm2','_zero_event_upper_cm2'):
                row[name+suffix]=''
        row.update({'control_'+k:v for k,v in case['controls'].items()})
        candidates=[]
        for stage,eid in case['experiments'].items():
            if eid not in latest: continue
            exp=experiments[eid]
            if exp['arms'][0]!=case['controls']: raise ValueError('Estimate belongs to another numerical design')
            candidates.append((stage=='production',sum(latest[eid]['report']['samples']),eid,stage))
        if candidates:
            _,_,eid,stage=max(candidates);audit=latest[eid];report=audit['report']
            row.update(stage=stage,experiment=eid,packet_samples=sum(report['samples']),audit_status=report['status'],
                audit_id=audit.get('id',''),source_assessment_revision=report.get('assessment_revision',''),
                source_execution_revision=report.get('execution_revision',''))
            for i,name in enumerate(q.MEASURE_NAMES):
                row[name+'_cm2']=report['mean'][0][i]
                row[name+'_standard_error_cm2']=report['standard_error'][0][i]
                limits=report.get('zero_upper_limit')
                if limits and limits[0][i] is not None: row[name+'_zero_event_upper_cm2']=limits[0][i]
        rows.append(row)
    return rows


def write_csv(path,rows):
    if not rows: return
    buffer=io.StringIO();writer=csv.DictWriter(buffer,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
    content=buffer.getvalue()
    if path.exists() and path.read_text()==content: return
    tmp=path.with_name(path.name+f'.{os.getpid()}.tmp')
    with tmp.open('w') as stream:
        stream.write(content);stream.flush();os.fsync(stream.fileno())
    os.replace(tmp,path)


def export(q,root):
    root=Path(root);manifest=q.verify(root)
    with q.database(root) as db:
        cases=[json.loads(r[0]) for r in db.execute('SELECT payload FROM cases')]
        experiments={r[0]:json.loads(r[1]) for r in db.execute('SELECT id,payload FROM experiments')}
        raw=db.execute("SELECT experiment,result,id FROM audits WHERE state='done'").fetchall()
        q.staged_workflow(manifest).assess_fractions(q,db,manifest,manifest['energies'])
        fractions=q.get(db,'meta','fractions') or {}
        summary=q.summary(db,manifest)
    audits=[dict(experiment=r[0],report=json.loads(zlib.decompress(r[1])),id=r[2]) for r in raw]
    # Synchronous verification/test audits retain the same report in the design.
    audits.extend(dict(experiment=eid,report=exp['report']) for eid,exp in experiments.items() if exp.get('report'))
    rows=rows_from_audits(q,cases,experiments,audits)
    write_csv(root/'current_cross_sections.csv',rows)
    fraction_rows=[]
    for energy in manifest['energies']:
        result=fractions.get(float(energy).hex())
        if result is None: continue
        for charge in range(manifest['nuclear_charge']+1):
            fraction_rows.append(dict(energy_keV_u=energy,charge_state=charge,status=result['status'],
                fraction='' if result.get('mean') is None else result['mean'][charge],
                standard_error='' if result.get('mean') is None else result['standard_error'][charge],
                mean_charge=result.get('mean_charge',''),mean_charge_standard_error=result.get('mean_charge_standard_error','')))
    write_csv(root/'equilibrium_fractions.csv',fraction_rows)
    record=dict(schema='com_ctmc_literature_1',updated=time.time(),manifest_signature=manifest['signature'],
        complete=summary['campaign_complete'],qualified=summary['production_table_ready'],
        completed_cases=summary['completed_cases'],qualified_cases=summary['qualified_cases'],total_cases=len(cases),
        rows_with_estimates=sum(bool(r['experiment']) for r in rows),
        scope='Fixed-grid CTMC estimates. Production uses samples independent of settings selection. Numerical checks cover tested finite settings only. Errors are estimated Monte Carlo standard errors; zero-event limits are reported separately. Numerical/statistical limitations are explicit; no physical-model or campaign-wide confidence guarantee.',
        cross_sections='current_cross_sections.csv',equilibrium='equilibrium_fractions.csv' if fraction_rows else None)
    q.atomic_json(root/'current_cross_sections.json',record)
    if summary['campaign_complete']:
        final=dict(record,cases=cases,cross_sections=rows,equilibrium=fractions,
                   source_hashes=manifest['sources'],configuration=manifest)
        q.atomic_json(root/'production_table.json',final)
        write_csv(root/'cross_sections.csv',rows)
    return record
