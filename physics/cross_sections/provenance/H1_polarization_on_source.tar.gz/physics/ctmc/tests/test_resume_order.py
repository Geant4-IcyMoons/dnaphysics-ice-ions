"""The indexed checkpoint queue preserves the old timing-join order."""
import ast
import inspect
import sqlite3
import zlib

import pytest

from physics.ctmc import qualify as Q


OLD = "SELECT t.id FROM tasks t JOIN task_progress p ON p.task=t.id WHERE t.state='ready' AND t.resuming=1 ORDER BY p.updated,t.id"
QUERY = next(node.value for node in ast.walk(ast.parse(inspect.getsource(Q.claim_trajectory_tasks)))
             if isinstance(node, ast.Constant) and isinstance(node.value, str)
             and "INDEXED BY tasks_ready_resume_updated" in node.value)


@pytest.fixture
def ledger():
    db = sqlite3.connect(":memory:")
    db.row_factory = sqlite3.Row
    for table in ("cases", "experiments", "meta"):
        db.execute(f"CREATE TABLE {table}(id TEXT PRIMARY KEY,payload TEXT NOT NULL)")
    db.execute("CREATE TABLE tasks(id TEXT PRIMARY KEY,experiment TEXT,stratum INTEGER,start INTEGER,count INTEGER,cost INTEGER,state TEXT,owner TEXT,result BLOB,resuming INTEGER NOT NULL DEFAULT 0)")
    db.execute("CREATE TABLE task_progress(task TEXT PRIMARY KEY,experiment TEXT,started REAL,updated REAL NOT NULL,segments INTEGER DEFAULT 0,seconds REAL DEFAULT 0,payload TEXT)")
    db.execute("CREATE TABLE task_counts(stage TEXT,state TEXT,n INTEGER,cost INTEGER,PRIMARY KEY(stage,state))")
    Q.put(db, "cases", "case", dict(status="sampling", experiments={"bmax": "exp"}))
    Q.put(db, "experiments", "exp", dict(id="exp", case="case", stage="bmax", status="sampling", targets=[32], completed=[0]))
    yield db
    db.close()


def seed(db, entries):
    for i, (identity, state, resuming, updated) in enumerate(entries):
        db.execute("INSERT INTO tasks VALUES(?, 'exp',0,?,1,10,?,?,?,?)",
                   (identity, i, state, "orphan" if state == "running" else None,
                    zlib.compress(Q.canonical(dict(physical_sample=identity)).encode()), resuming))
        if updated is not None:
            db.execute("INSERT INTO task_progress(task,experiment,started,updated) VALUES(?,'exp',0,?)", (identity, updated))
    db.execute("INSERT INTO task_counts SELECT 'bmax',state,COUNT(*),SUM(cost) FROM tasks GROUP BY state")
    db.commit()


def identifiers(db):
    old = [r[0] for r in db.execute(OLD)]
    new = [r["id"] for r in db.execute(QUERY, (1000,))]
    assert new == old
    return new


def test_legacy_backfill_preserves_payloads_counts_ties_and_future_requeues(ledger):
    db = ledger
    seed(db, [("z", "ready", 1, 2.), ("a", "ready", 1, 2.),
              ("running", "running", 1, 1.), ("cancelled", "cancelled", 1, .5),
              ("missing", "ready", 1, None), ("history", "done", 1, 0.),
              ("fresh", "ready", 0, 0.)])
    before = list(map(tuple, db.execute("SELECT * FROM tasks ORDER BY id")))
    counts = list(map(tuple, db.execute("SELECT * FROM task_counts ORDER BY state")))
    Q.initialize_runtime(db)
    assert [tuple(r)[:-1] for r in db.execute("SELECT * FROM tasks ORDER BY id")] == before
    assert list(map(tuple, db.execute("SELECT * FROM task_counts ORDER BY state"))) == counts
    assert identifiers(db) == ["a", "z"]
    db.execute("UPDATE tasks SET state='ready',owner=NULL WHERE id IN ('running','cancelled')")
    assert identifiers(db) == ["cancelled", "running", "a", "z"]
    plan = " ".join(str(tuple(r)) for r in db.execute("EXPLAIN QUERY PLAN " + QUERY, (1,)))
    assert "tasks_ready_resume_updated" in plan and "TEMP B-TREE" not in plan
    assert "task_progress" not in plan


def test_restart_after_column_add_and_repeated_initialization(ledger):
    db = ledger
    seed(db, [("older", "ready", 1, 1.), ("newer", "ready", 1, 2.)])
    # A stopped migration may leave the column before its transactional backfill.
    db.execute("ALTER TABLE tasks ADD COLUMN resume_updated REAL")
    Q.initialize_runtime(db)
    assert identifiers(db) == ["older", "newer"]
    db.commit()
    statements = []
    db.set_trace_callback(statements.append)
    Q.initialize_runtime(db)
    db.set_trace_callback(None)
    assert not any(s.startswith("UPDATE tasks SET resume_updated=") for s in statements)
    assert identifiers(db) == ["older", "newer"]


def test_old_nonresuming_timing_is_retained_for_repair_without_new_telemetry(ledger):
    db = ledger
    seed(db, [("repair", "failed", 0, .5), ("waiting", "ready", 1, 1.)])
    Q.initialize_runtime(db)
    assert identifiers(db) == ["waiting"]
    # An interrupted/error-recovery path can recover a continuation without
    # recording another completed segment or refreshing its old timing row.
    db.execute("UPDATE tasks SET state='ready',resuming=1,owner=NULL WHERE id='repair'")
    assert identifiers(db) == ["repair", "waiting"]


def test_migration_can_rollback_and_retry(ledger):
    db = ledger
    seed(db, [("one", "ready", 1, 1.)])
    db.execute("BEGIN")
    Q.initialize_runtime(db)
    assert identifiers(db) == ["one"]
    db.rollback()
    assert "resume_updated" not in {r[1] for r in db.execute("PRAGMA table_info(tasks)")}
    Q.initialize_runtime(db)
    assert identifiers(db) == ["one"]


def test_telemetry_update_delete_reinsert_and_orphan_reclaim(ledger, tmp_path):
    db = ledger
    seed(db, [("first", "ready", 1, 1.), ("later", "running", 1, 2.),
              ("missing", "ready", 1, None)])
    Q.initialize_runtime(db)
    before = list(map(tuple, db.execute("SELECT * FROM task_counts ORDER BY state")))
    db.execute("UPDATE task_progress SET updated=.5 WHERE task='later'")
    db.execute("DELETE FROM task_progress WHERE task='first'")
    db.execute("INSERT INTO task_progress(task,experiment,started,updated) VALUES('missing','exp',0,.75)")
    assert list(map(tuple, db.execute("SELECT * FROM task_counts ORDER BY state"))) == before
    assert identifiers(db) == ["missing"]
    Q.reclaim_orphans(db, tmp_path, "active")
    assert identifiers(db) == ["later", "missing"]
    db.execute("INSERT INTO task_progress(task,experiment,started,updated) VALUES('first','exp',0,.25)")
    assert identifiers(db) == ["first", "later", "missing"]


def test_yielded_commit_refreshes_age_without_changing_packet_or_budget(ledger, monkeypatch):
    db = ledger
    seed(db, [("packet", "running", 1, 1.), ("waiting", "ready", 1, 2.)])
    Q.initialize_runtime(db)
    monkeypatch.setattr(Q.time, "time", lambda: 8.)
    packet = dict(db.execute("SELECT * FROM tasks WHERE id='packet'").fetchone())
    saved = dict(schema=1, task="packet", completed=[], active=None, signature="preserved")
    budget = Q.reserved_cost(db)
    Q.commit_result(db, packet, dict(yielded=saved, runtime=dict(seconds=.5, work={})), "orphan")
    row = db.execute("SELECT * FROM tasks WHERE id='packet'").fetchone()
    assert row["resume_updated"] == db.execute("SELECT updated FROM task_progress WHERE task='packet'").fetchone()[0] == 8.
    assert zlib.decompress(row["result"]).decode() == Q.canonical(dict(continuation=saved))
    assert Q.reserved_cost(db) == budget
    assert identifiers(db) == ["waiting", "packet"]


def test_existing_half_resume_quota_and_fallback_selection_remain_identical(ledger):
    db = ledger
    seed(db, [(f"task{i}", "ready", 1, float((10-i)//2)) for i in range(10)])
    Q.initialize_runtime(db)
    resumes = [r[0] for r in db.execute(OLD + " LIMIT 4")]
    fallback = [r[0] for r in db.execute("SELECT id FROM tasks WHERE state='ready' ORDER BY resuming,start,experiment,stratum") if r[0] not in resumes][:4]
    actual = Q.claim_trajectory_tasks(db, "worker", 8)
    assert [r["id"] for r in actual] == resumes + fallback
