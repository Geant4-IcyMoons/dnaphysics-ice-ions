"""Task refilling and lock-contention checks; no physical integration executes."""
from concurrent.futures import Future
from concurrent.futures.process import BrokenProcessPool
from contextlib import contextmanager
import fcntl
import json
import subprocess
import sys
import time

import pytest

from physics.ctmc.tests.test_qualification import Q, controls, policy, kernel, campaign, make, packet


def test_optional_controller_skips_busy_database_and_releases_election_lock(campaign, monkeypatch):
    root, manifest = campaign
    child = subprocess.Popen([sys.executable, '-c',
        "import fcntl,sys; f=open(sys.argv[1],'a+'); fcntl.lockf(f,fcntl.LOCK_EX); print('locked',flush=True); sys.stdin.read()",
        str(root/'database.lock')], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
    try:
        assert child.stdout.readline().strip() == 'locked'
        start = time.monotonic()
        assert Q.controller_tick(root, manifest, 'test') is False
        assert time.monotonic()-start < 1.
        result = subprocess.run([sys.executable, '-c',
            "import fcntl,sys; f=open(sys.argv[1],'a+'); fcntl.lockf(f,fcntl.LOCK_EX|fcntl.LOCK_NB)",
            str(root/'controller.lock')], capture_output=True, timeout=3)
        assert result.returncode == 0
    finally:
        child.communicate('', timeout=3)
    with Q.database(root) as db:
        Q.put(db, 'meta', 'runtime_health', dict(last_control=time.time(), control_seconds=0.))
    calls=[]
    monkeypatch.setattr(Q, 'advance', lambda *args:calls.append(True) or dict(status='running'))
    assert Q.controller_tick(root, manifest, 'test') is False
    assert not calls
    assert Q.controller_tick(root, manifest, 'test', force=True) is True
    with Q.database(root) as db:
        health=Q.get(db,'meta','runtime_health');health['last_control']=0.
        Q.put(db,'meta','runtime_health',health)
    assert Q.controller_tick(root, manifest, 'test') is True
    assert len(calls)==2


@pytest.mark.parametrize('mode', ['refill', 'stop', 'pool_error'])
def test_completed_results_commit_during_refill_stop_and_pool_failure(campaign, monkeypatch, mode):
    root, manifest = campaign
    exp=make(root,manifest,'flight')
    monkeypatch.setenv('PBS_JOBID','synthetic-ledger-test')
    monkeypatch.setenv('PBS_NCPUS','2')
    monkeypatch.setattr(Q,'load_runtime',lambda *args:None)
    monkeypatch.setattr(Q,'prepare_native_runtime',lambda *args:None)
    monkeypatch.setattr(Q,'controller_tick',lambda *args,**kwargs:True)
    monkeypatch.setattr(Q,'wait',lambda *args,**kwargs:None)
    original_database, original_commit, original_claim=Q.database,Q.commit_result,Q.claim_trajectory_tasks
    active_transaction=[];events=[];submitted=[]
    @contextmanager
    def database(*args,**kwargs):
        with original_database(*args,**kwargs) as db:
            token=object();active_transaction.append(token)
            try:yield db
            finally:active_transaction.pop()
    def commit(db,*args):
        events.append(('commit',active_transaction[-1]));return original_commit(db,*args)
    def claim(db,*args,**kwargs):
        events.append(('claim',active_transaction[-1]));return original_claim(db,*args,**kwargs)
    class Pool:
        def __init__(self,**kwargs):pass
        def submit(self,fn,task,experiment,*args):
            submitted.append(task['id']);future=Future()
            if mode=='pool_error' and len(submitted)==2:future.set_exception(BrokenProcessPool('synthetic failed child'))
            else:future.set_result(packet(experiment,task))
            if len(submitted)==(4 if mode=='refill' else 2):Q._STOP=True
            return future
        def shutdown(self,**kwargs):pass
    monkeypatch.setattr(Q,'database',database)
    monkeypatch.setattr(Q,'commit_result',commit)
    monkeypatch.setattr(Q,'claim_trajectory_tasks',claim)
    monkeypatch.setattr(Q,'ProcessPoolExecutor',Pool)
    Q.run(root,2,'test_worker')
    with original_database(root) as db:
        states={r['id']:r['state'] for r in db.execute("SELECT id,state FROM tasks WHERE id IN (%s)" % ','.join('?'*len(submitted)),submitted)}
        if mode=='pool_error':
            assert states[submitted[0]]=='done' and states[submitted[1]]=='ready'
            assert len(Q.get(db,'meta','pool_recoveries'))==1
        else:assert set(states.values())=={'done'}
    if mode=='refill':
        first_commit=next(token for event,token in events if event=='commit')
        assert ('claim',first_commit) in events
    assert len(submitted)==(4 if mode=='refill' else 2)


def test_resume_fairness_and_fallback_order_are_unchanged(campaign):
    root, manifest = campaign
    exp=make(root,manifest,'flight')
    with Q.database(root) as db:
        ids=[r[0] for r in db.execute('SELECT id FROM tasks ORDER BY id')]
        for i,task in enumerate(ids):
            db.execute("UPDATE tasks SET resuming=1 WHERE id=?",(task,))
            db.execute('INSERT INTO task_progress(task,experiment,started,updated) VALUES(?,?,?,?)',
                       (task,exp['id'],0.,float((len(ids)-i)//2)))
        resumes=[r[0] for r in db.execute("SELECT t.id FROM tasks t JOIN task_progress p ON p.task=t.id WHERE t.state='ready' AND t.resuming=1 ORDER BY p.updated,t.id LIMIT 4")]
        fallback=[r[0] for r in db.execute("SELECT id FROM tasks WHERE state='ready' ORDER BY resuming,start,experiment,stratum") if r[0] not in resumes][:4]
        assert Q.claim_trajectory_tasks(db,'test',0)==[]
        actual=Q.claim_trajectory_tasks(db,'test',8)
        assert [r['id'] for r in actual]==resumes+fallback


@pytest.mark.parametrize('late_mode', ['refill', 'stop', 'pool_error', 'runtime_error'])
def test_completion_during_lock_wait_is_handled_in_the_same_transaction(campaign, monkeypatch, late_mode):
    root, manifest = campaign
    make(root, manifest, 'flight')
    monkeypatch.setenv('PBS_JOBID', 'synthetic-ledger-test')
    monkeypatch.setenv('PBS_NCPUS', '2')
    monkeypatch.setattr(Q, 'load_runtime', lambda *args: None)
    monkeypatch.setattr(Q, 'prepare_native_runtime', lambda *args: None)
    monkeypatch.setattr(Q, 'controller_tick', lambda *args, **kwargs: True)
    monkeypatch.setattr(Q, 'wait', lambda *args, **kwargs: None)
    original_database, original_commit, original_claim = Q.database, Q.commit_result, Q.claim_trajectory_tasks
    submissions, deferred, events, transaction = [], [], [], []
    acquired = []

    @contextmanager
    def database(*args, **kwargs):
        # The outer loop saw only the first completed future. The second
        # becomes ready during the modeled wait for the exclusive DB lock.
        if deferred and not acquired:
            future, task, experiment = deferred[0]
            if late_mode == 'pool_error':
                future.set_exception(BrokenProcessPool('failed while waiting'))
            elif late_mode == 'runtime_error':
                future.set_exception(ValueError('runtime failure while waiting'))
            else:
                future.set_result(packet(experiment, task))
            if late_mode == 'stop':
                Q._STOP = True
            acquired.append(True)
        with original_database(*args, **kwargs) as db:
            token = object()
            transaction.append(token)
            if acquired == [True]:
                acquired.append(token)
            try:
                yield db
            finally:
                transaction.pop()

    def commit(db, task, result, owner):
        events.append(('commit', task['id'], transaction[-1]))
        return original_commit(db, task, result, owner)

    def claim(db, worker, slots, **kwargs):
        events.append(('claim', slots, transaction[-1]))
        return original_claim(db, worker, slots, **kwargs)

    class Pool:
        def __init__(self, **kwargs): pass
        def submit(self, fn, task, experiment, *args):
            submissions.append(task['id'])
            future = Future()
            if len(submissions) == 2:
                deferred.append((future, task, experiment))
            else:
                future.set_result(packet(experiment, task))
            if len(submissions) == 4:
                Q._STOP = True
            return future
        def shutdown(self, **kwargs):
            # Stop after the verified failed-pool recovery, without creating
            # another synthetic pool that is outside this regression's scope.
            if late_mode == 'pool_error':
                Q._STOP = True

    monkeypatch.setattr(Q, 'database', database)
    monkeypatch.setattr(Q, 'commit_result', commit)
    monkeypatch.setattr(Q, 'claim_trajectory_tasks', claim)
    monkeypatch.setattr(Q, 'ProcessPoolExecutor', Pool)
    Q.run(root, 2, 'late_worker')
    locked = acquired[1]
    assert ('commit', submissions[0], locked) in events
    if late_mode != 'pool_error':
        assert ('commit', submissions[1], locked) in events
    claims = [event for event in events if event[0] == 'claim' and event[2] is locked]
    assert claims == ([('claim', 2, locked)] if late_mode == 'refill' else [])
    assert len(submissions) == (4 if late_mode == 'refill' else 2)
    with original_database(root) as db:
        rows = db.execute("SELECT state,COUNT(*) FROM tasks WHERE id IN (%s) GROUP BY state" % ','.join('?'*len(submissions)), submissions)
        assert dict(rows) == ({'done': 4} if late_mode == 'refill' else {'done': 2} if late_mode == 'stop'
                              else {'done': 1, 'ready': 1} if late_mode == 'pool_error' else {'done': 1, 'failed': 1})


@pytest.mark.parametrize('broken_position', [0, 1])
def test_harvest_retains_successes_around_broken_future_and_never_waits(broken_position):
    class Incomplete:
        def done(self): return False
        def result(self): pytest.fail('Attempted to wait for an unfinished future')
    incomplete = Incomplete()
    pending = {incomplete: dict(id='unfinished', kind='trajectory')}
    successes = []
    for i in range(3):
        future = Future()
        task = dict(id=f'task{i}', kind='trajectory')
        if i == broken_position:
            future.set_exception(BrokenProcessPool('synthetic pool failure'))
        else:
            result = dict(yielded=dict(completed=[i], active=dict(saved_state=i)))
            future.set_result(result)
            successes.append((task, result))
        pending[future] = task
    finished, error = Q.collect_finished_tasks(pending)
    assert finished == successes and error == "BrokenProcessPool('synthetic pool failure')"
    assert list(pending) == [incomplete]


@pytest.mark.parametrize('kind', ['trajectory', 'audit'])
def test_harvest_retains_existing_runtime_exception_reports(kind):
    future = Future()
    future.set_exception(ValueError('synthetic exception'))
    task = dict(id='task', kind=kind)
    pending = {future: task}
    finished, error = Q.collect_finished_tasks(pending)
    expected = (dict(status='execution_error', error="ValueError('synthetic exception')") if kind == 'audit'
                else dict(failure=dict(outcome='execution_error', error="ValueError('synthetic exception')"), attempts=0))
    assert finished == [(task, expected)] and error is None and not pending
