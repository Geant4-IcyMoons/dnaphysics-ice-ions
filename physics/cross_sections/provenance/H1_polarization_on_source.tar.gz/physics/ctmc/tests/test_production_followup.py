"""Production informs planning but cannot substitute for a numerical comparison."""
import copy
import numpy as np
from physics.ctmc import qualify as Q
from physics.ctmc.tests.test_literature_policy import experiment,moments,assess,manifest
from physics.ctmc.tests.test_progressive_sampling import progressive


def test_zero_followup_cannot_pass_and_uses_production_variance(progressive):
    e=experiment();e['production_followup']=dict(observables=['channel_6'],mean=[0]*6+[1,0],
        raw_variances=np.zeros((2,1,8)).tolist())
    e['production_followup']['raw_variances'][0][0][6]=100
    r=assess(progressive,e,*moments(e,baseline=0))
    assert r['status']=='needs_samples'
    assert r['allocation']['planned_targets'][0]>512
    assert r['allocation']['planned_targets'][1]==512
    assert r['mean'][0][6]==0
    assert r['standard_error'][0][6]==0
    assert not r['numerical_qualification_met']
    r=assess(progressive,e,*moments(e,baseline=1,change=.01,se=.02))
    assert r['status']=='pass'


def test_production_moments_available_without_replaying_samples(progressive):
    e=experiment('production',2048);e['planned_targets']=list(e['targets'])
    r=assess(progressive,e,*moments(e,se=.02))
    assert r['stratum_raw_variances'][0][0][6]==2048*.02**2


def test_reopen_only_unobserved_checks_preserves_production(monkeypatch):
    case=dict(experiments={s:s for s in Q.STAGES});controls={'bmax':25}
    table={s:dict(id=s,arms=[controls],report=dict(numerical_status_by_observable={'decrease':'unobserved_rate' if s=='flight' else 'pass'})) for s in Q.AXES}
    production=dict(id='production',arms=[controls],targets=[2048],status='production_complete')
    report=dict(mean=[[0]*7+[1]],stratum_means=[[[0]*7+[1]]],stratum_raw_variances=[[[0]*7+[2]]])
    before=copy.deepcopy(production)
    monkeypatch.setattr(Q,'get',lambda db,t,k:copy.deepcopy(table[k]))
    monkeypatch.setattr(Q,'put',lambda db,t,k,v:table.update({k:copy.deepcopy(v)}))
    assert Q.reopen_unobserved_checks(None,{},case,production,report)
    assert production==before
    assert case['stage']=='flight'
    assert table['flight']['production_followup']['observables']==['decrease']
    assert 'production_followup' not in table['bmax']
    assert 'production_followup' not in table['solver']


def test_legacy_production_needs_only_new_moment_audit(monkeypatch):
    table={s:dict(id=s,arms=[{}],report=dict(numerical_status_by_observable={'decrease':'unobserved_rate'})) for s in Q.AXES}
    monkeypatch.setattr(Q,'get',lambda db,t,k:table[k]);monkeypatch.setattr(Q,'put',lambda *a:None)
    c=dict(experiments={s:s for s in Q.STAGES});p=dict(id='production',arms=[{}],targets=[2048])
    assert Q.reopen_unobserved_checks(None,{},c,p,dict(mean=[[0]*7+[1]]))
    assert p['targets']==[2048] and p['report'] is None and c['stage']=='production'

from physics.ctmc.tests.test_qualification import controls,policy,kernel,campaign,make


def test_followup_gets_new_audit_identity_at_same_sample_count(campaign):
    root,m=campaign;e=make(root,m,'flight')
    e['completed']=list(e['targets'])
    with Q.database(root) as db:
        Q.put(db,'meta','async_audits',True)
        first=Q.assess_experiment(db,m,e)
        e['production_followup']={'observables':['decrease']}
        second=Q.assess_experiment(db,m,e)
    assert first['audit']!=second['audit']
