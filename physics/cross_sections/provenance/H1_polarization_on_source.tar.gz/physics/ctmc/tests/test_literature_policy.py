"""Finite pilot decisions, zero-event limits and independent production planning.

Synthetic moments test the statistical contract, not CTMC physical convergence.
"""
from copy import deepcopy
from types import SimpleNamespace
import math

import numpy as np
import pytest

from physics.ctmc import staged as S


class Engine:
    MEASURE_NAMES = tuple(f"channel_{i}" for i in range(8))
    C = SimpleNamespace(BOHR2_CM2=1/math.pi)

    @staticmethod
    def production_indices(charge, nuclear_charge):
        return [6]

    @staticmethod
    def task_cost(manifest, exp, stratum, samples):
        return samples * len(exp["arms"])

    @staticmethod
    def measurement_support(exp, stratum, nuclear_charge):
        arms = len(exp["arms"])
        low = np.zeros((2*arms-1, 8))
        high = np.zeros_like(low)
        for arm in range(arms):
            high[arm, 6] = float(exp["edges"][stratum] < exp["arms"][arm]["bmax"])
        if arms > 1:
            low[arms:, 6] = -1
            high[arms:, 6] = 1
        return low, high


@pytest.fixture
def manifest():
    return dict(initialization="projectile_ion_com_balanced", nuclear_charge=6,
        energies=[10.], workflow=dict(name=S.WORKFLOW_NAME, phase="production"),
        policy=dict(confidence=.95, numerical_relative=.05, statistical_relative=.05,
            initial_samples=512, block_size=8, max_samples_per_annulus=4096, cutoff_tail_samples=10000,
            production_min_samples=2048, production_max_samples=16384,
            max_trajectories=250000000))


def experiment(stage="flight", samples=512):
    arms = [{"bmax": 1.}]
    if stage != "production":
        arms.append({"bmax": 2. if stage == "bmax" else 1.})
    edges = [0., 1., 2.] if stage == "bmax" else [0., .5, 1.]
    return dict(stage=stage, arms=arms, edges=edges, targets=[samples]*(len(edges)-1), charge=0)


def moments(exp, baseline=1., change=0., se=0.):
    arms = len(exp["arms"])
    means = np.zeros((len(exp["targets"]), 2*arms-1, 8))
    variances = np.zeros_like(means)
    means[0, 0, 6] = baseline
    if arms > 1:
        means[0, 1, 6] = baseline + change
        means[0, 2, 6] = change
        variances[0, 2, 6] = se**2
    variances[0, 0, 6] = se**2
    covariance = np.zeros((len(exp["targets"]), arms))
    return means, variances, covariance


def assess(manifest, exp, means, variances, covariance):
    return S.assess_moments(Engine, manifest, exp, means.sum(axis=0), variances,
        covariance, stratum_means=means)


def test_only_retained_stages_and_com_initialization(manifest):
    assert S.stages(manifest) == ("bmax", "flight", "solver", "production")
    manifest["initialization"] = "projectile_core"
    with pytest.raises(ValueError, match="COM-balanced"):
        S.validate_workflow(manifest)


def test_zero_event_probability_limit_is_finite_and_scales_with_support():
    expected = 1-.05**(1/1000)
    assert S.zero_event_upper(1000, 7.) == pytest.approx(7*expected)
    assert S.zero_event_upper(2000, 7.) < S.zero_event_upper(1000, 7.)
    with pytest.raises(ValueError):
        S.zero_event_upper(0, 7.)


def test_measured_numerical_stability_and_paired_standard_error(manifest):
    exp = experiment()
    report = assess(manifest, exp, *moments(exp, change=.02, se=.03))
    assert report["status"] == "pass"
    assert report["pair_standard_error"][0][6] == pytest.approx(.03)
    assert "simultaneous" in report["confidence_scope"]


def test_bad_settings_reject_without_tightening_standard_error_to_five_percent(manifest):
    exp = experiment()
    report = assess(manifest, exp, *moments(exp, change=10., se=1.))
    assert report["status"] == "resolved_change"


def test_no_infinite_sampling_ladder_after_single_planned_check(manifest):
    exp = experiment()
    data = moments(exp, change=.03, se=.10)
    initial = assess(manifest, exp, *data)
    assert initial["status"] == "needs_samples"
    assert max(initial["planned_targets"]) > 512
    exp["targets"] = initial["planned_targets"]
    exp["planned_targets"] = list(exp["targets"])
    assert assess(manifest, exp, *data)["status"] == "sampling_limit"


def test_plan_requires_matching_completed_cohort(manifest):
    exp = experiment()
    exp["planned_targets"] = [1024, 512]
    with pytest.raises(ValueError, match="saved plan"):
        assess(manifest, exp, *moments(exp))


def test_unobserved_cutoff_tail_requires_predeclared_sample_count(manifest):
    exp = experiment("bmax")
    exp["edges"] = [0., 1., 100.]
    exp["arms"][1]["bmax"] = 100.
    report = assess(manifest, exp, *moments(exp))
    assert report["status"] == "needs_samples"
    assert report["tail_evidence"]["zero_event_upper"][0] > .05
    assert report["planned_targets"][1] == 10000


def test_unobserved_tail_upper_limit_is_reported_without_absolute_release_gate(manifest):
    exp = experiment("bmax")
    exp["edges"] = [0., 1., 100.]
    exp["arms"][1]["bmax"] = 100.
    exp["targets"][1] = 10000
    report = assess(manifest, exp, *moments(exp))
    assert report["status"] == "pass"
    assert report["tail_evidence"]["tail_upper"][0] > .05
    assert report["tail_evidence"]["sample_requirement_met"]
    assert "not release gates" in report["tail_evidence"]["scope"]


def test_zero_required_rate_remains_unresolved_with_nonzero_upper_limit(manifest):
    exp = experiment()
    report = assess(manifest, exp, *moments(exp, baseline=0.))
    assert report["status"] == "pass"
    assert not report["numerical_qualification_met"]
    assert report["numerical_status_by_observable"] == {"channel_6": "unobserved_rate"}
    assert not report["precision_met"]
    assert report["zero_upper_limit"][0][6] > 0


def test_solver_pilot_freezes_separate_production_sample_count(manifest):
    exp = experiment("solver")
    report = assess(manifest, exp, *moments(exp, se=.02))
    assert report["status"] == "pass"
    assert report["production_targets"] == [2048, 2048]
    assert exp["targets"] == [512, 512]


def test_production_plan_uses_rate_variance_and_caps_rare_rates(manifest):
    exp = experiment("solver")
    means, variances, covariance = moments(exp)
    variances[0, 0, 6] = 1.
    report = assess(manifest, exp, means, variances, covariance)
    assert report["production_targets"] == [16384, 2048]


def test_fixed_production_finishes_with_honest_precision_flag(manifest):
    exp = experiment("production", 2048)
    exp["planned_targets"] = list(exp["targets"])
    report = assess(manifest, exp, *moments(exp, se=.2))
    assert report["status"] == "production_complete"
    assert not report["precision_met"]
    assert report["standard_error"][0][6] == pytest.approx(.2)


def test_zero_observed_production_is_an_upper_limit_not_precise_zero(manifest):
    exp = experiment("production", 2048)
    exp["planned_targets"] = list(exp["targets"])
    report = assess(manifest, exp, *moments(exp, baseline=0.))
    assert report["status"] == "production_complete"
    assert not report["precision_met"]
    assert report["zero_upper_limit"][0][6] > 0


def test_production_cannot_choose_its_sample_size_from_its_own_outcomes(manifest):
    exp = experiment("production")
    with pytest.raises(ValueError, match="independent solver pilot"):
        assess(manifest, exp, *moments(exp))


def test_covariance_is_retained_in_equilibrium_uncertainty():
    rates = np.array([[2., 0.], [3., 1.], [0., 4.]])
    f = S.equilibrium_fractions(rates[:-1, 0], rates[1:, 1])
    np.testing.assert_allclose(f, np.array([1., 2., 1.5])/4.5)
    covariance = np.zeros((3, 2, 2))
    covariance[1] = [[.09, .01], [.01, .04]]
    result = S.fraction_statistics(f, rates, covariance)
    assert result["mean_charge_standard_error"] > 0
    np.testing.assert_allclose(np.asarray(result["covariance"]).sum(axis=0), 0., atol=1e-14)
    with pytest.raises(ValueError, match="positive"):
        S.equilibrium_fractions([0., 1.], [1., 1.])


def test_equilibrium_log_product_avoids_intermediate_overflow():
    f = S.equilibrium_fractions([1e200, 1e200], [1e-200, 1e-200])
    np.testing.assert_array_equal(f, [0., 0., 1.])


def test_fixed_plan_rounds_to_blocks_without_doubling_oversampling():
    assert S._rounded_target(1100, 512, 4096, 8) == 1104
    assert S._rounded_target(4090, 512, 4096, 8) == 4096
    assert S._rounded_target(400, 512, 4096, 8) == 512


def test_rate_seen_in_only_one_arm_never_receives_zero_rate_exemption(manifest):
    exp = experiment("flight")
    report = assess(manifest, exp, *moments(exp, baseline=0., change=.01, se=.1))
    assert report["status"] != "pass"
    assert not report["numerical_qualification_met"]
    assert report["numerical_status_by_observable"] == {"channel_6": "unresolved_comparison"}


def test_cutoff_fixed_outer_count_does_not_expand_inner_annulus_budget(manifest):
    exp = experiment("bmax")
    report = assess(manifest, exp, *moments(exp, change=.02, se=.5))
    assert report["planned_targets"] == [4096, 10000]


def test_resolved_rate_does_not_certify_other_unobserved_required_rate(manifest):
    class BothRates(Engine):
        @staticmethod
        def production_indices(charge, nuclear_charge):
            return [6, 7]

        @staticmethod
        def measurement_support(exp, stratum, nuclear_charge):
            low, high = Engine.measurement_support(exp, stratum, nuclear_charge)
            low[:, 7] = low[:, 6]; high[:, 7] = high[:, 6]
            return low, high

    exp = experiment("solver")
    means, variances, covariance = moments(exp)
    report = S.assess_moments(BothRates, manifest, exp, means.sum(axis=0), variances,
        covariance, stratum_means=means)
    assert report["status"] == "pass"
    assert report["numerical_status_by_observable"] == {"channel_6": "pass", "channel_7": "unobserved_rate"}
    assert not report["numerical_qualification_met"]
    assert report["unresolved_observables"] == ["channel_7"]


def test_equilibrium_retains_unresolved_numerical_qualification(manifest):
    cases = [{"certificate": dict(mean=[0.]*6+rates, precision_met=True,
               numerical_qualification_met=(charge == 0), rate_covariance=np.zeros((2, 2)).tolist())}
             for charge, rates in enumerate(([2., 0.], [0., 1.]))]
    saved = {}
    engine = SimpleNamespace(case_key=lambda energy, charge: charge,
        get=lambda db, table, key: cases[key], put=lambda db, table, key, value: saved.update({key: value}))
    S.assess_fractions(engine, None, dict(manifest, nuclear_charge=1), [10.])
    result = saved["fractions"][float(10.).hex()]
    assert result["status"] == "estimated_with_limits"
    assert result["precision_met"]
    assert not result["numerical_qualification_met"]
    np.testing.assert_allclose(result["mean"], [1/3, 2/3])


def _single_capture_flight_case():
    """Retained C6@1000 moments: one baseline event in b=[0,1], sample233."""
    class CaptureRate(Engine):
        @staticmethod
        def production_indices(charge, nuclear_charge):
            return [7]

        @staticmethod
        def measurement_support(exp, stratum, nuclear_charge):
            low, high = Engine.measurement_support(exp, stratum, nuclear_charge)
            low[:, 7] = low[:, 6]; high[:, 7] = high[:, 6]
            low[:, 6] = high[:, 6] = 0
            return low, high

    exp = dict(stage="flight", arms=[{"bmax": 25.}, {"bmax": 25.}],
               edges=[0., 1., 5., 10., 20., 25.], targets=[512]*5, charge=6)
    means = np.zeros((5, 3, 8)); variances = np.zeros_like(means)
    one_event = 1.7177321126794876e-19
    means[0, 0, 7] = one_event
    means[0, 2, 7] = -one_event
    variances[0, 0, 7] = variances[0, 2, 7] = one_event**2
    return CaptureRate, exp, means, variances, np.zeros((5, 2))


def test_live_one_arm_capture_gets_bounded_enlargement_before_sampling_limit(manifest):
    engine, exp, means, variances, covariance = _single_capture_flight_case()
    report = S.assess_moments(engine, manifest, exp, means.sum(axis=0), variances,
        covariance, stratum_means=means)
    assert report["status"] == "needs_samples"
    assert report["planned_targets"] == [4096, 512, 512, 512, 512]
    assert report["allocation"]["unobserved_required_rates"] == []
    assert not report["numerical_qualification_met"]
    assert report["numerical_status_by_observable"] == {"channel_7": "unresolved_comparison"}
    assert exp["targets"] == [512]*5


def test_one_arm_capture_planning_is_invariant_under_arm_exchange(manifest):
    engine, exp, means, variances, covariance = _single_capture_flight_case()
    first = S.assess_moments(engine, manifest, exp, means.sum(axis=0), variances,
        covariance, stratum_means=means)
    swapped = means[:, [1, 0, 2]].copy()
    swapped[:, 2] *= -1
    result = S.assess_moments(engine, manifest, exp, swapped.sum(axis=0), variances[:, [1, 0, 2]],
        covariance[:, [1, 0]], stratum_means=swapped)
    assert result["planned_targets"] == first["planned_targets"]
    assert result["status"] == first["status"] == "needs_samples"
    assert result["allocation"]["unobserved_required_rates"] == []
    assert not result["numerical_qualification_met"]


def test_both_arm_zero_planning_and_unqualified_status_are_unchanged(manifest):
    engine, exp, means, variances, covariance = _single_capture_flight_case()
    means[:] = 0; variances[:] = 0
    result = S.assess_moments(engine, manifest, exp, means.sum(axis=0), variances,
        covariance, stratum_means=means)
    assert result["planned_targets"] == [512]*5
    assert result["status"] == "pass"
    assert result["allocation"]["unobserved_required_rates"] == ["channel_7"]
    assert not result["numerical_qualification_met"]


def test_one_arm_capture_cannot_create_second_enlargement(manifest):
    engine, exp, means, variances, covariance = _single_capture_flight_case()
    exp["targets"] = exp["planned_targets"] = [4096, 512, 512, 512, 512]
    # Same one event after eight times as many inner samples is still unresolved.
    means[0] /= 8; variances[0] /= 64
    result = S.assess_moments(engine, manifest, exp, means.sum(axis=0), variances,
        covariance, stratum_means=means)
    assert result["status"] == "sampling_limit"
    assert result["planned_targets"] == exp["planned_targets"]
    assert not result["numerical_qualification_met"]
