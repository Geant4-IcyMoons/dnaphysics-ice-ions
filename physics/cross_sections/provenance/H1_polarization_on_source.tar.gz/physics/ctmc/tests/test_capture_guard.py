"""Exact paired-event guard for the observed C5 zero-versus-four failure."""
import numpy as np
import pytest
from physics.ctmc import staged as S
from physics.ctmc.tests.test_literature_policy import Engine,manifest
from physics.ctmc.tests.test_progressive_sampling import progressive

class Capture(Engine):
    @staticmethod
    def production_indices(*args):return [7]
    @staticmethod
    def measurement_support(exp,stratum,z):
        low,high=Engine.measurement_support(exp,stratum,z)
        low[:,7]=low[:,6];high[:,7]=high[:,6];low[:,6]=high[:,6]=0
        return low,high

def data(k):
    n=1872
    exp=dict(stage='flight',charge=5,arms=[{'bmax':25},{'bmax':25}],
        edges=[0,1,5,10,20,25],targets=[n,512,512,512,512],reference_targets=[512]*5)
    mean=np.zeros((5,3,8));var=np.zeros_like(mean);counts=np.zeros_like(mean,dtype=int)
    mean[0,1:,7]=k/n;var[0,1:,7]=(k/n)*(1-k/n)/(n-1);counts[0,1:,7]=k
    return exp,mean,var,counts

def test_saved_four_events_remain_unresolved(progressive):
    exp,mean,var,count=data(4)
    result=S.assess_moments(Capture,progressive,exp,mean.sum(axis=0),var,np.zeros((5,2)),stratum_means=mean,stratum_nonzero=count)
    assert result['status']=='needs_samples'
    assert not result['numerical_qualification_met']
    assert result['capture_discordance_guard']['strata'][0]['pvalue']==.125
    assert result['capture_discordance_guard']['adjusted_pvalue']==.625
    assert result['allocation']['planned_targets'][0]>1872

def test_strong_one_sided_event_evidence_still_rejects(progressive):
    exp,mean,var,count=data(12)
    result=S.assess_moments(Capture,progressive,exp,mean.sum(axis=0),var,np.zeros((5,2)),stratum_means=mean,stratum_nonzero=count)
    assert result['status']=='resolved_change'

def test_guard_is_symmetric_under_arm_exchange(progressive):
    exp,mean,var,count=data(4)
    a=S.capture_discordance_guard(Capture,progressive,exp,mean,count)
    mean[:,[0,1]]=mean[:,[1,0]];mean[:,2]*=-1
    b=S.capture_discordance_guard(Capture,progressive,exp,mean,count)
    assert a['adjusted_pvalue']==b['adjusted_pvalue']

def test_inconsistent_counts_are_rejected(progressive):
    exp,mean,var,count=data(4);count[0,2,7]=3
    with pytest.raises(ValueError):S.capture_discordance_guard(Capture,progressive,exp,mean,count)
