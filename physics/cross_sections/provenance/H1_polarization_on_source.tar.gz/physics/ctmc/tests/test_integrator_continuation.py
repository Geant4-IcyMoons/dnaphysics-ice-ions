"""Exact checkpoint round trips; physical trajectories run only in PBS."""
from dataclasses import asdict, replace
import importlib.util
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pytest
from scipy.integrate import solve_ivp

from physics.ctmc import continuation as S
from physics.ctmc import qualify as Q
from physics.ctmc.tests.test_qualification import kernel, controls

COMPUTE = pytest.mark.skipif(not os.environ.get("PBS_JOBID"), reason="CTMC integration requires PBS")


def _roundtrip(value):
    return json.loads(json.dumps(value, allow_nan=False))


def test_yield_preserves_draw_retry_and_budget(kernel, controls, monkeypatch):
    cfg = Q.config_for(dict(projectile="carbon", nuclear_charge=6, seed=7,
        ensemble="independent_isotropic_sensitivity", initialization="projectile_ion_com_balanced"), asdict(controls))
    draws, calls = [], []
    def draw(**kw):
        draws.append(kw["rng"].random())
        return np.zeros(12)
    monkeypatch.setattr(kernel, "_build_initial_relative_state", draw)
    monkeypatch.setattr(kernel, "relative_three_body_energy", lambda *args: 1.)
    monkeypatch.setattr(kernel, "_electron_core_energy_relative", lambda *args: -1. if args[1] == 0 else 1.)
    def segment(*args):
        cp = args[-1]
        calls.append(cp)
        work = S._new_work()
        work["accepted_steps"] = 2
        if cp is None:
            return dict(status="yielded", continuation={"marker": "same solve"}, work=work)
        assert cp == {"marker": "same solve"}
        return dict(status="done", state=np.zeros(12), work=work)
    monkeypatch.setattr(S, "_native_segment", segment)
    kwargs = dict(energy_keV_u=100., charge_state=6, impact_parameter_au=.7,
        bound_to="target", binding_eV=kernel.WATER_ORBITALS[0].binding_eV,
        start_separation_au=20., minimum_integration_time_au=2., config=cfg,
        retain_ambiguous_endpoint=True, segment_steps=2)
    first = S.simulate_one_trajectory_segment(kernel, **kwargs, rng=np.random.default_rng(771))
    assert first["status"] == "yielded" and "result" not in first
    second = S.simulate_one_trajectory_segment(kernel, **kwargs, rng=np.random.default_rng(771),
                                               continuation=_roundtrip(first["continuation"]))
    assert second["result"] == ["retained_target", True, 0.]
    assert len(draws) == 1 and len(calls) == 2
    assert second["work"]["accepted_steps"] == 4
    assert second["work"]["integrator_attempts"] == 1


def test_reference_json_resume_preserves_interpolation_events_and_nfev(kernel, monkeypatch):
    # Artificial 18-dimensional oscillator plus straight core flight, not CTMC.
    def rhs(t, y, *args):
        d = np.zeros(18)
        d[0:9] = y[9:18]
        d[15:18] = -y[6:9]
        return d
    monkeypatch.setattr(kernel, "_three_body_rhs", rhs)
    initial = np.zeros(18)
    initial[3:6] = [0.1, 0, -2]
    initial[12:15] = [0, 0, 1]
    initial[6:9] = [.7, .3, .1]
    initial[15:18] = [.2, .1, -.2]
    kwargs = dict(kernel=kernel, initial=initial, minimum_time=.3, target_core=None,
        projectile_core=None, minimum_radius=1e-10, rtol=1e-10, atol=1e-12,
        max_step=.07, fixed_time=False, terminal=1., segment_steps=2)
    calls = []
    def observe(*args, **kw):
        kw["method"] = "RK45"
        r = solve_ivp(*args, **kw)
        calls.append(r.nfev)
        return r
    monkeypatch.setattr(kernel, "solve_ivp", observe)
    expected = kernel._integrate_scipy_until_separated(initial_state=initial,
            minimum_integration_time_au=.3, target_core=None, projectile_core=None,
            minimum_radius_au=1e-10, rtol=1e-10, atol=1e-12, max_step=.07,
            terminal_core_distance_au=1.)
    checkpoint = None
    work = S._new_work()
    for _ in range(1000):
        result = S._scipy_segment(**kwargs, continuation=checkpoint)
        S._add_work(work, result["work"])
        if result["status"] == "done":
            break
        checkpoint = _roundtrip(result["continuation"])
    else:
        pytest.fail("Reference did not complete")
    np.testing.assert_array_equal(result["state"], expected)
    assert work["rhs_evaluations"] == sum(calls)
    assert work["restore_rhs_evaluations"] > 0


def test_segmented_reference_preserves_cooperative_cancellation(kernel):
    initial = np.zeros(18)
    initial[5], initial[14] = -2., 1.
    def cancel():
        raise Q.SupersededTrajectory()
    with pytest.raises(Q.SupersededTrajectory):
        S._scipy_segment(kernel, initial, .3, None, None, 1e-10,
                         1e-9, 1e-11, np.inf, False, 1., 10, None, cancel)




@COMPUTE
@pytest.mark.parametrize("backend_name", ["numba", "scipy"])
@pytest.mark.parametrize("charge", [0, 6])
def test_trajectory_retry_and_reference_result_survive_json_resume(kernel, controls, backend_name, charge):
    cfg = Q.config_for(dict(projectile="carbon", nuclear_charge=6, seed=7,
        ensemble="independent_isotropic_sensitivity", initialization="projectile_ion_com_balanced"), asdict(controls))
    cfg = replace(cfg, backend=backend_name, maximum_integration_steps=1000000)
    kwargs = dict(energy_keV_u=100., charge_state=charge, impact_parameter_au=.7,
        bound_to="target", binding_eV=kernel.WATER_ORBITALS[0].binding_eV,
        start_separation_au=20., minimum_integration_time_au=2.,
        minimum_terminal_core_separation_au=10., config=cfg, retain_ambiguous_endpoint=True)
    direct = S.simulate_one_trajectory_segment(kernel, **kwargs,
        rng=np.random.default_rng(771), segment_steps=1000000)
    assert direct["status"] == "done"
    expected = tuple(direct["result"])
    checkpoint = None
    for _ in range(100000):
        result = S.simulate_one_trajectory_segment(kernel, **kwargs,
            rng=np.random.default_rng(771), continuation=checkpoint, segment_steps=7)
        if result["status"] == "done":
            break
        checkpoint = _roundtrip(result["continuation"])
    else:
        pytest.fail("Segmented trajectory did not complete")
    assert tuple(result["result"]) == expected
    assert checkpoint is not None
    invalid = dict(kwargs, impact_parameter_au=.71)
    with pytest.raises(ValueError, match="Incompatible"):
        S.simulate_one_trajectory_segment(kernel, **invalid, rng=np.random.default_rng(771),
                                         continuation=checkpoint, segment_steps=7)


@COMPUTE
@pytest.mark.parametrize("power", [0, 1, 2])
def test_resume_across_reference_switch(kernel, power):
    """A zero-force crossing isolates reference-frame bookkeeping exactly."""
    backend = sys.modules[kernel.integrate_relative_dop853.__module__]
    state = np.array([1., 0., 0., .25, .1, 0., 0., 0., 0., 1., 0., 0.])
    p = np.array([0., 0., 1., 1.])
    args = [state, 1., p, p, 1e-9, 1e-11, .04, 1e-10, 1836., 21868.]
    name = "integrate_relative_dop853"
    if power:
        name += "_regularized"
        args.extend([power, 1e-6])
    args.extend([100000, True, -1.])
    expected = getattr(backend, name)(*args)
    floating = integral = None
    switched = []
    for _ in range(10000):
        result = getattr(backend, "_" + name + "_segment")(*args, 1, floating, integral)
        if result[0] != 2:
            break
        floating = np.asarray(_roundtrip(result[4].tolist()))
        integral = np.asarray(_roundtrip(result[5].tolist()), dtype=np.int64)
        switched.append(int(integral[4]))
    else:
        pytest.fail("Reference switch continuation did not complete")
    assert 0 in switched and 1 in switched
    assert result[0] == 1 and expected[0]
    np.testing.assert_array_equal(result[1], expected[1])
    assert result[2:4] == expected[2:4]


