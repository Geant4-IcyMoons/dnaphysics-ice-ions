"""Production ledger and estimator regressions using synthetic electron outcomes.

These tests never integrate a trajectory. Small test cohorts exercise control
flow; they are not numerical evidence for the carbon production cross-sections.
"""
import csv
import itertools
import json
from pathlib import Path

import numpy as np
import pytest

from physics.ctmc import qualify as Q

ROOT = Path(__file__).resolve().parents[3]
RUNTIME = ROOT / "python_scripts/physics_ice"


@pytest.fixture
def controls():
    return Q.Controls(bmax=25., incoming=1000., outgoing=1000., minimum_time=1000.,
        radial=4096, rtol=1e-8, atol=1e-10, minimum_radius=1e-10,
        energy_drift=1e-6, maximum_steps=1000000)


@pytest.fixture
def policy():
    return Q.Policy(initial_samples=16, cutoff_tail_samples=32, block_size=4,
        max_samples_per_annulus=256, production_min_samples=64,
        production_max_samples=256, max_trajectories=10000000)


@pytest.fixture
def kernel():
    if not (RUNTIME / "charge_exchange_ctmc.py").exists():
        pytest.skip("The retained CTMC kernel is unavailable")
    Q.load_runtime(RUNTIME)
    yield Q.C
    Q.C.select_projectile("carbon")


@pytest.fixture
def campaign(tmp_path, controls, policy, kernel, monkeypatch):
    root = tmp_path / "campaign"
    manifest = Q.prepare(root, RUNTIME, "carbon", [50.], controls, policy, 91431,
                         execution_check=True, energy_scaled_flight=False)
    monkeypatch.setattr(Q, "initial_state_audit", lambda *args:dict(status="pass", scope="Synthetic ledger test"))
    return root, manifest


def make(root, manifest, stage="bmax", charge=3):
    with Q.database(root) as db:
        key = Q.case_key(50., charge)
        case = Q.get(db, "cases", key)
        exp = Q.make_experiment(db, manifest, key, case, stage)
        Q.schedule(db, manifest, exp)
        Q.put(db, "cases", key, case)
    return exp


def packet(exp, row, pattern="constant"):
    """Realizable SC/SL indicators, shared between numerical comparison arms."""
    data = np.zeros((row["count"], len(exp["arms"]), len(Q.NAMES)), dtype=np.int8)
    for offset in range(row["count"]):
        index = row["start"] + offset
        up, down = (1, 1)
        if pattern == "varying":
            up, down = ((1, 1), (1, 1), (1, 0), (0, 0))[index % 4]
        elif pattern == "rare":
            up = down = int(index == 0)
        elif pattern == "zero":
            up = down = 0
        for arm, numerical in enumerate(exp["arms"]):
            # The synthetic interaction is compactly supported inside the base
            # cutoff. Added annuli are sampled and give retained electrons.
            if exp["edges"][row["stratum"]] >= min(exp["arms"][0]["bmax"], numerical["bmax"]):
                continue
            if pattern == "contrasting":
                up = down = (index+arm) % 2
            data[offset, arm, 0] = down if exp["charge"] else 0
            data[offset, arm, 2] = up if exp["charge"] < 6 else 0
    return dict(values=data.tolist(), attempts=row["cost"], maximum_energy_drift=0.)


def complete(root, exp, pattern="constant", reverse=False):
    with Q.database(root) as db:
        rows = db.execute("SELECT * FROM tasks WHERE experiment=? AND state='ready' ORDER BY start,stratum", (exp["id"],)).fetchall()
        for raw in reversed(rows) if reverse else rows:
            row = dict(raw)
            db.execute("UPDATE tasks SET state='running',owner='test' WHERE id=?", (row["id"],))
            Q.commit_result(db, row, packet(exp, row, pattern), "test")


def drive_case(root, manifest, charge=3, production_pattern="constant"):
    key = Q.case_key(50., charge)
    for _ in range(20):
        with Q.database(root) as db:
            case = Q.get(db, "cases", key)
            Q.assess_case(db, manifest, key, case)
            Q.put(db, "cases", key, case)
            if case["status"] in (*Q.TERMINAL_CASE_STATES, "complete", "qualified"):
                return case
            experiments = [Q.get(db, "experiments", e) for e in case["experiments"].values()]
        for exp in experiments:
            complete(root, exp, production_pattern if exp["stage"] == "production" else "constant")
    pytest.fail("Finite synthetic campaign failed to terminate")


@pytest.mark.parametrize("loss_electrons", range(7))
def test_packet_expectations_match_independent_electron_formula(loss_electrons):
    pi, pc, pl = .23, .17, .37
    result = np.zeros(6)
    for pair in itertools.product(range(3), repeat=2):
        target = np.zeros((5, 2), int)
        target[0] = pair
        probability = np.prod([(.60, pi, pc)[x] for x in pair])
        for loss in itertools.product(range(2), repeat=loss_electrons):
            result += probability * np.prod([pl if x else 1-pl for x in loss]) * Q.event_weights(target, loss)
    one_loss = loss_electrons*pl*(1-pl)**(loss_electrons-1) if loss_electrons else 0.
    np.testing.assert_allclose(result, [2*pc*.60, 2*pc*pi, one_loss,
        2*pi*.60*one_loss, 2*pi*.60, pi*pi], rtol=1e-13, atol=1e-15)


def test_weighted_shell_counts_are_not_clipped_to_probabilities():
    target = np.tile([1, 0], (5, 1))
    assert Q.event_weights(target, [1, 0]).tolist() == [0, 0, 1, 5, 5, 0]
    with pytest.raises(ValueError):
        Q.event_weights(np.full((5, 2), 3), [])


def test_prepare_fixes_grid_com_initialization_and_source_provenance(campaign):
    root, manifest = campaign
    assert Q.verify(root) == manifest
    assert manifest["initialization"] == "projectile_ion_com_balanced"
    with Q.database(root) as db:
        cases = Q.summary(db, manifest)
    assert cases["total_cases"] == 7 and cases["completed_cases"] == 0
    assert {c["charge"] for c in cases["cases"]} == set(range(7))
    assert all(c["experiments"] == {} for c in cases["cases"])
    dependency = root / "source/staged.py"
    dependency.write_text(dependency.read_text()+"\n# changed\n")
    with pytest.raises(ValueError, match="Changed frozen"):
        Q.verify(root)


def test_paired_covariance_and_area_estimator_match_raw_samples(campaign, kernel):
    root, manifest = campaign
    exp = make(root, manifest, "flight")
    complete(root, exp, "varying")
    with Q.database(root) as db:
        exp = Q.get(db, "experiments", exp["id"])
        report = Q.assess_experiment(db, manifest, exp, force=True)
    vectors = np.array([[1, 1], [1, 1], [1, 0], [0, 0]]*4, dtype=float)
    areas = np.pi*np.diff(np.square(exp["edges"]))*kernel.BOHR2_CM2
    expected_mean = areas.sum()*vectors.mean(axis=0)
    expected_cov = np.square(areas).sum()*np.cov(vectors.T, ddof=1)/len(vectors)
    np.testing.assert_allclose(np.asarray(report["mean"])[:, 6:], [expected_mean, expected_mean])
    np.testing.assert_allclose(report["rate_covariance"][0], expected_cov, rtol=1e-13)
    np.testing.assert_allclose(report["standard_error"][0][6:], np.sqrt(np.diag(expected_cov)))
    assert np.asarray(report["pair_standard_error"]).max() == 0.
    assert report["rate_covariance"][0][0][1] > 0.


def test_no_production_before_checks_and_cases_advance_independently(campaign):
    root, manifest = campaign
    key = Q.case_key(50., 3)
    with Q.database(root) as db:
        Q.advance(db, manifest)
        case = Q.get(db, "cases", key)
        assert list(case["experiments"]) == ["bmax"]
    case = drive_case(root, manifest)
    assert case["status"] == "qualified"
    assert set(case["experiments"]) == set(Q.STAGES)
    with Q.database(root) as db:
        for stage in Q.AXES:
            assert Q.get(db, "experiments", case["experiments"][stage])["report"]["status"] == "pass"
        other = Q.get(db, "cases", Q.case_key(50., 0))
    assert other["status"] == "sampling" and "production" not in other["experiments"]


def test_fixed_production_plan_reports_missed_precision_without_new_sampling(campaign):
    root, manifest = campaign
    case = drive_case(root, manifest, production_pattern="rare")
    assert case["status"] == "complete" and not case["certificate"]["precision_met"]
    with Q.database(root) as db:
        exp = Q.get(db, "experiments", case["experiments"]["production"])
        planned = list(exp["planned_targets"])
        assert exp["targets"] == exp["completed"] == planned
        count = db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        Q.assess_case(db, manifest, Q.case_key(50., 3), case)
        assert db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0] == count
        exp["targets"][0] += manifest["policy"]["block_size"]
        with pytest.raises(ValueError, match="frozen sample"):
            Q.verify_design(manifest, exp)


def test_production_uses_new_random_streams_and_order_does_not_change_samples(campaign):
    root, manifest = campaign
    case = drive_case(root, manifest)
    with Q.database(root) as db:
        solver = Q.get(db, "experiments", case["experiments"]["solver"])
        production = Q.get(db, "experiments", case["experiments"]["production"])
    keys = [(s, n) for s in range(len(production["targets"])) for n in range(8)]
    def draws(order):
        return {key:Q.phase_rng(manifest, production, *key, 0, 0).random(4) for key in order}
    forward, backward = draws(keys), draws(reversed(keys))
    for key in keys:
        np.testing.assert_array_equal(forward[key], backward[key])
    assert not np.array_equal(Q.phase_rng(manifest, solver, 0, 0, 0, 0).random(4), forward[(0, 0)])
    assert not np.array_equal(Q.phase_rng(manifest, production, 0, 0, 0, 1).random(4), forward[(0, 0)])


def test_checkpoint_resume_counts_only_complete_packets_and_rejects_duplicates(campaign):
    root, manifest = campaign
    exp = make(root, manifest)
    with Q.database(root) as db:
        initial_cost = Q.reserved_cost(db)
        row = dict(db.execute("SELECT * FROM tasks ORDER BY id LIMIT 1").fetchone())
        db.execute("UPDATE tasks SET state='running',owner='first' WHERE id=?", (row["id"],))
        partial = dict(yielded=dict(schema=1, task=row["id"], signature="test", completed=[], active=None),
                       runtime=dict(seconds=1.25))
        Q.commit_result(db, row, partial, "first")
        saved = dict(db.execute("SELECT * FROM tasks WHERE id=?", (row["id"],)).fetchone())
        assert saved["state"] == "ready" and saved["resuming"] == 1
        assert sum(Q.get(db, "experiments", exp["id"])["completed"]) == 0
        assert Q.reserved_cost(db) == initial_cost
        assert Q.assess_experiment(db, manifest, Q.get(db, "experiments", exp["id"]))["status"] == "sampling"
        claimed = Q.claim_trajectory_tasks(db, "second", 1)
        assert claimed[0]["id"] == row["id"]
        Q.commit_result(db, dict(claimed[0]), packet(exp, row), "second")
        assert sum(Q.get(db, "experiments", exp["id"])["completed"]) == row["count"]
        assert Q.reserved_cost(db) == initial_cost
        with pytest.raises(ValueError, match="duplicate"):
            Q.commit_result(db, row, packet(exp, row), "second")


def test_failed_sample_cannot_produce_survivor_only_mean(campaign):
    root, manifest = campaign
    exp = make(root, manifest, "flight")
    with Q.database(root) as db:
        row = dict(db.execute("SELECT * FROM tasks WHERE experiment=? LIMIT 1", (exp["id"],)).fetchone())
        db.execute("UPDATE tasks SET state='running',owner='test' WHERE id=?", (row["id"],))
        Q.commit_result(db, row, dict(failure=dict(outcome="execution_error"), attempts=1), "test")
    complete(root, exp)
    with Q.database(root) as db:
        report = Q.assess_experiment(db, manifest, Q.get(db, "experiments", exp["id"]), force=True)
    assert report["status"] == "trajectory_failure" and "mean" not in report
    assert len(report["failures"]) == 1


def test_budget_rejects_whole_cohort_before_any_partial_reservation(campaign):
    root, manifest = campaign
    bounded = dict(manifest, policy=dict(manifest["policy"], max_trajectories=1))
    exp = make(root, bounded)
    assert exp["status"] == "budget_exhausted"
    with Q.database(root) as db:
        assert db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0] == 0
        assert Q.reserved_cost(db) == 0


def test_incremental_budget_counters_match_ledger_after_state_changes(campaign):
    root, manifest = campaign
    exp = make(root, manifest)
    with Q.database(root) as db:
        identity = db.execute("SELECT id FROM tasks LIMIT 1").fetchone()[0]
        for state in ("running", "done", "ready", "superseded", "ready", "failed", "cancelled"):
            db.execute("UPDATE tasks SET state=? WHERE id=?", (state, identity))
            raw = dict(db.execute("SELECT state,SUM(cost) FROM tasks GROUP BY state"))
            indexed = dict(db.execute("SELECT state,SUM(cost) FROM task_counts GROUP BY state HAVING SUM(n)>0"))
            assert raw == indexed
            assert Q.reserved_cost(db) == sum(v for k, v in raw.items() if k != "superseded")


def test_completed_audit_is_reused_and_stale_audit_cannot_replace_new_cohort(campaign):
    root, manifest = campaign
    exp = make(root, manifest, "flight")
    complete(root, exp)
    with Q.database(root) as db:
        exp = Q.get(db, "experiments", exp["id"])
        Q.put(db, "meta", "async_audits", True)
        report = Q.assess_experiment(db, manifest, exp)
        assert report["status"] == "sampling" and report["audit"]
        assert Q.assess_experiment(db, manifest, exp)["audit"] == report["audit"]
        assert db.execute("SELECT COUNT(*) FROM audits").fetchone()[0] == 1
        task = dict(db.execute("SELECT * FROM audits").fetchone())
        db.execute("UPDATE audits SET state='running',owner='test'")
        actual = Q.assess_experiment(db, manifest, exp, force=True)
        Q.commit_audit(db, task, actual, "test")
        assert Q.assess_experiment(db, manifest, Q.get(db, "experiments", exp["id"])) == actual
        db.execute("UPDATE audits SET state='running',owner='test'")
        exp["targets"][0] *= 2
        exp["report"] = None
        Q.put(db, "experiments", exp["id"], exp)
        Q.commit_audit(db, task, actual, "test")
        assert Q.get(db, "experiments", exp["id"])["report"] is None
        assert db.execute("SELECT state FROM audits").fetchone()[0] == "superseded"


def test_all_charge_states_finish_and_export_cross_sections_and_equilibrium(campaign):
    root, manifest = campaign
    for charge in range(7):
        assert drive_case(root, manifest, charge)["status"] == "qualified"
    with Q.database(root) as db:
        summary = Q.summary(db, manifest)
    assert summary["campaign_complete"] and summary["qualified_cases"] == 7
    assert not summary["production_table_ready"]  # This is an execution-check fixture.
    report = Q.export(root)
    assert report["complete"] and report["rows_with_estimates"] == 7
    final = json.loads((root/"production_table.json").read_text())
    assert final["configuration"]["purpose"] == "execution_check"
    with (root/"cross_sections.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 7 and all(r["stage"] == "production" for r in rows)
    with (root/"equilibrium_fractions.csv").open() as stream:
        fractions = list(csv.DictReader(stream))
    np.testing.assert_allclose([float(r["fraction"]) for r in fractions], np.full(7, 1/7))
    assert float(fractions[0]["mean_charge"]) == pytest.approx(3.)


def test_atomic_checkpoint_replacement_failure_preserves_previous_product(tmp_path, monkeypatch):
    path = tmp_path / "status.json"
    Q.atomic_json(path, {"old":1})
    def fail(*args):
        raise OSError("interrupted replacement")
    monkeypatch.setattr(Q.os, "replace", fail)
    with pytest.raises(OSError):
        Q.atomic_json(path, {"new":2})
    assert json.loads(path.read_text()) == {"old":1}
    assert not list(tmp_path.glob("*.tmp"))


def test_physical_worker_requires_compute_allocation(tmp_path, monkeypatch):
    monkeypatch.delenv("PBS_JOBID", raising=False)
    with pytest.raises(RuntimeError, match="PBS"):
        Q.run(tmp_path, 1, "test")


def test_packet_execution_is_identical_across_worker_orders(campaign, kernel, monkeypatch):
    root, manifest = campaign
    exp = make(root, manifest, "flight")
    def synthetic_segment(**kwargs):
        # The real packet assembler and phase RNG run; only the ODE is stubbed.
        outcome = "ionized" if kwargs["rng"].random() < .4 else "retained_target"
        return dict(status="done", result=(outcome, True, 0.))
    monkeypatch.setattr(kernel, "simulate_one_trajectory_segment", synthetic_segment)
    with Q.database(root) as db:
        tasks = [dict(r) for r in db.execute("SELECT * FROM tasks WHERE experiment=? ORDER BY start,stratum LIMIT 8", (exp["id"],))]
    def execute(order, workers):
        results = {}
        for i, task in enumerate(order):
            result = Q.execute(dict(task, owner=f"worker_{i%workers}"), exp, manifest, RUNTIME)
            assert "failure" not in result
            assert result["attempts"] == task["cost"]
            results[task["id"]] = result["values"]
        return results
    assert execute(tasks, 1) == execute(list(reversed(tasks)), 7)


def test_packet_execution_discards_no_failed_sample_into_survivor_mean(campaign, kernel, monkeypatch):
    root, manifest = campaign
    exp = make(root, manifest, "flight")
    calls = 0
    def synthetic_segment(**kwargs):
        nonlocal calls
        calls += 1
        return dict(status="done", result=("integration_failure", False, 1.)) if calls == 3 else dict(
            status="done", result=("retained_target", True, 0.))
    monkeypatch.setattr(kernel, "simulate_one_trajectory_segment", synthetic_segment)
    with Q.database(root) as db:
        task = dict(db.execute("SELECT * FROM tasks WHERE experiment=? LIMIT 1", (exp["id"],)).fetchone())
    result = Q.execute(task, exp, manifest, RUNTIME)
    assert result["failure"]["outcome"] == "integration_failure"
    assert result["attempts"] == 3 and "values" not in result


def test_numerical_pilot_enlarges_once_then_reports_its_limit(campaign):
    root, manifest = campaign
    exp = make(root, manifest, "flight")
    complete(root, exp, "contrasting")
    with Q.database(root) as db:
        exp = Q.get(db, "experiments", exp["id"])
        exp["report"] = Q.assess_experiment(db, manifest, exp, force=True)
        assert exp["report"]["status"] == "needs_samples"
        Q.more_samples(db, manifest, exp)
        planned = list(exp["planned_targets"])
        assert max(planned) > manifest["policy"]["initial_samples"]
    complete(root, exp, "contrasting")
    with Q.database(root) as db:
        exp = Q.get(db, "experiments", exp["id"])
        exp["report"] = Q.assess_experiment(db, manifest, exp, force=True)
        assert exp["report"]["status"] == "sampling_limit"
        assert exp["targets"] == exp["completed"] == planned
        count = db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        Q.more_samples(db, manifest, exp)
        assert exp["status"] == "sampling_limit" and exp["targets"] == planned
        assert db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0] == count
