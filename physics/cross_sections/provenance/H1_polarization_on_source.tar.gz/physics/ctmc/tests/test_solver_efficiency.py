"""Deterministic retries retain outcomes and every distinct solver setting."""
from dataclasses import asdict, replace
import numpy as np
import pytest
from physics.ctmc import qualify as Q
from physics.ctmc.tests.test_qualification import kernel, controls


@pytest.mark.parametrize('mode', ['tight_success', 'regularized_success', 'all_fail'])
@pytest.mark.parametrize('distinct_retry', [False, True])
def test_unique_retry_ladder_retains_decision(kernel, controls, monkeypatch, mode, distinct_retry):
    k = kernel
    base=Q.config_for(dict(projectile='carbon',nuclear_charge=6,seed=7,
        ensemble='independent_isotropic_sensitivity',initialization='projectile_ion_com_balanced'),asdict(controls))
    cfg = replace(base, backend='numba', rtol=1e-9, atol=1e-11,
                  retry_rtol=1e-10 if distinct_retry else 1e-9,
                  retry_atol=1e-12 if distinct_retry else 1e-11,
                  maximum_integration_steps=100)
    calls = []
    monkeypatch.setattr(k, '_build_initial_relative_state', lambda **kw: np.zeros(12))
    monkeypatch.setattr(k, 'relative_three_body_energy', lambda *a: 1.)
    monkeypatch.setattr(k, '_electron_core_energy_relative', lambda *a: -1. if a[1]==0 else 1.)
    def plain(state, time, p, q, rtol, atol, *args, **kwargs):
        assert kwargs == {'maximum_relative_energy_drift': cfg.maximum_relative_energy_drift}
        calls.append(('plain', rtol, atol))
        return mode=='tight_success' and rtol<cfg.retry_rtol, state.copy(), 1, 0
    def regularized(state, time, p, q, rtol, atol, *args):
        calls.append(('regularized', args[4], args[6], rtol, atol))
        return mode=='regularized_success' and rtol<cfg.retry_rtol, state.copy(), 1, 0
    monkeypatch.setattr(k, 'integrate_relative_dop853', plain)
    monkeypatch.setattr(k, 'integrate_relative_dop853_regularized', regularized)
    result=k.simulate_one_trajectory(energy_keV_u=100.,charge_state=6,
        impact_parameter_au=1.,bound_to='target',binding_eV=k.WATER_ORBITALS[0].binding_eV,
        start_separation_au=100.,minimum_integration_time_au=100.,config=cfg,
        rng=np.random.default_rng(7),retain_ambiguous_endpoint=True)
    assert len(calls)==len(set(calls))
    assert ('plain',cfg.rtol,cfg.atol) in calls
    assert ('plain',cfg.retry_rtol*.1,cfg.retry_atol*.1) in calls
    if mode=='all_fail':
        assert result[0:2]==('integration_failure',False)
        assert len(calls)==(3 if distinct_retry else 2)*5
    else:
        assert result==('retained_target',True,0.)


def test_cached_underflow_floor_preserves_potential(kernel):
    k=kernel
    assert k._FLOAT_TINY == np.finfo(float).tiny
    for core in k._trajectory_cores(0,'target'):
        for radius in (0.,1e-14,.01,1.,100.,1e5):
            zeff,derivative=k.effective_charge_and_derivative(core,radius)
            assert np.isfinite(zeff) and np.isfinite(derivative)
            with np.errstate(over='ignore'):
                assert k.potential_magnitude(core,radius)==zeff/max(float(radius),np.finfo(float).tiny)
