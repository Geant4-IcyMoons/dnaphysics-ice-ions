"""Cover the exact native signatures without compiling or integrating on login."""
from types import SimpleNamespace

import numpy as np
from numba import types, typeof
import pytest

from physics.ctmc import continuation as S
from physics.ctmc.tests.test_qualification import kernel


def test_warmup_covers_every_production_signature(kernel):
    calls = []
    class Recorder:
        def __init__(self, name): self.name = name
        def compile(self, signature): calls.append((self.name, signature))
    names = ('_integrate_relative_dop853_segment',
             '_integrate_relative_dop853_regularized_segment')
    backend = SimpleNamespace(**{name: Recorder(name) for name in names})
    report = S.warm_native_backend(kernel, backend_module=backend)
    assert len(calls) == len(report['signatures']) == 4
    assert len(set(calls)) == 4
    assert report['cpu'] and report['seconds'] >= 0.
    for name, signature in calls:
        assert signature[0] == types.Array(types.float64, 1, 'C')
        assert signature[2] == signature[3] == types.Array(types.float64, 1, 'C', readonly=True)
        for index in (1, 4, 5, 6, 7, 8, 9): assert signature[index] == types.float64
        floating, integral = signature[14:16] if name == names[0] else signature[16:18]
        assert (floating, integral) in ((types.none, types.none),
            (types.Array(types.float64, 1, 'C'), types.Array(types.int64, 1, 'C')))


@pytest.mark.parametrize('power', [0, 1, 2])
@pytest.mark.parametrize('resumed', [False, True])
def test_integer_controls_use_exactly_prewarmed_interface(kernel, power, resumed):
    calls = []
    class Recorder:
        def __init__(self, name): self.name=name
        def compile(self, signature): calls.append((self.name,signature))
    names = ('_integrate_relative_dop853_segment', '_integrate_relative_dop853_regularized_segment')
    S.warm_native_backend(kernel, backend_module=SimpleNamespace(**{n:Recorder(n) for n in names}))
    target, projectile = kernel._trajectory_cores(0, 'target')
    def native(*args, **kwargs):
        actual = (*args, kwargs['maximum_relative_energy_drift']) if kwargs else args
        signature = tuple(typeof(x) for x in actual)
        assert (names[bool(power)],signature) in calls
        return 0, np.zeros(12), 0, 0, np.empty(0), np.empty(0,dtype=np.int64)
    checkpoint = None if not resumed else dict(floating=np.zeros(29).tolist(),integral=np.zeros(5,dtype=int).tolist())
    result = S._native_segment(SimpleNamespace(**{n:native for n in names}),
        np.zeros(12), 1000, kernel._cached_core_parameters(target),
        kernel._cached_core_parameters(projectile), 1e-8, 1e-10, 1, 1e-10,
        int(kernel.WATER_MASS_AU), int(kernel.PROJECTILE_MASS_AU),
        100000, False, 1000, power, 1e-6, 100000, checkpoint)
    assert result['status']=='done' and result['state'] is None
