"""Packet checkpoints preserve raw sample identity; integration is faked here."""
import json
from pathlib import Path
import zlib

import pytest

from physics.ctmc import qualify as Q
from physics.ctmc.tests.test_qualification import campaign, controls, policy, kernel, make


class Segments:
    """Deterministic electron labels, optionally paused inside selected electrons."""
    def __init__(self, clock, pauses=()):
        self.clock = clock
        self.pauses = set(pauses)
        self.fresh = []
        self.resumed = []

    def __call__(self, *, continuation=None, **kw):
        draw = float(kw["rng"].random())
        identity = [kw["start_separation_au"], kw["impact_parameter_au"],
                    kw["binding_eV"], kw["bound_to"], draw]
        if continuation is None:
            assert identity not in self.fresh, "An electron was restarted from scratch"
            self.fresh.append(identity)
            if len(self.fresh) in self.pauses:
                self.clock[0] += 2.
                return dict(status="yielded", continuation=dict(identity=identity, step=7),
                            work=dict(steps=7))
        else:
            assert continuation == dict(identity=identity, step=7)
            self.resumed.append(identity)
        outcome = "ionized" if draw < .2 else "captured_projectile" if draw < .3 else "retained_target"
        return dict(status="done", result=[outcome, True, draw*1e-8], work=dict(steps=12))


@pytest.fixture
def packet(campaign, kernel, monkeypatch):
    root, manifest = campaign
    exp = make(root, manifest, "flight", 1)
    with Q.database(root) as db:
        task = dict(db.execute("SELECT * FROM tasks WHERE experiment=? ORDER BY start,stratum LIMIT 1",
            (exp["id"],)).fetchone())
    clock = [0.]
    monkeypatch.setattr(Q.time, "monotonic", lambda:clock[0])
    monkeypatch.setattr(Q, "CONTINUATION_REVISION", "test-packet-revision-1")
    monkeypatch.setitem(Q.RUNTIME, "packet_seconds", 1.)
    monkeypatch.setattr(Q, "_CANCEL_FLAGS", None)
    monkeypatch.setattr(Q, "_CANCEL_SLOT", None)
    return root, manifest, exp, task, clock, Path(kernel.__file__).parent


def claim(root, task, owner="test"):
    with Q.database(root) as db:
        db.execute("UPDATE tasks SET state='running',owner=? WHERE id=?", (owner,task["id"]))
        return dict(db.execute("SELECT * FROM tasks WHERE id=?", (task["id"],)).fetchone())


def fake_segment(monkeypatch, clock, pauses):
    fake = Segments(clock, pauses)
    monkeypatch.setattr(Q.C, "simulate_one_trajectory_segment", fake, raising=False)
    monkeypatch.setattr(Q.C, "simulate_one_trajectory", lambda **kw:pytest.fail("Unsegmented integration ran"))
    return fake


def test_json_checkpoint_commit_resume_matches_uninterrupted_packet(packet, monkeypatch):
    root, manifest, exp, task, clock, runtime = packet
    fake = fake_segment(monkeypatch, clock, {4, 17})
    before = exp["completed"][:]
    yielded = 0
    while True:
        task = claim(root, task)
        result = Q.execute(task, exp, manifest, runtime)
        # The result must survive actual compressed JSON persistence, not just
        # reuse the same in-memory continuation object.
        with Q.database(root) as db:
            budget = Q.reserved_cost(db)
            Q.commit_result(db, task, result, "test")
            assert Q.reserved_cost(db) == budget
            row = dict(db.execute("SELECT * FROM tasks WHERE id=?", (task["id"],)).fetchone())
            completed = Q.get(db, "experiments", exp["id"])["completed"]
            if "yielded" not in result:
                break
            yielded += 1
            assert row["state"] == "ready" and row["owner"] is None and row["resuming"] == 1
            assert completed == before
            assert json.loads(zlib.decompress(row["result"]))["continuation"] == result["yielded"]
    assert yielded == 2 and len(fake.resumed) == 2
    assert len(fake.fresh) == task["cost"] == result["attempts"]
    assert row["state"] == "done"
    assert completed[task["stratum"]] == before[task["stratum"]]+task["count"]
    with Q.database(root) as db:
        progress = dict(db.execute("SELECT * FROM task_progress WHERE task=?", (task["id"],)).fetchone())
        assert progress["segments"] == 3 and progress["seconds"] == 4.
        with pytest.raises(ValueError, match="duplicate"):
            Q.commit_result(db, task, result, "test")
    fake_segment(monkeypatch, clock, set())
    fresh = Q.execute(dict(task, result=None), exp, manifest, runtime)
    assert {k:v for k,v in result.items() if k != "runtime"} == {
        k:v for k,v in fresh.items() if k != "runtime"}


def test_execution_revision_change_refuses_saved_continuation(packet, monkeypatch):
    root, manifest, exp, task, clock, runtime = packet
    fake = fake_segment(monkeypatch, clock, {1})
    task = claim(root, task)
    result = Q.execute(task, exp, manifest, runtime)
    with Q.database(root) as db:
        Q.commit_result(db, task, result, "test")
    task = claim(root, task)
    monkeypatch.setattr(Q, "CONTINUATION_REVISION", "incompatible-revision")
    with pytest.raises(ValueError, match="Incompatible"):
        Q.execute(task, exp, manifest, runtime)
    assert len(fake.fresh) == 1 and fake.resumed == []


def test_completed_electrons_remain_cached_when_next_electron_fails(packet, monkeypatch):
    root, manifest, exp, task, clock, runtime = packet
    fake = fake_segment(monkeypatch, clock, {4})
    task = claim(root, task)
    partial = Q.execute(task, exp, manifest, runtime)
    with Q.database(root) as db:
        Q.commit_result(db, task, partial, "test")
    task = claim(root, task)
    monkeypatch.setattr(Q.C, "simulate_one_trajectory_segment", lambda **kw:dict(
        status="done", result=["integration_failed",False,float("nan")]))
    failed = Q.execute(task, exp, manifest, runtime)
    assert failed["attempts"] == 4 and failed["failure"]["drift"] is None
    with Q.database(root) as db:
        Q.commit_result(db, task, failed, "test")
        assert Q.get(db, "experiments", exp["id"])["completed"] == exp["completed"]
        assert db.execute("SELECT state FROM tasks WHERE id=?", (task["id"],)).fetchone()[0] == "failed"
    assert len(fake.fresh) == 4


def partial_task(packet, monkeypatch):
    root, manifest, exp, task, clock, runtime = packet
    fake_segment(monkeypatch, clock, {1})
    task = claim(root, task)
    result = Q.execute(task, exp, manifest, runtime)
    with Q.database(root) as db:
        Q.commit_result(db, task, result, "test")
    return task


def test_cancelling_resumed_obsolete_packet_keeps_its_full_budget(packet, monkeypatch):
    root, manifest, exp, _, _, runtime = packet
    task = partial_task(packet, monkeypatch)
    task = claim(root, task)
    with Q.database(root) as db:
        c = Q.get(db, "cases", exp["case"])
        c["experiments"] = {}
        Q.put(db, "cases", exp["case"], c)
        before = Q.reserved_cost(db)
        Q.commit_result(db, task, dict(cancelled="superseded_design"), "test")
        assert Q.reserved_cost(db) == before
        assert Q.get(db, "experiments", exp["id"])["completed"] == exp["completed"]


def test_pruning_ready_partial_packet_cannot_refund_its_started_trajectories(packet, monkeypatch):
    root, manifest, exp, _, _, _ = packet
    task = partial_task(packet, monkeypatch)
    with Q.database(root) as db:
        c = Q.get(db, "cases", exp["case"])
        c["experiments"] = {}
        Q.put(db, "cases", exp["case"], c)
        Q.prune_inactive_work(db)
        row = db.execute("SELECT state,result FROM tasks WHERE id=?", (task["id"],)).fetchone()
        assert row["state"] == "cancelled"
        assert "continuation" in json.loads(zlib.decompress(row["result"]))
        assert Q.reserved_cost(db) == task["cost"]
        assert db.execute("SELECT COUNT(*) FROM tasks WHERE state='superseded'").fetchone()[0] > 0


def test_advance_retirement_uses_partial_budget_rule(packet, monkeypatch):
    root, manifest, exp, _, _, _ = packet
    task = partial_task(packet, monkeypatch)
    def assess(db, manifest, key, case, **kw):
        case["experiments"] = {}
    monkeypatch.setattr(Q, "assess_case", assess)
    with Q.database(root) as db:
        Q.advance(db, manifest)
        assert Q.reserved_cost(db) == task["cost"]
        assert db.execute("SELECT state FROM tasks WHERE id=?", (task["id"],)).fetchone()[0] == "cancelled"


def test_resume_and_fresh_work_each_receive_slots_after_restart(packet, monkeypatch):
    root, manifest, exp, _, _, _ = packet
    task = partial_task(packet, monkeypatch)
    with Q.database(root) as db:
        rows = Q.claim_trajectory_tasks(db, "worker", 2, admission_slots=0)
        assert len(rows) == 2 and rows[0]["id"] == task["id"]
        assert rows[1]["resuming"] == 0
        # Return the unchanged packets to their respective queues.
        for row in rows:
            db.execute("UPDATE tasks SET state='ready',owner=NULL WHERE id=?",(row["id"],))
        Q.put(db, "meta", "continuation_dispatch_turn", True)
        first = Q.claim_trajectory_tasks(db, "worker", 1, admission_slots=0)[0]
        assert first["resuming"] == 1
        db.execute("UPDATE tasks SET state='ready',owner=NULL WHERE id=?",(first["id"],))
    with Q.database(root) as db:
        Q.initialize_runtime(db)
        second = Q.claim_trajectory_tasks(db, "worker", 1, admission_slots=0)[0]
        assert second["resuming"] == 0


def test_continuations_fill_capacity_when_no_fresh_tasks_remain(packet, monkeypatch):
    root, manifest, exp, _, _, _ = packet
    task = partial_task(packet, monkeypatch)
    with Q.database(root) as db:
        db.execute("UPDATE tasks SET state='running',owner='other' WHERE resuming=0")
        Q.put(db, "meta", "continuation_dispatch_turn", False)
        claimed = Q.claim_trajectory_tasks(db, "worker", 1, admission_slots=0)
        assert [r["id"] for r in claimed] == [task["id"]]
