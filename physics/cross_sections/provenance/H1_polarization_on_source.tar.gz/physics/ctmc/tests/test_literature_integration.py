"""Initializer checks and bounded compute regressions at literature-scale flights.

The deterministic trajectories below check execution and solver continuation.
They cannot qualify a cross-section or establish its statistical uncertainty.
"""
from dataclasses import asdict, replace
import json
import os

import numpy as np
import pytest

from physics.ctmc import continuation as S
from physics.ctmc.tests.test_qualification import Q, controls, kernel


COMPUTE = pytest.mark.skipif(not os.environ.get("PBS_JOBID"),
    reason="Physical CTMC trajectories require a PBS allocation")

# Energies, charge, initial electron owner, water orbital index, and impact (au).
PREFIX_CASES = ((10., 0, "target", 0, .7),
                (10., 0, "projectile", 0, .7),
                (50., 3, "projectile", 0, .7),
                (10., 3, "target", 4, 50.))
ENDPOINT_CASES = ((50., 3, "target", 0, .7),
                  (50., 3, "projectile", 0, 5.),
                  (1000., 6, "target", 0, .7),
                  (1000., 6, "target", 4, 25.))


def _inputs(kernel, controls, case):
    energy, charge, bound, orbital, impact = case
    distance = 10000. if energy <= 25. else 1000.
    numerical = replace(controls, bmax=25., incoming=distance,
        outgoing=distance,
        minimum_time=kernel.paper_minimum_integration_time_au(energy))
    manifest = dict(projectile="carbon", nuclear_charge=6, seed=732691,
        ensemble="independent_isotropic_sensitivity",
        initialization="projectile_ion_com_balanced")
    cfg = Q.config_for(manifest, asdict(numerical))
    binding = (kernel.WATER_ORBITALS[orbital].binding_eV if bound == "target"
               else kernel.PROJECTILE_OUTER_ORBITAL[charge].binding_eV)
    return dict(energy_keV_u=energy, charge_state=charge,
        impact_parameter_au=impact, bound_to=bound, binding_eV=binding,
        start_separation_au=distance,
        minimum_integration_time_au=numerical.minimum_time,
        minimum_terminal_core_separation_au=distance,
        config=cfg, retain_ambiguous_endpoint=True)


def _json_roundtrip(value):
    return json.loads(json.dumps(value, allow_nan=False))


@pytest.mark.parametrize("case", PREFIX_CASES + ENDPOINT_CASES)
def test_prescribed_com_beam_and_binding_at_new_boundaries(kernel, controls, case):
    inputs = _inputs(kernel, controls, case)
    cfg = inputs["config"]
    target, projectile = kernel._trajectory_cores(case[1], case[2])
    for seed in range(8):
        state = kernel._build_initial_relative_state(
            energy_keV_u=case[0], impact_parameter_au=case[4],
            separation_au=inputs["start_separation_au"], bound_to=case[2],
            binding_eV=inputs["binding_eV"], target_core=target,
            projectile_core=projectile, radial_grid_points=cfg.radial_grid_points,
            rng=np.random.default_rng(seed), initial_ensemble=cfg.initial_ensemble,
            projectile_loss_initialization=cfg.projectile_loss_initialization)
        target_bound = case[2] == "target"
        mass = kernel.WATER_MASS_AU if target_bound else kernel.PROJECTILE_MASS_AU
        core = target if target_bound else projectile
        fraction = kernel.ELECTRON_MASS_AU / (mass + kernel.ELECTRON_MASS_AU)
        sign = 1. if target_bound else -1.
        expected_position = sign * np.array([case[4], 0., -inputs["start_separation_au"]])
        expected_velocity = sign * np.array([0., 0., kernel.projectile_velocity_au(case[0])])
        np.testing.assert_allclose(state[:3] - fraction * state[3:6],
            expected_position, rtol=0., atol=1e-10)
        np.testing.assert_allclose(state[6:9] - fraction * state[9:12],
            expected_velocity, rtol=0., atol=1e-13)
        binding = kernel._electron_core_energy_relative(state, 0, core,
                                                        mass, cfg.minimum_radius_au)
        assert binding == pytest.approx(-inputs["binding_eV"] / kernel.EV_PER_HARTREE,
                                       rel=1e-7)


def test_radial_quadrature_refinement_for_every_bound_core(kernel):
    target = kernel.CorePotential.from_zn(kernel.WATER_PSEUDO_NUCLEAR_CHARGE, 9)
    channels = [(target, orbital.binding_eV) for orbital in kernel.WATER_ORBITALS]
    channels += [(kernel._trajectory_cores(q, "projectile")[1], orbital.binding_eV)
                 for q, orbital in kernel.PROJECTILE_OUTER_ORBITAL.items()]
    for core, binding in channels:
        grids = [kernel._microcanonical_radius_cdf(core.nuclear_charge,
            core.spectators, round(binding, 10), points)
            for points in (4096, 8192, 16384)]
        distances = [float(np.max(abs(np.interp(r2, r1, c1) - c2)))
                     for (r1, c1), (r2, c2) in zip(grids, grids[1:])]
        # This is a deterministic sampler regression, not a physical-error gate.
        assert distances[0] < 1e-3
        assert distances[1] < distances[0]


@COMPUTE
@pytest.mark.parametrize("case", PREFIX_CASES)
def test_new_boundary_native_prefix_survives_json_resume(kernel, controls, case):
    inputs = _inputs(kernel, controls, case)
    # The same 20,000 attempted-step prefix, advanced in one or two calls.
    expected = S.simulate_one_trajectory_segment(kernel, **inputs,
        rng=np.random.default_rng(732691), segment_steps=20000)
    first = S.simulate_one_trajectory_segment(kernel, **inputs,
        rng=np.random.default_rng(732691), segment_steps=10000)
    if first["status"] == "done":
        assert _json_roundtrip(first) == _json_roundtrip(expected)
        return
    assert first["status"] == "yielded"
    resumed = S.simulate_one_trajectory_segment(kernel, **inputs,
        rng=np.random.default_rng(732691), segment_steps=10000,
        continuation=_json_roundtrip(first["continuation"]))
    assert _json_roundtrip(resumed) == _json_roundtrip(expected)


@COMPUTE
@pytest.mark.parametrize("case", ENDPOINT_CASES)
def test_new_boundary_endpoint_resume_and_reference(kernel, controls, case, record_property):
    inputs = _inputs(kernel, controls, case)
    seed = 732691
    uninterrupted = kernel.simulate_one_trajectory(**inputs,
        rng=np.random.default_rng(seed))
    checkpoint = None
    for _ in range(10000):
        result = S.simulate_one_trajectory_segment(kernel, **inputs,
            rng=np.random.default_rng(seed), segment_steps=100000,
            continuation=checkpoint)
        if result["status"] == "done":
            break
        checkpoint = _json_roundtrip(result["continuation"])
    else:
        pytest.fail("Bounded test exhausted its continuation-call allowance")
    assert tuple(result["result"]) == uninterrupted
    reference_inputs = dict(inputs, config=replace(inputs["config"], backend="scipy"))
    checkpoint = None
    for _ in range(10000):
        reference_result = S.simulate_one_trajectory_segment(kernel, **reference_inputs,
            rng=np.random.default_rng(seed), segment_steps=100000,
            continuation=checkpoint)
        if reference_result["status"] == "done":
            reference = reference_result["result"]
            break
        checkpoint = _json_roundtrip(reference_result["continuation"])
    else:
        pytest.fail("Independent RK45 exhausted its bounded continuation-call allowance")
    observed = dict(case=list(case), native=list(uninterrupted),
        reference=list(reference), outcome_agreement=reference[0] == uninterrupted[0],
        scope="Deterministic execution check; no statistical cross-section qualification")
    record_property("ctmc_reference", json.dumps(observed))
    print("CTMC_REFERENCE_RESULT=" + json.dumps(observed))
    for outcome, success, drift in (uninterrupted, reference):
        assert success
        assert outcome in ("retained_target", "captured_projectile", "ionized")
        assert np.isfinite(drift) and drift <= inputs["config"].maximum_relative_energy_drift
