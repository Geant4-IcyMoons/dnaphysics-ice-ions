"""Variance-guided extension and threshold regressions; no physical integration."""
import copy
import numpy as np
import pytest
from physics.ctmc import qualify as Q
from physics.ctmc.tests.test_literature_policy import Engine, experiment, moments, assess, manifest

@pytest.fixture
def progressive(manifest):
    manifest['policy'].update(max_samples_per_annulus=None, production_max_samples=None,
        max_trajectories=None, batch_growth=.2, fallback_relative=.1, fallback_multiplier=11.)
    return manifest


def test_unlimited_policy_is_explicit():
    Q.Policy(max_samples_per_annulus=None,production_max_samples=None,max_trajectories=None)
    with pytest.raises(ValueError): Q.Policy(batch_growth=0)


def test_close_comparison_gets_small_topup(progressive):
    exp=experiment();exp['reference_targets']=list(exp['targets'])
    r=assess(progressive,exp,*moments(exp,change=.02,se=.0546))
    assert r['status']=='needs_samples'
    assert r['effective_statistical_relative']==.05
    assert exp['targets'][0] < r['allocation']['planned_targets'][0] <= 616
    assert r['allocation']['planned_targets'][1]==512


def test_rare_comparison_relaxes_noise_not_measured_change(progressive):
    exp=experiment();exp['reference_targets']=list(exp['targets'])
    # Large history relative to the fixed reference puts this on the fallback.
    exp['targets']=[8192,8192];exp['planned_targets']=list(exp['targets'])
    r=assess(progressive,exp,*moments(exp,change=.02,se=.09))
    assert r['effective_statistical_relative']==.1
    assert r['status']=='pass'
    r=assess(progressive,exp,*moments(exp,change=.12,se=.09))
    assert r['status']=='needs_samples'
    assert not r['numerical_qualification_met']
    r=assess(progressive,exp,*moments(exp,change=.50,se=.09))
    assert r['status']=='resolved_change'


def test_fixed_reference_does_not_move_across_batches(progressive):
    exp=experiment();exp['reference_targets']=[512,512]
    for n in (4096,8192,16384):
        exp['targets']=exp['planned_targets']=[n,n]
        r=assess(progressive,exp,*moments(exp,se=.3))
        assert r['status']=='needs_samples'
        assert r['allocation']['reference_targets']==[512,512]
        assert all(n<=v<=8*np.ceil(n*1.2/8) for v in r['allocation']['planned_targets'])


def test_production_extends_zero_and_noisy_rates(progressive):
    exp=experiment('production',2048);exp['planned_targets']=list(exp['targets'])
    for base,se in [(0.,0.),(1.,.5)]:
        r=assess(progressive,exp,*moments(exp,baseline=base,se=se))
        assert r['status']=='needs_samples'
        assert not r['precision_met']
        assert sum(r['allocation']['planned_targets'])>sum(exp['targets'])
        assert 'no nominal confidence' in r['zero_upper_limit_scope']
    r=assess(progressive,exp,*moments(exp,se=.02))
    assert r['status']=='production_complete'


def test_more_samples_keeps_reference_and_accepts_repeated_rounds(progressive,monkeypatch):
    saved=[]
    monkeypatch.setattr(Q,'schedule',lambda *args:None)
    monkeypatch.setattr(Q,'put',lambda db,t,k,v:saved.append(copy.deepcopy(v)))
    exp=experiment();exp['id']='synthetic'
    for _ in range(4):
        exp['report']=assess(progressive,exp,*moments(exp,se=.5))
        Q.more_samples(None,progressive,exp)
        assert exp['status']=='sampling'
        assert exp['reference_targets']==[512,512]
    assert exp['sampling_rounds']==4
    assert len(saved)==4
