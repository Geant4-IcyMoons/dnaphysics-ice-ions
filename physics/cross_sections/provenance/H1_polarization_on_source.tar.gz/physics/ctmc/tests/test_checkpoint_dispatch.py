"""Checkpoint scheduling preserves sample identity and general-queue service."""
from physics.ctmc import qualify as Q
from physics.ctmc.tests.test_qualification import campaign, controls, policy, make, kernel


def finishing_case(root, manifest, remaining_blocks=1):
    old = make(root, manifest, 'flight', 0)
    new = make(root, manifest, 'bmax', 1)
    with Q.database(root) as db:
        rows = db.execute('SELECT * FROM tasks WHERE experiment=? ORDER BY start,stratum', (old['id'],)).fetchall()
        finish = [dict(row) for row in rows[-remaining_blocks:]]
        old['completed'] = old['targets'][:]
        for row in rows[:-remaining_blocks]:
            db.execute("UPDATE tasks SET state='done' WHERE id=?", (row['id'],))
        for row in finish:
            old['completed'][row['stratum']] -= row['count']
        Q.put(db, 'experiments', old['id'], old)
    return old, new, finish


def test_finishing_sample_precedes_new_low_index_work_without_excluding_it(campaign, kernel):
    root, manifest = campaign
    old, new, finish = finishing_case(root, manifest)
    with Q.database(root) as db:
        rows = Q.claim_trajectory_tasks(db, 'worker', 2, admission_slots=0)
        assert rows[0]['id'] == finish[0]['id']
        assert rows[0]['start'] == finish[0]['start']  # No artificial reindexing.
        assert rows[1]['experiment'] == new['id'] and rows[1]['start'] == 0
        assert len({r['id'] for r in rows}) == 2


def test_single_slot_fairness_persists_across_restart(campaign, kernel):
    root, manifest = campaign
    old, new, _ = finishing_case(root, manifest, 2)
    with Q.database(root) as db:
        assert Q.claim_trajectory_tasks(db, 'worker', 1, admission_slots=0)[0]['experiment'] == old['id']
    with Q.database(root) as db:
        Q.initialize_runtime(db)
        assert Q.claim_trajectory_tasks(db, 'worker', 1, admission_slots=0)[0]['experiment'] == new['id']
        assert Q.claim_trajectory_tasks(db, 'worker', 1, admission_slots=0)[0]['experiment'] == old['id']


def test_running_work_still_counts_as_outstanding(campaign, kernel):
    root, manifest = campaign
    old, new, _ = finishing_case(root, manifest)
    with Q.database(root) as db:
        db.execute("UPDATE tasks SET state='running',owner='other' WHERE experiment=? AND start>0", (new['id'],))
        assert Q.checkpoint_order(db)[0] == old['id']


def test_refined_design_is_not_promoted_from_cached_order(campaign, kernel):
    root, manifest = campaign
    old, new, _ = finishing_case(root, manifest)
    with Q.database(root) as db:
        assert Q.checkpoint_order(db)[0] == old['id']
        case = Q.get(db, 'cases', old['case']); case['experiments'] = {}
        Q.put(db, 'cases', old['case'], case)
        Q.prune_inactive_work(db)
        assert all(row['experiment'] == new['id'] for row in Q.claim_trajectory_tasks(db, 'worker', 2, admission_slots=0))


def test_timing_calibration_uses_sparse_experiment_index(campaign):
    # Without the fixed join order SQLite scans millions of historical done
    # packets, even when this experiment has no recorded execution timings.
    import ast
    import inspect
    query = next(n.value for n in ast.walk(ast.parse(inspect.getsource(Q.assess_experiment)))
                 if isinstance(n, ast.Constant) and isinstance(n.value, str)
                 and "SUM(p.seconds)" in n.value)
    root, _ = campaign
    with Q.database(root) as db:
        plan = " ".join(str(tuple(row)) for row in db.execute("EXPLAIN QUERY PLAN "+query, ("none",)))
        assert "task_progress_experiment" in plan
        assert "tasks_work" not in plan
        assert list(db.execute(query, ("none",))) == []
