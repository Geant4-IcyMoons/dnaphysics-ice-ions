"""Allocation lifecycle and resource fitting use fake PBS; no jobs are submitted."""
import copy
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace

import pytest
from physics.ctmc import supervise as S


class Scheduler:
    def __init__(self, available=8):
        self.available = available
        self.states = {}
        self.exit_codes = {}
        self.submissions = []
        self.retirements = []
        self.error = None
        self.hosts = [dict(host=f"node{i}", queues=["idle", "p72"], cpus=32, memory_gb=16.) for i in range(8)]

    def jobs(self, ids):
        if any(i not in self.states for i in ids):
            raise RuntimeError("Unknown recorded job")
        return {i:dict(job_state=self.states[i], Exit_status=self.exit_codes.get(i, 0)) for i in ids}

    def capacity(self, routes):
        return dict(admission={r:dict(available=self.available) for r in routes}, hosts=copy.deepcopy(self.hosts))

    def submit(self, command, script):
        self.submissions.append((command, script))
        if self.error:
            raise self.error
        job = f"{100+len(self.submissions)}.pbs02"
        self.states[job] = "Q"
        return SimpleNamespace(returncode=0, stdout=job+"\n", stderr="")

    def retire(self, job, queued):
        self.retirements.append((job, queued))
        return SimpleNamespace(returncode=0, stdout="", stderr="")


@pytest.fixture
def setup(tmp_path):
    root = tmp_path/"production"
    root.mkdir()
    (root/"manifest.json").write_text(json.dumps(dict(signature="production-signature",
        workflow=dict(name="literature_pilot_production_v1", phase="production"))))
    launcher = tmp_path/"launcher.py"
    launcher.write_text("# immutable test launcher\n")
    revision = tmp_path/"revision.json"
    revision.write_text(json.dumps(dict(schema=1, launcher=str(launcher),
        files={str(launcher):S.file_hash(launcher)})))
    path = S.initialize(root, revision, [], total_cpus=80, workers=32, memory_gb=16)
    return path, json.loads(path.read_text()), Scheduler(), Path(S.__file__)


def running_report():
    return dict(status="running", tasks=dict(ready=1000), audits={}, qualified_cases=0, total_cases=189)


def test_dynamic_chunks_preserve_exact_cpu_cap_and_remainder(setup):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program)
    assert [s["workers"] for s in record["slots"]] == [32, 32, 16]
    assert record["allocated_worker_cpus"] == 80
    assert record["slots"][-1]["memory_gb"] == 8
    S.replenish(path, record, scheduler, program)
    assert len(scheduler.submissions) == 3


def test_predecessors_must_finish_before_any_new_allocation(setup):
    path, record, scheduler, program = setup
    record["predecessors"] = ["old.pbs02"]
    scheduler.states["old.pbs02"] = "R"
    assert not S.reconcile(path, record, scheduler)
    assert scheduler.submissions == []
    scheduler.states["old.pbs02"] = "F"
    assert S.reconcile(path, record, scheduler)
    assert record["predecessors_verified"]


def test_public_spillover_uses_supported_route_under_shared_cap(setup):
    path, record, scheduler, program = setup
    old = scheduler.capacity
    def capacity(routes):
        result = old(routes)
        result["admission"]["idle"]["available"] = 0
        return result
    scheduler.capacity = capacity
    S.replenish(path, record, scheduler, program)
    assert len(scheduler.submissions) == 3
    assert all(cmd[cmd.index("-q")+1] == "p72" for cmd, _ in scheduler.submissions)
    assert all("-J" not in cmd for cmd, _ in scheduler.submissions)
    assert record["allocated_worker_cpus"] == 80


def test_finished_allocation_renews_without_generation_limit(setup):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program)
    first = record["slots"][0]["submissions"][0]["job_id"]
    scheduler.states[first] = "F"
    record["slots"][0]["allocations_used"] = 100
    S.reconcile(path, record, scheduler)
    S.replenish(path, record, scheduler, program)
    assert record["slots"][0]["allocations_used"] == 101
    assert record["allocated_worker_cpus"] == 80
    assert not record["worker_failures"]


def test_unknown_job_state_cannot_create_duplicates(setup):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program)
    scheduler.states.clear()
    with pytest.raises(RuntimeError, match="Unknown"):
        S.reconcile(path, record, scheduler)
    assert len(scheduler.submissions) == 3


def test_ambiguous_submission_is_never_retried(setup):
    path, record, scheduler, program = setup
    scheduler.error = subprocess.TimeoutExpired("qsub", 60)
    with pytest.raises(RuntimeError, match="Ambiguous"):
        S.replenish(path, record, scheduler, program)
    saved = json.loads(path.read_text())
    assert saved["slots"][0]["submissions"][0]["status"] == "submission_ambiguous"
    with pytest.raises(RuntimeError, match="unresolved"):
        S.reconcile(path, saved, scheduler)
    assert len(scheduler.submissions) == 1


def test_failed_submission_remains_explicit(setup):
    path, record, scheduler, program = setup
    scheduler.submit = lambda *a:SimpleNamespace(returncode=1, stdout="", stderr="quota")
    with pytest.raises(RuntimeError, match="unambiguous"):
        S.replenish(path, record, scheduler, program)
    with pytest.raises(RuntimeError, match="unresolved"):
        S.reconcile(path, record, scheduler)


def test_revision_checks_all_sources_and_pins_manifest(setup):
    path, record, _, _ = setup
    revision_path = Path(record["revision"])
    revision = json.loads(revision_path.read_text())
    dependency = revision_path.with_name("kernel.py")
    dependency.write_text("original")
    revision["files"][str(dependency)] = S.file_hash(dependency)
    revision_path.write_text(json.dumps(revision))
    with pytest.raises(ValueError, match="fixed runtime"):
        S.verify_revision(revision_path, record["revision_sha256"])
    S.verify_revision(revision_path)
    dependency.write_text("changed")
    with pytest.raises(ValueError, match="hash mismatch"):
        S.verify_revision(revision_path)


def test_completion_drains_then_exports_even_with_unqualified_rows(setup, monkeypatch):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program)
    first = record["slots"][0]["submissions"][0]["job_id"]
    scheduler.states[first] = "R"
    monkeypatch.setattr(S, "phase_report", lambda *a:dict(status="complete", campaign_complete=True))
    exports = []
    q = SimpleNamespace(export_progress=lambda root:None, export=lambda root:exports.append(root))
    assert S.tick(path, record, scheduler, program, q) == "draining"
    assert exports == []
    assert (first, False) in scheduler.retirements
    for job in scheduler.states:
        scheduler.states[job] = "F"
    assert S.tick(path, record, scheduler, program, q) == "complete"
    assert exports == [Path(record["production_root"])]


def test_progress_error_is_visible_without_stopping_sampling(setup, monkeypatch):
    path, record, scheduler, program = setup
    monkeypatch.setattr(S, "phase_report", lambda *a:running_report())
    def failed(root):
        raise OSError("storage issue")
    q = SimpleNamespace(export_progress=failed)
    assert S.tick(path, record, scheduler, program, q) == "running"
    assert "storage issue" in record["progress_export_error"]["error"]
    assert len(scheduler.submissions) == 3


def test_actual_failure_budget_drains_without_resubmitting(setup, monkeypatch):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program)
    first = record["slots"][0]["submissions"][0]["job_id"]
    scheduler.states[first] = "F"
    scheduler.exit_codes[first] = 137
    record["settings"]["max_worker_failures"] = 1
    monkeypatch.setattr(S, "phase_report", lambda *a:running_report())
    q = SimpleNamespace(export_progress=lambda root:None)
    assert S.tick(path, record, scheduler, program, q) == "draining"
    assert record["status"] == "worker_failure_limit"
    assert len(record["worker_failures"]) == 1
    assert len(scheduler.submissions) == 3
    S.reconcile(path, record, scheduler)
    assert len(record["worker_failures"]) == 1


def test_terminal_budget_and_execution_outcomes():
    assert S.decision(dict(tasks={}, audits={})) == "blocked"
    assert S.decision(dict(running_report(), stop_requested=True)) == "stopped"
    assert S.decision(dict(running_report(), worker_error={"failure":"pool"})) == "blocked"
    assert S.decision(dict(status="budget_exhausted", tasks={"ready":10})) == "blocked"
    assert S.decision(dict(status="execution_error", tasks={"ready":10})) == "blocked"
    assert S.decision(dict(production_table_ready=True)) == "qualified"
    assert S.decision(dict(campaign_complete=True)) == "complete"


def test_initializer_cannot_overwrite_lifecycle_or_accept_old_workflow(setup):
    path, record, _, _ = setup
    with pytest.raises(ValueError, match="exists"):
        S.initialize(record["production_root"], record["revision"], [], journal=path)
    manifest = Path(record["production_root"])/"manifest.json"
    manifest.write_text(json.dumps(dict(workflow=dict(phase="selection"))))
    with pytest.raises(ValueError, match="literature"):
        S.initialize(record["production_root"], record["revision"], [], journal=path.with_name("other.json"))


def test_worker_runs_one_persistent_pool_without_hourly_restarts(setup, monkeypatch):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program)
    receipt = record["slots"][0]["submissions"][0]
    monkeypatch.setenv("PBS_JOBID", receipt["job_id"])
    monkeypatch.setenv("PBS_NCPUS", "32")
    monkeypatch.setattr(S.signal, "signal", lambda *a:None)
    calls = []
    class Child:
        def __init__(self, command):
            calls.append(command)
        def wait(self, timeout=None):
            return 0
    monkeypatch.setattr(S.subprocess, "Popen", Child)
    S.worker(path, 0, receipt["allocation"], receipt["worker_id"])
    assert len(calls) == 1
    cmd = calls[0]
    assert float(cmd[cmd.index("--max-seconds")+1]) > 71*3600
    assert cmd[cmd.index("--root")+1] == record["production_root"]


def test_worker_refuses_wrong_pbs_identity(setup, monkeypatch):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program)
    receipt = record["slots"][0]["submissions"][0]
    monkeypatch.setenv("PBS_JOBID", "unrecorded.pbs02")
    monkeypatch.setattr(S.signal, "signal", lambda *a:None)
    with pytest.raises(ValueError, match="PBS identity"):
        S.worker(path, 0, receipt["allocation"], receipt["worker_id"])


def test_retirement_race_requires_confirmed_terminal_state(setup):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program)
    receipt = record["slots"][0]["submissions"][0]
    for job in scheduler.states:
        scheduler.states[job] = "F"
    scheduler.retire = lambda *a, **k:SimpleNamespace(returncode=1, stdout="", stderr="finished")
    S.request_drain(path, record, scheduler)
    assert receipt["terminal"] and receipt["retirement_reconciled"]


def test_capacity_uses_vnode_permissions_and_fits_fragmented_hosts():
    def node(cpus, mem, queues, assigned=0, state="free", host="machine"):
        return dict(state=state, resources_available=dict(ncpus=cpus, mem=mem,
            allowed_queues=queues, host=host), resources_assigned=dict(ncpus=assigned, mem="0kb"))
    nodes = dict(parent=node(0, "0b", "idlex"), a=node(32, "16gb", "idlex,publicx", 8),
        b=node(32, "16gb", "idlex,publicx", 16), test=node(256, "512gb", "idle_testx,testq"),
        offline=node(256, "512gb", "idlex", state="offline"))
    hosts = S.free_hosts(nodes)
    assert hosts == [dict(host="machine", queues=["idle", "p72"], cpus=40, memory_gb=32.)]
    settings = dict(workers=256, memory_gb=128, min_workers=16, worker_step=4)
    assert S.fit(hosts[0], settings, 10000) == 40
    assert S.fit(hosts[0], settings, 18) == 16
    assert S.fit(hosts[0], settings, 2) == 2
    assert S.fit(dict(cpus=32, memory_gb=3.), settings, 1000) == 0


def test_largest_useful_fit_and_memory_bound(setup):
    path, record, scheduler, program = setup
    record["settings"].update(workers=256, memory_gb=128, total_cpus=10000)
    scheduler.hosts = [dict(host="large", queues=["idle"], cpus=256, memory_gb=128.),
        dict(host="small", queues=["idle"], cpus=24, memory_gb=12.)]
    S.replenish(path, record, scheduler, program, useful_workers=270)
    assert [s["workers"] for s in record["slots"]] == [256, 14]
    assert record["allocated_worker_cpus"] == 270


def test_queued_jobs_are_not_counted_as_free_cpu_capacity(setup):
    path, record, scheduler, program = setup
    record["settings"].update(total_cpus=10000, max_submissions_per_tick=1)
    scheduler.hosts = [dict(host="one", queues=["idle"], cpus=32, memory_gb=16.)]
    S.replenish(path, record, scheduler, program)
    assert record["slots"][0]["workers"] == 32
    S.replenish(path, record, scheduler, program)
    # Only one separate public fallback may wait; no second idle job consumes
    # the same currently free node while its first request is still queued.
    assert len(scheduler.submissions) == 2
    assert record["slots"][1]["queue"] == "p72"
    S.replenish(path, record, scheduler, program)
    assert len(scheduler.submissions) == 2


def test_pbs_json_does_not_use_broken_owner_filter(monkeypatch):
    commands = []
    def command(args, **kwargs):
        commands.append(args)
        return SimpleNamespace(returncode=0, stdout='{"Jobs":{}}', stderr="")
    monkeypatch.setattr(S.subprocess, "run", command)
    assert S.PBS().jobs() == {}
    assert "-u" not in commands[0]


def test_controller_successor_is_journaled_once_and_uses_queue_minimum(setup, monkeypatch):
    path, record, scheduler, program = setup
    monkeypatch.setenv("PBS_JOBID", "current.pbs02")
    old = scheduler.capacity
    def capacity(routes):
        result = old(routes)
        result["admission"]["idle"]["available"] = 0
        return result
    scheduler.capacity = capacity
    S.schedule_controller_successor(path, record, scheduler, program)
    S.schedule_controller_successor(path, record, scheduler, program)
    assert len(scheduler.submissions) == 1
    command = scheduler.submissions[0][0]
    assert command[command.index("-q")+1] == "p72"
    assert "select=1:ncpus=8:mem=4gb" in command
    assert "depend=afterany:current.pbs02" in command


def test_controller_keeps_small_idle_allocation_when_available(setup, monkeypatch):
    path, record, scheduler, program = setup
    monkeypatch.setenv("PBS_JOBID", "current.pbs02")
    S.schedule_controller_successor(path, record, scheduler, program)
    command = scheduler.submissions[0][0]
    assert command[command.index("-q")+1] == "idle"
    assert "select=1:ncpus=2:mem=4gb" in command


def test_useful_work_caps_new_allocations_without_cancelling_running_ones(setup):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program, useful_workers=20)
    assert record["allocated_worker_cpus"] == 20
    S.replenish(path, record, scheduler, program, useful_workers=2)
    assert record["allocated_worker_cpus"] == 20
    assert scheduler.retirements == []


def test_stop_sentinel_survives_concurrent_journal_replacement(setup, monkeypatch):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program)
    stale = copy.deepcopy(record)
    S.request_stop(path)
    S.save(path, stale)  # Simulate the old controller overwriting a JSON flag.
    loaded = json.loads(path.read_text())
    assert not loaded["stop_requested"]
    monkeypatch.setattr(S, "phase_report", lambda *args:running_report())
    q = SimpleNamespace(export_progress=lambda root:None)
    assert S.tick(path, loaded, scheduler, program, q) == "draining"
    assert loaded["stop_requested"] and loaded["status"] == "stopped"
    assert len(scheduler.submissions) == 3
    assert len(scheduler.retirements) == 3


def test_running_worker_observes_durable_stop_without_controller_signal(setup, monkeypatch):
    path, record, scheduler, program = setup
    S.replenish(path, record, scheduler, program)
    receipt = record["slots"][0]["submissions"][0]
    monkeypatch.setenv("PBS_JOBID", receipt["job_id"])
    monkeypatch.setenv("PBS_NCPUS", "32")
    monkeypatch.setattr(S.signal, "signal", lambda *args:None)
    signals = []
    class Child:
        def __init__(self, command):
            self.command, self.calls = command, 0
        def wait(self, timeout=None):
            self.calls += 1
            if self.calls == 1:
                S.request_stop(path)
                raise subprocess.TimeoutExpired(self.command, timeout)
            return 0
        def poll(self):
            return None
        def send_signal(self, sig):
            signals.append(sig)
    monkeypatch.setattr(S.subprocess, "Popen", Child)
    S.worker(path, 0, receipt["allocation"], receipt["worker_id"])
    assert signals == [S.signal.SIGUSR1]


def test_campaign_stop_file_is_also_respected(setup):
    path, record, scheduler, program = setup
    (Path(record["production_root"])/"STOP").touch()
    assert S.stop_requested(path, record)


def cached_report(record, now):
    return dict(running_report(), signature=record["signature"], runtime=dict(last_control=now-10),
        stop_requested=False, campaign_complete=False, production_table_ready=False,
        completed_collision_trajectories=1234, worker_error=None)


def test_fresh_atomic_status_avoids_database_and_forced_control(setup, monkeypatch):
    path, record, scheduler, program = setup
    root = Path(record["production_root"])
    monkeypatch.setattr(S.time, "time", lambda:1000.)
    expected = cached_report(record, 1000.)
    (root/"status.json").write_text(json.dumps(expected))
    def unexpected(*args, **kwargs):
        raise AssertionError("Fresh status must not acquire the database")
    q = SimpleNamespace(verify=lambda root:dict(signature=record["signature"]),
        controller_tick=unexpected, database=unexpected)
    assert S.phase_report(q, root) == expected


@pytest.mark.parametrize("change", [
    {"signature": "another-campaign"},
    {"runtime": {"last_control": 939.}},
    {"runtime": {"last_control": 1001.}},
    {"runtime": None},
    {"runtime": {"last_control": float("nan")}},
    {"tasks": {"ready": -1}},
    {"audits": []},
    {"stop_requested": None},
    {"qualified_cases": 190},
    {"completed_collision_trajectories": True},
    {"status": "unrecognized"},
])
def test_unusable_atomic_status_falls_back_to_authoritative_control(setup, monkeypatch, change):
    from contextlib import contextmanager
    path, record, scheduler, program = setup
    root = Path(record["production_root"])
    monkeypatch.setattr(S.time, "time", lambda:1000.)
    report = cached_report(record, 1000.)
    report.update(change)
    (root/"status.json").write_text(json.dumps(report))
    calls = []
    @contextmanager
    def database(root):
        calls.append("database")
        yield object()
    q = SimpleNamespace(verify=lambda root:dict(signature=record["signature"]),
        controller_tick=lambda *args, **kwargs:calls.append(kwargs), database=database,
        summary=lambda *args:dict(running_report(), source="database"), get=lambda *args:True)
    actual = S.phase_report(q, root)
    assert calls == [{"force": True}, "database"]
    assert actual["source"] == "database" and actual["stop_requested"]


def test_missing_status_bootstraps_control(setup, monkeypatch):
    from contextlib import contextmanager
    path, record, scheduler, program = setup
    called = []
    @contextmanager
    def database(root):
        yield object()
    q = SimpleNamespace(verify=lambda root:dict(signature=record["signature"]),
        controller_tick=lambda *args, **kwargs:called.append(kwargs), database=database,
        summary=lambda *args:running_report(), get=lambda *args:False)
    assert S.phase_report(q, Path(record["production_root"]))["status"] == "running"
    assert called == [{"force": True}]


def held_by_child(path):
    """An actual other process is needed to contend on POSIX process locks."""
    from contextlib import contextmanager
    import select
    import sys
    @contextmanager
    def hold():
        script = ("import fcntl,sys; f=open(sys.argv[1],'a+'); "
                  "fcntl.lockf(f,fcntl.LOCK_EX|fcntl.LOCK_NB); "
                  "print('locked',flush=True); sys.stdin.readline()")
        child = subprocess.Popen([sys.executable, "-B", "-c", script, str(path)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            assert select.select([child.stdout], [], [], 5)[0], "Lock child did not report readiness"
            assert child.stdout.readline().strip() == "locked"
            yield
        finally:
            if child.poll() is None:
                child.communicate("release\n", timeout=5)
            assert child.returncode == 0
    return hold()


def test_busy_progress_export_defers_while_cpu_admission_continues(setup, monkeypatch):
    path, record, scheduler, program = setup
    root = Path(record["production_root"])
    monkeypatch.setattr(S, "phase_report", lambda *a:running_report())
    exported = []
    q = SimpleNamespace(export_progress=lambda root:exported.append(root))
    with held_by_child(root/"database.lock"):
        assert S.tick(path, record, scheduler, program, q) == "running"
    assert len(scheduler.submissions) == 3
    assert exported == []
    assert record["progress_export_deferred"]["reason"] == "database_busy"
    assert "last_progress_export" not in record
    assert S.tick(path, record, scheduler, program, q) == "running"
    assert exported == [root]
    assert "progress_export_deferred" not in record
    assert record["last_progress_export"] > 0


def test_export_guard_supports_nested_engine_lock_and_releases_after_error(setup):
    import fcntl
    path, record, scheduler, program = setup
    root = Path(record["production_root"])
    def export(root):
        with (root/"database.lock").open("a+") as lock:
            fcntl.lockf(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            raise OSError("export failed")
    with pytest.raises(OSError, match="export failed"):
        S.try_export_progress(SimpleNamespace(export_progress=export), root)
    # An independent process can acquire it immediately after the exception.
    with held_by_child(root/"database.lock"):
        pass


def test_continuous_worker_contention_cannot_defer_exports_forever(setup, monkeypatch):
    path, record, scheduler, program = setup
    now = [1000.]
    monkeypatch.setattr(S.time, "time", lambda:now[0])
    monkeypatch.setattr(S, "phase_report", lambda *a:running_report())
    attempts = []
    def export(q, root, *, blocking=False):
        attempts.append(blocking)
        return blocking
    monkeypatch.setattr(S, "try_export_progress", export)
    assert S.tick(path, record, scheduler, program, None) == "running"
    assert len(scheduler.submissions) == 3
    since = record["progress_export_deferred"]["since"]
    now[0] += S.MAX_PROGRESS_EXPORT_DEFERRAL - 1
    assert S.tick(path, record, scheduler, program, None) == "running"
    assert record["progress_export_deferred"]["since"] == since
    now[0] += 1
    assert S.tick(path, record, scheduler, program, None) == "running"
    assert attempts == [False, False, True]
    assert "progress_export_deferred" not in record
    assert record["last_progress_export"] == now[0]


def test_fresh_status_retains_stop_and_completion_decisions(setup, monkeypatch):
    path, record, scheduler, program = setup
    root = Path(record["production_root"])
    monkeypatch.setattr(S.time, "time", lambda:1000.)
    report = cached_report(record, 1000.)
    report["stop_requested"] = True
    (root/"status.json").write_text(json.dumps(report))
    assert S.decision(S.fresh_status(root, record["signature"])) == "stopped"
    report.update(stop_requested=False, status="complete", campaign_complete=True)
    (root/"status.json").write_text(json.dumps(report))
    assert S.decision(S.fresh_status(root, record["signature"])) == "complete"
