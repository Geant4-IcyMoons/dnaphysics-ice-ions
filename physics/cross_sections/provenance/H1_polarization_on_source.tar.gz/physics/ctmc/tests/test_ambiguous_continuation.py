"""Outward endpoint extension preserves the sampled collision and its prefix.

These synthetic solvers test continuation bookkeeping without CTMC integration.
Physical endpoint comparisons run separately on PBS.
"""
from dataclasses import asdict, replace
import json

import numpy as np
import pytest

from physics.ctmc import continuation as S
from physics.ctmc import qualify as Q
from physics.ctmc.tests.test_qualification import (
    campaign, controls, kernel, make, packet, policy,
)


def _roundtrip(value):
    return json.loads(json.dumps(value, allow_nan=False))


def _scenario(kernel, controls, monkeypatch, *, resolve_at=20., extensions=2,
              fixed_time=False, fail_first_extension=False, first_endpoint=None):
    cfg = Q.config_for(dict(projectile="carbon", nuclear_charge=6, seed=7,
        ensemble="independent_isotropic_sensitivity",
        initialization="projectile_ion_com_balanced"), asdict(controls))
    cfg = replace(cfg, maximum_boundary_extensions=extensions)
    initial = np.zeros(12)
    initial[0] = 5.
    draws, calls, states = [], [], []
    failed = False

    def draw(**kwargs):
        draws.append(kwargs["rng"].random())
        return initial.copy()

    def energy(state, *args):
        # Later accepted endpoints deliberately have larger, still valid drift.
        return 1. + state[3] * 1e-8

    def binding(state, core, *args):
        return -1. if core == 0 or state[0] < resolve_at else 1.

    def segment(backend, sampled, minimum_time, ref, other, rtol, atol,
                max_step, minimum_radius, ref_mass, other_mass, maximum_steps,
                fixed, terminal, power, drift, budget, checkpoint):
        nonlocal failed
        np.testing.assert_array_equal(sampled, initial)
        assert minimum_time == 1.
        previous = 0 if checkpoint is None else checkpoint["integral"][0]
        calls.append(dict(terminal=terminal, checkpoint=_roundtrip(checkpoint),
                          rtol=rtol, initial=sampled.copy()))
        work = S._new_work()
        if fail_first_extension and terminal > 10. and not failed:
            failed = True
            work["accepted_steps"] = 1
            return dict(status="done", state=None, work=work)
        target = int(first_endpoint if terminal == 10. and first_endpoint else terminal)
        count = min(budget, target - previous)
        assert count >= 0
        accepted = previous + count
        state = initial.copy()
        state[0] = float(accepted)
        state[3] = float(accepted) / 10.
        floating = np.zeros(29)
        floating[:12] = state
        floating[24] = float(accepted)
        integral = np.zeros(5, dtype=int)
        integral[0] = accepted
        saved = dict(floating=floating.tolist(), integral=integral.tolist())
        work["accepted_steps"] = count
        if accepted < target:
            return dict(status="yielded", continuation=saved, work=work)
        states.append(state.copy())
        return dict(status="done", state=state, continuation=saved, work=work)

    monkeypatch.setattr(kernel, "_build_initial_relative_state", draw)
    monkeypatch.setattr(kernel, "relative_three_body_energy", energy)
    monkeypatch.setattr(kernel, "_electron_core_energy_relative", binding)
    monkeypatch.setattr(S, "_native_segment", segment)
    kwargs = dict(energy_keV_u=100., charge_state=6, impact_parameter_au=.7,
        bound_to="target", binding_eV=kernel.WATER_ORBITALS[0].binding_eV,
        start_separation_au=5., minimum_integration_time_au=1.,
        minimum_terminal_core_separation_au=10., config=cfg,
        retain_ambiguous_endpoint=True, fixed_time_endpoint=fixed_time,
        backend_module=object())
    return kwargs, draws, calls, states


def _finish(kernel, kwargs, segment_steps):
    checkpoint = None
    snapshots = []
    for iteration in range(1000):
        result = S.simulate_one_trajectory_segment(kernel, **kwargs,
            rng=np.random.default_rng(771 + iteration), segment_steps=segment_steps,
            continuation=checkpoint)
        if result["status"] == "done":
            return result, snapshots
        assert "result" not in result
        checkpoint = _roundtrip(result["continuation"])
        snapshots.append(checkpoint)
    pytest.fail("Bounded synthetic extension did not finish")


@pytest.mark.parametrize("segment_steps", [1, 7, 10, 1000])
def test_ambiguous_extension_keeps_original_draw_energy_and_prefix(
        kernel, controls, monkeypatch, segment_steps):
    kwargs, draws, calls, states = _scenario(kernel, controls, monkeypatch)
    result, snapshots = _finish(kernel, kwargs, segment_steps)
    assert result["result"] == ["retained_target", True, abs(1. + 2e-8 - 1.)]
    assert len(draws) == 1
    assert result["work"]["accepted_steps"] == 20
    assert result["work"]["integrator_attempts"] == 1
    assert result["work"]["boundary_extensions"] == 1
    first_extension = next(c for c in calls if c["terminal"] > 10.)
    assert first_extension["terminal"] == 20.
    assert first_extension["checkpoint"]["integral"][0] == 10
    np.testing.assert_array_equal(first_extension["checkpoint"]["floating"][:12], states[0])
    for saved in snapshots:
        assert saved["initial_energy"] == 1.
        assert saved["initial"][0] == 5.
    # A lower-drift ambiguous endpoint must never replace the later outcome.
    assert result["result"][2] > abs(1. + 1e-8 - 1.)


def test_nonambiguous_collision_unchanged_when_extension_disabled(
        kernel, controls, monkeypatch):
    outputs = []
    for extensions in (0, 3):
        kwargs, draws, calls, states = _scenario(kernel, controls, monkeypatch,
            resolve_at=10., extensions=extensions)
        result, _ = _finish(kernel, kwargs, 3)
        assert len(draws) == 1
        assert {c["terminal"] for c in calls} == {10.}
        assert result["work"]["boundary_extensions"] == 0
        outputs.append((result, states[-1].tobytes()))
    assert outputs[0] == outputs[1]


@pytest.mark.parametrize("segment_steps", [3, 1000])
def test_persistent_ambiguity_has_finite_outward_limit(
        kernel, controls, monkeypatch, segment_steps):
    kwargs, draws, calls, _ = _scenario(kernel, controls, monkeypatch,
                                      resolve_at=np.inf, extensions=2)
    result, _ = _finish(kernel, kwargs, segment_steps)
    assert result["result"][:2] == ["ambiguous_bound", True]
    assert len(draws) == 1
    assert result["work"]["accepted_steps"] == 40
    assert result["work"]["boundary_extensions"] == 2
    assert sorted({c["terminal"] for c in calls}) == [10., 20., 40.]


def test_fixed_time_diagnostic_does_not_extend_ambiguous_endpoint(
        kernel, controls, monkeypatch):
    kwargs, draws, calls, _ = _scenario(kernel, controls, monkeypatch,
                                      resolve_at=np.inf, fixed_time=True)
    result, _ = _finish(kernel, kwargs, 1000)
    assert result["result"][:2] == ["ambiguous_bound", True]
    assert len(draws) == 1 and len(calls) == 1
    assert result["work"]["boundary_extensions"] == 0


def test_minimum_time_overshoot_extends_from_actual_separation(kernel, controls, monkeypatch):
    kwargs, draws, calls, states = _scenario(kernel, controls, monkeypatch,
        resolve_at=60., first_endpoint=30.)
    result, _ = _finish(kernel, kwargs, 7)
    assert result["result"][:2] == ["retained_target", True]
    assert len(draws) == 1
    assert states[0][0] == 30.
    assert sorted({c['terminal'] for c in calls}) == [10., 60.]
    assert result['work']['boundary_extensions'] == 1


def test_failed_extension_retries_original_sample_at_new_boundary(
        kernel, controls, monkeypatch):
    kwargs, draws, calls, _ = _scenario(kernel, controls, monkeypatch,
                                      fail_first_extension=True)
    result, _ = _finish(kernel, kwargs, 7)
    assert result["result"][0:2] == ["retained_target", True]
    assert len(draws) == 1
    retry = next(c for c in calls if c["terminal"] == 20. and c["checkpoint"] is None)
    assert retry["rtol"] == .1 * kwargs["config"].retry_rtol
    assert retry["initial"][0] == 5.
    assert result["work"]["integrator_attempts"] == 2


def test_exhausted_endpoint_ambiguity_stops_without_global_flight_refinement(campaign):
    root, manifest = campaign
    exp = make(root, manifest)
    with Q.database(root) as db:
        rows = db.execute("SELECT * FROM tasks WHERE experiment=? AND state='ready' ORDER BY id LIMIT 2",
                          (exp['id'],)).fetchall()
        for row in rows:
            db.execute("UPDATE tasks SET state='running',owner='test' WHERE id=?", (row['id'],))
        Q.commit_result(db, dict(rows[0]), packet(exp, rows[0]), 'test')
        Q.commit_result(db, dict(rows[1]), dict(attempts=1,
            failure=dict(outcome='ambiguous_bound', drift=1e-8)), 'test')
        key = Q.case_key(exp['energy'], exp['charge'])
        case = Q.get(db, 'cases', key)
        case['experiments']['bmax'] = exp['id']
        before = _roundtrip({name:case[name] for name in ('controls', 'levels', 'experiments')})
        Q.assess_case(db, manifest, key, case, force=True)
        assert case['status'] == 'numerical_limit'
        assert {name:case[name] for name in before} == before
        assert 'certificate' not in case
        assert db.execute("SELECT state FROM tasks WHERE id=?", (rows[0]['id'],)).fetchone()[0] == 'done'
