"""A runtime exception preserves restart data and stops shared production."""
import json
import zlib

from physics.ctmc import qualify as Q
from physics.ctmc.tests.test_qualification import campaign, controls, policy, kernel
from physics.ctmc.tests.test_packet_continuation import packet, claim


def test_runtime_failure_keeps_completed_electrons_and_last_solver_state(packet, monkeypatch):
    root, manifest, exp, task, clock, runtime = packet
    calls = []
    checkpoint = dict(initial=[1., 2.], accepted_steps=7)
    def segment(**kwargs):
        calls.append(kwargs.get('continuation'))
        if len(calls) <= 2:
            return dict(status='done', result=['retained_target', True, 0.])
        if len(calls) == 3:
            return dict(status='yielded', continuation=checkpoint)
        assert kwargs['continuation'] == checkpoint
        raise TypeError('native runtime fixture')
    monkeypatch.setattr(Q.C, 'simulate_one_trajectory_segment', segment)
    task = claim(root, task)
    result = Q.execute(task, exp, manifest, runtime)
    assert result['failure']['outcome'] == 'execution_error'
    assert 'TypeError' in result['failure']['traceback']
    assert len(result['continuation']['completed']) == 2
    assert result['continuation']['active']['state'] == checkpoint
    with Q.database(root) as db:
        Q.commit_result(db, task, result, 'test')
        assert Q.get(db, 'meta', 'stop_requested') is True
        assert Q.get(db, 'meta', 'last_worker_error')['task'] == task['id']
        assert Q.get(db, 'experiments', exp['id'])['completed'] == exp['completed']
        state, blob = db.execute('SELECT state,result FROM tasks WHERE id=?', (task['id'],)).fetchone()
        assert state == 'failed'
        assert json.loads(zlib.decompress(blob))['continuation'] == result['continuation']
    monkeypatch.setattr(Q, 'advance', lambda *args: (_ for _ in ()).throw(AssertionError('runtime error must not prune cases')))
    assert Q.controller_tick(root, manifest, 'test', force=True)
    with Q.database(root) as db:
        assert Q.get(db, 'cases', exp['case'])['status'] != 'execution_error'


def test_future_exception_keeps_previously_committed_packet_checkpoint(packet):
    root, manifest, exp, task, clock, runtime = packet
    checkpoint = dict(schema=1, task=task['id'], signature='saved', completed=[], active=None)
    task = claim(root, task)
    with Q.database(root) as db:
        db.execute('UPDATE tasks SET result=?,resuming=1 WHERE id=?',
            (zlib.compress(json.dumps(dict(continuation=checkpoint)).encode()), task['id']))
        Q.commit_result(db, task, dict(failure=dict(outcome='execution_error', error='future failure'), attempts=0), 'test')
        blob = db.execute('SELECT result FROM tasks WHERE id=?', (task['id'],)).fetchone()[0]
        assert json.loads(zlib.decompress(blob))['continuation'] == checkpoint
        assert Q.get(db, 'meta', 'stop_requested') is True
