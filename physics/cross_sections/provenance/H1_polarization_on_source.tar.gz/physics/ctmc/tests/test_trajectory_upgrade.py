"""Explicit V1 migration preserves numerical data; no trajectories execute.

The legacy fixture was generated from the frozen V1 CTMCConfig, payload
expression and signature helper, rather than the new payload constructor.
Frozen continuation SHA256: 104e7dc93512bf7c8137e588c897dc97eec4c8974a4ed539ea5532c3c52516a7
Frozen kernel SHA256: 73b717b2ced7e86bcd05f6ea0d0ea16cdff2a655948450504ecf31d9d106a22a
"""
import copy
from dataclasses import replace
import hashlib
import json
import math

import pytest

from physics.ctmc import continuation as S
from physics.ctmc.tests.test_qualification import kernel


LEGACY = dict(energy_keV_u=50., charge_state=3, impact_parameter_au=.7,
    bound_to="target", binding_eV=12.61, start_separation_au=1000.,
    minimum_integration_time_au=1000., fixed_time_endpoint=False,
    projectile_velocity_override_au=None,
    minimum_terminal_core_separation_au=1000., garvey_role_term=False,
    reference_method="RK45", config=dict(backend="numba", trajectories=1,
        trajectory_chunk_size=1, target_bmax_au=(25.,)*5, loss_bmax_au=(25.,)*6,
        radial_grid_points=4096, start_separation_au=(1000.,),
        boundary_extension_factor=2, minimum_integration_time_au=(1000.,),
        rtol=1e-8, atol=1e-10, retry_rtol=1e-8, retry_atol=1e-10,
        max_step_au=math.inf, minimum_radius_au=1e-10,
        maximum_relative_energy_drift=1e-6, max_failure_fraction=0,
        maximum_integration_steps=1000000, seed=7, projectile="carbon",
        initial_ensemble="independent_isotropic_sensitivity",
        projectile_loss_initialization="projectile_ion_com_balanced",
        channel_scope="all", expanded_impact_domain=True,
        terminal_core_distance_au=(1000.,), case_convergence_candidate=False))
LEGACY_SIGNATURE = "03447e540264540fca2ae422315316d470e84573d556b39a709c89c1ebbb7d6a"


def legacy_signature(payload):
    normalized = copy.deepcopy(payload)
    normalized["config"]["max_step_au"] = "Infinity"
    return hashlib.sha256(json.dumps(normalized, sort_keys=True,
        separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def specimen(kernel, kind="native"):
    legacy = copy.deepcopy(LEGACY)
    if kind == "reference":
        legacy["config"]["backend"] = "scipy"
    parameters = {k:v for k,v in legacy.items() if k != "config"}
    parameters["config"] = kernel.CTMCConfig(**legacy["config"], maximum_boundary_extensions=3)
    solver = (dict(floating=[i/10. for i in range(29)], integral=[7, 3, 10, 1, 1])
              if kind == "native" else dict(phase="flight", elapsed=17.25,
                  state=[i/10. for i in range(18)], solver=None)
              if kind == "reference" else None)
    checkpoint = dict(version=1, signature=legacy_signature(legacy), attempt=2,
        initial=[-0., 1e-300, *[i/10. for i in range(10)]], initial_energy=-1.25,
        best_state=[i/17. for i in range(12)], best_drift=1e-4,
        had_finite_endpoint=True, solver=solver,
        work=dict(accepted_steps=7, rejected_steps=3, rhs_evaluations=15,
                  restore_rhs_evaluations=1, integrator_attempts=2))
    return parameters, checkpoint


@pytest.mark.parametrize("kind", ["native", "reference", "retry_boundary"])
def test_upgrade_preserves_all_existing_numerical_values_and_original_input(kernel, kind):
    assert legacy_signature(LEGACY) == LEGACY_SIGNATURE
    parameters, original = specimen(kernel, kind)
    before = json.dumps(original, separators=(",", ":"), allow_nan=False)
    upgraded = S.upgrade_trajectory_checkpoint(original, **parameters)
    assert upgraded["version"] == 2
    assert upgraded["signature"] != original["signature"]
    assert upgraded["signature"] == S._signature(S._trajectory_payload(**parameters))
    assert upgraded["terminal"] == 1000.
    assert upgraded["work"]["boundary_extensions"] == 0
    restored = copy.deepcopy(upgraded)
    restored.pop("terminal")
    restored["work"].pop("boundary_extensions")
    restored.update(version=original["version"], signature=original["signature"])
    assert json.dumps(restored, separators=(",", ":"), allow_nan=False) == before
    upgraded["initial"][0] = 91.
    upgraded["work"]["accepted_steps"] = 92
    if upgraded["solver"] is not None:
        upgraded["solver"]["modified"] = True
    assert json.dumps(original, separators=(",", ":"), allow_nan=False) == before


@pytest.mark.parametrize("changed", ["energy", "terminal", "tolerance", "seed", "ensemble"])
def test_upgrade_rejects_changed_old_scientific_configuration(kernel, changed):
    parameters, checkpoint = specimen(kernel)
    if changed == "energy":
        parameters["energy_keV_u"] = 51.
    elif changed == "terminal":
        parameters["minimum_terminal_core_separation_au"] = 2000.
    else:
        field, value = {"tolerance": ("rtol", 1e-9), "seed": ("seed", 8),
                        "ensemble": ("initial_ensemble", "liamsuwan_olson_salop_tangent")}[changed]
        parameters["config"] = replace(parameters["config"], **{field:value})
    with pytest.raises(ValueError, match="Incompatible V1"):
        S.upgrade_trajectory_checkpoint(checkpoint, **parameters)


@pytest.mark.parametrize("changed", ["version", "signature", "terminal", "counter"])
def test_upgrade_rejects_wrong_version_signature_or_existing_new_metadata(kernel, changed):
    parameters, checkpoint = specimen(kernel)
    if changed == "version": checkpoint["version"] = 2
    elif changed == "signature": checkpoint["signature"] = "incorrect"
    elif changed == "terminal": checkpoint["terminal"] = 1000.
    else: checkpoint["work"]["boundary_extensions"] = 0
    with pytest.raises(ValueError):
        S.upgrade_trajectory_checkpoint(checkpoint, **parameters)


def test_normal_resume_rejects_v1_before_any_kernel_work(kernel, monkeypatch):
    parameters, checkpoint = specimen(kernel)
    monkeypatch.setattr(kernel, "_trajectory_cores", lambda *args, **kwargs:
                        pytest.fail("V1 reached the collision kernel without explicit upgrade"))
    with pytest.raises(ValueError, match="Incompatible trajectory checkpoint"):
        S.simulate_one_trajectory_segment(kernel, **parameters,
            rng=None, continuation=checkpoint, retain_ambiguous_endpoint=True)
