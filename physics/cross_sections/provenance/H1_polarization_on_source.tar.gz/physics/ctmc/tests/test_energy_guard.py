"""Fixed-cadence conservation checks reject numerical attempts, never samples."""
from dataclasses import asdict
import json
import os
import sys

import numpy as np
import pytest

from physics.ctmc import continuation as S
from physics.ctmc import qualify as Q
from physics.ctmc.tests.test_qualification import kernel, controls

COMPUTE = pytest.mark.skipif(not os.environ.get('PBS_JOBID'), reason='Integration requires PBS')


def test_failed_attempt_retries_identical_initial_sample(kernel, controls, monkeypatch):
    cfg = Q.config_for(dict(projectile='carbon', nuclear_charge=6, seed=7,
        ensemble='independent_isotropic_sensitivity',
        initialization='projectile_ion_com_balanced'), asdict(controls))
    initial = np.arange(12, dtype=float)
    draws, attempts = [], []
    monkeypatch.setattr(kernel, '_build_initial_relative_state',
        lambda **kwargs: draws.append(kwargs['rng'].random()) or initial.copy())
    monkeypatch.setattr(kernel, 'relative_three_body_energy', lambda *args: 1.)
    monkeypatch.setattr(kernel, '_electron_core_energy_relative',
        lambda *args: -1. if args[1] == 0 else 1.)
    def segment(*args):
        attempts.append(args[1].copy())
        work = S._new_work()
        work['accepted_steps'] = 256
        return dict(status='done', state=None if len(attempts) == 1 else initial.copy(), work=work)
    monkeypatch.setattr(S, '_native_segment', segment)
    kwargs = dict(energy_keV_u=100., charge_state=6, impact_parameter_au=.7,
        bound_to='target', binding_eV=kernel.WATER_ORBITALS[0].binding_eV,
        start_separation_au=1000., minimum_integration_time_au=1000.,
        minimum_terminal_core_separation_au=1000., config=cfg,
        retain_ambiguous_endpoint=True)
    first = S.simulate_one_trajectory_segment(kernel, **kwargs,
        rng=np.random.default_rng(1), segment_steps=256)
    assert first['status'] == 'yielded' and 'result' not in first
    assert first['continuation']['attempt'] == 1
    assert first['continuation']['best_state'] is None
    second = S.simulate_one_trajectory_segment(kernel, **kwargs,
        rng=np.random.default_rng(999), segment_steps=256,
        continuation=json.loads(json.dumps(first['continuation'])))
    assert second['result'] == ['retained_target', True, 0.]
    assert len(draws) == 1
    np.testing.assert_array_equal(attempts[0], attempts[1])
    assert second['work']['integrator_attempts'] == 2


def _zero_force_args():
    state = np.array([1., 0., 0., .25, .1, 0., 0., 0., 0., 1., 0., 0.])
    p = np.array([0., 0., 1., 1.])
    return [state, 3., p, p, 1e-9, 1e-11, .005, 1e-10, 1836., 21868., 10000, True, -1.]


@COMPUTE
def test_valid_plain_trajectory_unchanged_by_guard(kernel):
    backend = sys.modules[kernel.integrate_relative_dop853.__module__]
    args = _zero_force_args()
    baseline = backend.integrate_relative_dop853(*args)
    guarded = backend.integrate_relative_dop853(*args, maximum_relative_energy_drift=1e-6)
    assert baseline[0] and guarded[0] and baseline[2] > 256
    np.testing.assert_array_equal(baseline[1], guarded[1])
    assert baseline[2:] == guarded[2:]


@COMPUTE
def test_energy_guard_is_independent_of_segment_partition(kernel):
    backend = sys.modules[kernel.integrate_relative_dop853.__module__]
    args = _zero_force_args()
    first = backend._integrate_relative_dop853_segment(*args, 1)
    assert first[0] == 2
    floating, integral = first[4].copy(), first[5].copy()
    # Inject a known numerical fault into a saved state. Refresh the derivative
    # consistently so the only violated condition is energy conservation.
    floating[9:12] *= 2.
    backend._relative_rhs(floating[:12], floating[12:24], args[2], args[3],
                          args[7], args[8], args[9])
    expected = backend._integrate_relative_dop853_segment(*args, 1000,
        floating, integral, maximum_relative_energy_drift=1e-6)
    assert expected[0] == 0 and expected[2] == 256
    assert expected[4].size == expected[5].size == 0
    for _ in range(100):
        actual = backend._integrate_relative_dop853_segment(*args, 17,
            floating, integral, maximum_relative_energy_drift=1e-6)
        if actual[0] != 2:
            break
        floating = np.array(json.loads(json.dumps(actual[4].tolist())))
        integral = np.array(json.loads(json.dumps(actual[5].tolist())), dtype=np.int64)
    else:
        pytest.fail('The deterministic energy boundary was not reached')
    assert actual[0] == expected[0] and actual[2:4] == expected[2:4]
    np.testing.assert_array_equal(actual[1], expected[1])


@COMPUTE
def test_old_checkpoint_at_energy_boundary_fails_without_advancing(kernel):
    backend = sys.modules[kernel.integrate_relative_dop853.__module__]
    args = _zero_force_args()
    checkpoint = backend._integrate_relative_dop853_segment(*args, 256)
    assert checkpoint[0] == 2 and checkpoint[2] == 256
    floating, integral = checkpoint[4].copy(), checkpoint[5].copy()
    floating[9:12] *= 2.
    guarded = backend._integrate_relative_dop853_segment(*args, 1000,
        floating, integral, maximum_relative_energy_drift=1e-6)
    assert guarded[0] == 0 and guarded[2:4] == checkpoint[2:4]
