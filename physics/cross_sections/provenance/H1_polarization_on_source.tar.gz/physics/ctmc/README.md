# Carbon CTMC production

The retained workflow checks numerical settings and then samples independent
production streams in variance-guided batches. COM-balanced initialization and
independently isotropic microcanonical electron sampling are retained. Each of
189 carbon charge–energy cases advances independently (C0–C6+, 27 energies).

## Numerical settings

[Liamsuwan & Nikjoo (2013), §2.1, p. 647](https://doi.org/10.1088/0031-9155/58/3/641)
choose the shortest converged integration interval using small trial samples.
They report launch separations of 1000–10000 au, minimum integration intervals
of 1000 atomic time units at intermediate energies and 10000 at low energies,
and target-orbital impact cutoffs of 1–25 au, with 10–20 au for projectile loss.
Their final sampling exceeds 10000 trajectories per impact parameter. These
values guide our starting trials; they do not prescribe our exact settings.

[carbon_production.json](carbon_production.json) is the shared specification.
The initial launch and outgoing distances are 10000 au at energies up to
25 keV/u, and 1000 au above that boundary. Minimum time has the same numerical
values in atomic time units. This energy-dependent distance rule is a tested
starting proposal, not a published interpolation formula. The common initial
impact cutoff is 25 au. Strata retain boundaries at 1, 5, 10 and 20 au to resolve
the compact orbitals without assigning unvalidated separate orbital cutoffs.
Every electron within a packet uses the same impact parameter.

Only three numerical comparisons remain:

1. Compare the impact cutoff with twice that cutoff. The additional annulus
   has 10000 predeclared packet samples; interior strata start at 512.
2. Double launch distance, outgoing distance and minimum integration time
   together, testing whether the shorter collision interval is sufficient.
3. Tighten the integration tolerances tenfold, double radial quadrature
   resolution, and reduce the minimum numerical radius tenfold together.

Positive required total rates pass a comparison when the measured change
is at most 5% and its paired standard error meets the effective 5% or 10%
statistical target, relative to the smaller estimate. This is
our practical observed-convergence criterion, not a literature-mandated
percentage or a bound on physical bias. For the binary charge-decrease total, a proposed rejection also requires exact
paired-event evidence (McNemar/binomial) in at least one impact stratum, with
Bonferroni adjustment across the sampled strata. This prevents sparse counts
such as zero versus four from forcing longer flights solely through a normal
approximation. This is an additional rejection guard, not a new acceptance
rule or a repeated-look confidence guarantee. See the
[exact McNemar documentation](https://www.statsmodels.org/stable/generated/statsmodels.stats.contingency_tables.mcnemar.html).
A clearly resolved change selects the
more conservative setting and repeats the necessary comparisons. Noise alone
does not force longer flights. Unresolved comparisons receive repeated variance-guided batches, with each
stratum growing by at most 20% (rounded up to one task block). Additional work
is concentrated using measured variance and CPU cost. The reference sample
count is fixed when an experiment starts, or at migration for an existing
experiment. If the estimated total needed for 5% precision exceeds eleven times
that reference, the statistical target becomes 10%. This resource policy was
chosen by the user; it is not a literature-prescribed tolerance. The observed
numerical-change criterion remains 5%, and resolved changes still refine the
settings. There is no sampling or total electron-trajectory cap. Numerical
refinement and integration-failure limits remain explicit.

When production resolves a rate that was unobserved in a settings comparison,
the case automatically reopens that comparison. Completed production samples
are retained. The production stratum variances guide additional sampling only;
the paired comparison retains its own estimates and errors. A reopened check
cannot pass merely because both arms remain unobserved. The first planning
proxy assumes equal marginal variances and independent arms; measured paired
variance replaces that proxy as soon as the comparison observes the rate.
Existing production without saved stratum moments receives a new moment audit,
not new trajectories. A changed numerical setting still requires production at
the new setting; incompatible samples are never pooled.

Zero observations are not evidence of exact absence. Both-arm unobserved rates
may proceed to production, carrying an unresolved numerical flag. A rate seen
in only one arm remains subject to the comparison. Zero-event upper limits are
reported; they do not impose a simultaneous omitted-tail release gate.
[Olson & Salop (1977), pp. 532–533](https://doi.org/10.1103/PhysRevA.16.531)
explicitly discuss the cost of excessive impact cutoffs and longer propagation
for exceptional ambiguous outcomes. When an energy-valid endpoint remains
bound to both centres, only that trajectory continues farther outward. Its
original incoming state, minimum time, conserved-energy reference and accepted
integration prefix are retained. Each extension doubles the actual outgoing
separation, with at most three extensions under the current `max_axis_levels`
resource limit. Three doublings are our finite computing allowance, not a
published accuracy standard. Remaining ambiguity produces an explicit
`numerical_limit`; it does not restart the whole case from farther away.
The separate flight comparison still determines whether the ordinary settings
need changing. Ambiguous or failed samples never enter a surviving-only mean.

## Production and uncertainty

The last numerical pilot selects the first independent production cohort.
Production then receives the same variance-guided extensions until required
charge-changing totals meet their effective estimated statistical-error target.
Unobserved required production rates receive more samples, not a precise-zero
label. Extremely rare or zero-probability rates may therefore never satisfy a
relative-error target; uncapped sampling is not a completion guarantee.

The initial production floor is 2048 packets per annulus. Completed samples
remain in their original settings and random streams. Repeated assessment
makes the stopping time data-dependent: standard errors are estimates, and
conventional zero-event limits are diagnostics without a nominal coverage
claim at stopping. No simultaneous or anytime confidence guarantee is asserted.

A 5% statistical target has CTMC precedent in
[Al Atawneh (2024), Eqs. 14–15](https://doi.org/10.3390/atoms12120063), for a
different collision system. Our stratified packet variance retains covariance
between channel contributions and between the two charge-changing totals.
The count-only uncertainty formula cannot replace this weighted estimator.
Pointwise one-sided 95% zero-event limits are distinct from standard errors;
there is no campaign-wide, repeated-look or infinite-tail confidence guarantee.

`current_cross_sections.csv` is updated throughout the calculation. Completed
cases receive independent production estimates; unfinished cases retain
explicitly provisional pilot estimates. After all cases finish or reach an
explicit limit, `cross_sections.csv` and `production_table.json` contain the
results and unresolved cases. Completion does not imply every precision or
numerical check passed. The fields `precision_met`,
`numerical_qualification_met` and `qualified` retain that distinction.

`equilibrium_fractions.csv` is available separately for each energy after all
seven production rows exist. Positive adjacent rates give equilibrium
fractions, mean charge and first-order propagated errors. Required unobserved
rates produce an unresolved equilibrium record. No artificial positive rate
floor is used. COM balancing alone does not establish agreement with experiment
or explain a stopping-cross-section discrepancy.

## Running and restarting

The active run is `runs/carbon_production/`. Its manifest and `source/` freeze
all executed code. Completed packets and bounded in-progress solver state are
saved atomically; deterministic sample identities are independent of worker
count. Eight-packet blocks reduce database task traffic while bounded solver
checkpoints retain partial work. The controller uses persistent workers and fits useful CPU chunks to
eligible free resources. The active pool uses `idle`: the public queue was at
its aggregate CPU limit during launch. The controller also supports the `p72`
route when its capacity makes it useful. It maintains a 10000-worker-CPU target,
renews ended allocations, and observes queue limits. Availability can prevent
the full target from running simultaneously.

Routine admission reads recent signed status output from the workers. If that
output is missing or stale, the controller refreshes it from the ledger.
Workers commit completed packets and refill freed processes in one transaction;
they also collect completions that arrived while waiting for that transaction.
Successful results are retained when a neighboring process fails. Optional
coordination skips a busy ledger. Periodic exports normally defer
while the database is busy. After five minutes of deferral, an export takes an
ordinary ledger turn to prevent indefinite postponement of the current table.
Final export still completes after workers drain.

Ready continuations use a partial index on their last checkpoint time and task
ID. Timing-table triggers maintain that cached ordering in the same transaction.
This avoids joining and sorting every checkpoint while holding the shared
ledger lock. The migration preserves the previous ordering, completed results,
sample identities and numerical state; queue speed is measured separately from
trajectory and whole-run throughput.

Before spawning its workers, each allocation prepares the four native solver
interfaces under a shared compiler-cache lock. Fresh and resumed calls use
the same scalar types; preparation is serialized across allocations and CPU
architectures. A packet runtime exception stops the campaign and retains completed
electrons and the last bounded checkpoint for repair. Such an exception does
not count as a physical outcome or cause unrelated cases to be pruned.

```bash
python -B physics/ctmc/runs/carbon_production/source/launch.py status \
  --root physics/ctmc/runs/carbon_production
python -B physics/ctmc/runs/carbon_production/source/supervise.py stop \
  --journal physics/ctmc/runs/carbon_production/pool.json
```

The stop command writes a dedicated durable sentinel. Shared journal updates
cannot erase the request. Workers drain their current bounded segment and retain
completed data. Resuming requires clearing the stop sentinel intentionally and
restarting the controller; a changed numerical manifest cannot resume silently.

The retained tests cover estimators, numerical planning, complete synthetic
production/export, scheduler admission, COM/binding, radial quadrature and
solver continuation. [verification.json](verification.json) records actual
software and compute checks; [literature_validation.json](literature_validation.json)
records source provenance and sampler measurements. These are implementation
checks, not validation of all 189 physical cross sections. Historical run data
are not pooled into the new production estimates.

## Runtime verification

Plain DOP853 checks the existing energy-drift allowance every 256 accepted
steps. An excursion ends that numerical attempt and retries the same initial
sample; it is not an accepted physical outcome or a discarded collision.
The cadence follows the global step counter, so checkpoint segmentation does
not change the decision. Conservation monitoring is distinct from the local
Runge--Kutta error control; the original
[DOP853 implementation](https://www.unige.ch/~hairer/prog/nonstiff/dop853.f)
supports monitoring and interruption at accepted steps. The cadence and
existing numerical allowance are implementation choices, not prescribed CTMC
literature tolerances.

Outgoing continuation retains the native solver's accepted state, derivative,
step size, reference frame and counters. V1 checkpoints require an explicit,
verified upgrade before the V2 runtime will resume them. The upgrade changes
only version/signature and extension metadata. The bounded
[outgoing-extension check](runs/carbon_production/endpoint_extension_validation.json)
resolved four recorded ambiguous trajectories with one local extension each,
preserved two ordinary control endpoints, and verified native checkpoint
upgrades and segmentation. These selected checks establish implementation
behaviour; full-case numerical comparisons still determine convergence.

`runs/carbon_production/monitoring.json` records observed work, allocations and
stage transitions. `flight_timing.json` contains a controlled six-trajectory
comparison of the previous and current flight settings. Its measured timing
ratio applies to those trajectories; changed collision phases and outcomes
mean it establishes neither cross-section equivalence nor a campaign speedup.

The regularized solver includes velocity projection onto the initial total
energy. This is an additional numerical approximation to time regularization;
conservation after projection is not an independent accuracy check. Numerical
comparisons must therefore include outcome or trajectory comparisons with a
tighter or independent integration. General projection methods are established,
but their preservation of other dynamical properties depends on the method
([Hairer, 2000](https://www.unige.ch/~hairer/preprints/symproj.pdf)).
