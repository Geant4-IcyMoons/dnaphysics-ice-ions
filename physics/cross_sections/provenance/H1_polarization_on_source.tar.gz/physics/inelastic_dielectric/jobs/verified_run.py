"""Run generation and independently verify the four exported products."""
import json
import os
from pathlib import Path
import subprocess
import sys
import numpy as np
from tqdm import tqdm
from physics.inelastic_dielectric.checkpoints import atomic_text, source_digest


def audit(paths, expected_energies):
    if len(paths) != 4:
        raise ValueError(f"Expected four case-specific DAT files, found {len(paths)}")
    for path in tqdm(sorted(paths), desc="Verifying final tables", unit="file"):
        if not path.name.startswith('sigmadiff_'):
            continue
        dcs = np.loadtxt(path)
        tcs = np.loadtxt(path.with_name(path.name.replace('sigmadiff_', 'sigma_', 1)))
        if not np.isfinite(dcs).all() or not np.isfinite(tcs).all():
            raise ValueError(f"Nonfinite table: {path}")
        if np.any(dcs[:, 2:] < 0) or np.any(tcs[:, 1:] < 0):
            raise ValueError(f"Negative table: {path}")
        starts = np.r_[0, np.flatnonzero(np.diff(dcs[:, 0]) != 0)+1]
        if len(starts) != expected_energies or not np.array_equal(dcs[starts, 0], tcs[:, 0]):
            raise ValueError(f"Incident grid mismatch: {path}")
        if not np.all(np.diff(tcs[:, 0]) > 0):
            raise ValueError(f"Unordered incident grid: {path}")
        for i, (lo, hi) in enumerate(zip(starts, np.r_[starts[1:], len(dcs)])):
            w = dcs[lo:hi, 1]
            if len(w) < 2 or not np.all(np.diff(w) > 0):
                raise ValueError(f"Invalid loss grid: {path}")
            if not np.allclose(np.trapezoid(dcs[lo:hi, 2:], w, axis=0), tcs[i, 1:],
                               rtol=1e-10, atol=1e-100):
                raise ValueError(f"DCS/TCS mismatch: {path}")


def main():
    command = sys.argv[1:]
    if command and command[0] == '--':
        command.pop(0)
    cache = Path(os.environ['CACHE_DIR'])
    marker = cache/'completion.json'
    marker.unlink(missing_ok=True)
    rc = subprocess.call(command)
    report = dict(source_sha256=source_digest(), generator_exit=rc, status='generation_failed')
    if rc == 0:
        try:
            paths = []
            for p in Path(os.environ['OUTPUT_TABLE_DIR']).rglob('*.dat'):
                with p.open() as stream:
                    meta = json.loads(stream.readline().split(': ', 1)[1])
                if (meta.get('projectile_charge_state') == int(os.environ['CHARGE_STATE'])
                        and meta.get('ice_type') == os.environ['ICE_TYPE']
                        and bool(meta.get('include_barkas_dcs')) == (os.environ['POLARIZATION'] == 'true')
                        and ('rpwba' in p.name) == (os.environ['RPWBA'] == 'true')):
                    if meta.get('diagnostic_only'):
                        diagnostic = json.loads((p.parent/'DIAGNOSTIC_ONLY.json').read_text())
                        if any(diagnostic['failure_counts'].values()):
                            raise ValueError(f"Unresolved diagnostic points: {diagnostic['failure_counts']}")
                    paths.append(p)
            audit(paths, int(os.environ['ENERGY_POINTS']))
            report.update(status='numerically_complete', products=[dict(path=str(p), size=p.stat().st_size,
                mtime_ns=p.stat().st_mtime_ns) for p in paths])
        except Exception as exc:
            report.update(status='validation_failed', error=str(exc))
    with atomic_text(marker) as stream:
        json.dump(report, stream, indent=2)
    print(json.dumps(report), flush=True)
    sys.exit(0 if report['status'] == 'numerically_complete' else 1)


if __name__ == '__main__':
    main()
