"""Targeted real-solver checks before launching a changed production campaign."""
import json
import os
from pathlib import Path
from time import monotonic
from concurrent.futures import ProcessPoolExecutor, as_completed
from multiprocessing import get_context
import numpy as np
from tqdm import tqdm
from physics.inelastic_dielectric.polarization import nonlinear_polarization as pol
from physics.inelastic_dielectric.projectile_potentials.projectile_form_factors import load_density
from physics.inelastic_dielectric.checkpoints import atomic_text


def check_case(case):
    element, charge, beta, loss = case
    started = monotonic()
    try:
        value, error, report = pol.converged_kernel([loss], beta, 1/np.sqrt(1-beta*beta),
            load_density(element, charge), return_diagnostics=True)
        row = dict(element=element, charge=charge, beta=beta, loss=loss,
                   value=value.tolist(), error=error.tolist(), report=report, passed=True)
    except Exception as exc:
        row = dict(element=element, charge=charge, beta=beta, loss=loss, passed=False, error=str(exc))
    row['seconds'] = monotonic()-started
    return row


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('output', type=Path)
    parser.add_argument('--workers', type=int, default=1)
    args = parser.parse_args()
    os.environ.setdefault('ICE_POLARIZATION_PROGRESS_DIR',
                          str(args.output.with_suffix('.progress')))
    rows = []
    # Logged H+ failure: the beta value was printed at limited precision.
    # Two H0 points are actual first/median nonfinite entries in the old export.
    cases = [('H', 1, .0246025, 7.), ('H', 0, .014594784218305139, 67.82012628321215),
             ('H', 0, .017589887285868945, 233.11862843639042)]
    with ProcessPoolExecutor(max_workers=min(args.workers,len(cases)),mp_context=get_context('spawn')) as pool:
        futures = [pool.submit(check_case,case) for case in cases]
        for future in tqdm(as_completed(futures),total=len(cases),desc='Recovery probe',unit='point'):
            rows.append(future.result())
            rows.sort(key=lambda r: cases.index((r['element'],r['charge'],r['beta'],r['loss'])))
            with atomic_text(args.output) as stream:
                json.dump(rows,stream,indent=2)
    if not all(r['passed'] for r in rows):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
