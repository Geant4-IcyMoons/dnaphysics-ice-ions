"""Launch frozen generation with the full admitted polarization worker count."""
from physics.inelastic_dielectric import generate_cross_sections as gen


def main():
    original = gen.correction.apply_barkas_correction_to_dcs_data
    def correction(data, *args, **kwargs):
        kwargs['workers'] = gen._max_workers_from_environment()
        print('Polarization worker allocation:', kwargs['workers'], flush=True)
        return original(data, *args, **kwargs)
    gen.correction.apply_barkas_correction_to_dcs_data = correction
    gen.main()


if __name__ == '__main__':
    main()
