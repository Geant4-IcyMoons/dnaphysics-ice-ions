"""Output-aware PBS sequencing; no destructive afterok dependencies.

The state file contains prepared submission manifests in `campaigns`.
Hydrogen must pass numerical output checks before helium becomes eligible.
Submission intent is saved before qsub: ambiguous submissions require review.
"""
import argparse
import fcntl
import json
from pathlib import Path
import subprocess
import time
from tqdm import tqdm
from physics.inelastic_dielectric.checkpoints import atomic_text


def save(path, state):
    with atomic_text(path) as stream:
        json.dump(state, stream, indent=2)


def complete(job, source):
    p = Path(job['cache'])/'completion.json'
    if not p.exists():
        return False
    m = json.loads(p.read_text())
    return (m.get('status') == 'numerically_complete' and m.get('source_sha256') == source
            and len(m.get('products', [])) == 4
            and all(Path(f['path']).is_file() and Path(f['path']).stat().st_size == f['size']
                    and Path(f['path']).stat().st_mtime_ns == f['mtime_ns'] for f in m['products']))


def tick(path, state):
    if state.get('probe'):
        probe = Path(state['probe'])
        if not probe.exists():
            print('Waiting for compute-node numerical probe', flush=True)
            return 1
        rows = json.loads(probe.read_text())
        if any(not row.get('passed') for row in rows):
            state['gate'] = 'needs_review'
            save(path, state)
            print('Numerical probe failed; production remains gated for review', flush=True)
            return 1
        if len(rows) != 3 or not all(row.get('passed') for row in rows):
            print('Numerical probe incomplete or failed; production remains gated', flush=True)
            return 1
    cases = []
    for name in state['campaigns']:
        campaign = json.loads(Path(name).read_text())
        cases.extend((campaign, job) for job in campaign['jobs']
                     if job['case'] not in state.get('exclude_cases', []))
    hydrogen_done = all(complete(j, c['source_sha256']) for c,j in cases if c['projectile'] == 'proton')
    unfinished = 0
    for campaign, job in tqdm(cases, desc='Checking campaign outputs', unit='case'):
        record = state.setdefault('jobs', {}).setdefault(job['case'], dict(attempts=[], status='waiting'))
        if complete(job, campaign['source_sha256']):
            record['status'] = 'complete'
            continue
        unfinished += 1
        if campaign['projectile'] == 'alpha' and not hydrogen_done:
            record['status'] = 'waiting_for_hydrogen'
            continue
        if record['status'] in ('submitting', 'needs_review'):
            continue
        if record['attempts']:
            check = subprocess.run(['qstat','-xf',record['attempts'][-1]], text=True, capture_output=True)
            if check.returncode:
                record['status'] = 'needs_review'
                record['reason'] = 'Cannot determine previous job state; refusing duplicate submission'
                continue
            if not any(line.strip() == 'job_state = F' for line in check.stdout.splitlines()):
                record['status'] = 'active'
                continue
            completion = Path(job['cache'])/'completion.json'
            if completion.exists():
                report = json.loads(completion.read_text())
                if report.get('status') == 'validation_failed':
                    record.update(status='needs_review', reason=report.get('error'))
                    continue
        if len(record['attempts']) >= state.get('max_attempts', 3):
            record['status'] = 'needs_review'
            record['reason'] = 'Bounded retry budget exhausted; checkpoints retained'
            continue
        record['status'] = 'submitting'
        save(path, state)
        command = list(job['command'])
        allocated = job.get('allocator', False)
        if allocated:
            command += ['--key', job['allocator_key'] + '-attempt-' + str(len(record['attempts']))]
        result = subprocess.run(command, text=True, capture_output=True)
        if result.returncode:
            record.update(status='needs_review', reason=result.stderr)
        else:
            try:
                job_id = json.loads(result.stdout)['job_id'] if allocated else result.stdout.strip()
            except (ValueError, KeyError):
                record.update(status='needs_review', reason='Uncertain allocator submission receipt')
                save(path, state)
                continue
            record['attempts'].append(job_id)
            record['status'] = 'active'
        save(path, state)
    state['unfinished'] = unfinished
    save(path, state)
    print(json.dumps(state['jobs']), flush=True)
    return unfinished


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('state', type=Path)
    parser.add_argument('--watch', action='store_true')
    args = parser.parse_args()
    with args.state.with_suffix('.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        deadline = time.monotonic()+70*3600
        while True:
            state = json.loads(args.state.read_text())
            remaining = tick(args.state, state)
            if not args.watch or not remaining or state.get('gate') == 'needs_review':
                break
            if time.monotonic() >= deadline:
                if 'PBS_JOBID' not in __import__('os').environ:
                    raise RuntimeError('Controller lifetime reached outside PBS; restart with same state')
                import os
                state['controller_handoff'] = 'submitting'
                save(args.state, state)
                root = Path(__file__).resolve().parents[3]
                command = ['qsub', '-W', 'depend=afterany:'+os.environ['PBS_JOBID'],
                    '-v', f'SEQUENCE_ROOT={root},SEQUENCE_STATE={args.state.resolve()}',
                    '-o', str(args.state.with_suffix('.controller.log')),
                    str(Path(__file__).with_name('sequence.pbs'))]
                if state.get('allocator_controller_script'):
                    command = ['/home/yoffegid/.local/bin/job_allocator', 'submit',
                        '--queue', 'idlex', '--mode', 'serial', '--cpus', '1', '--nodes', '1',
                        '--mem-per-cpu-gb', '1', '--walltime', '72:00:00',
                        '--afterany', os.environ['PBS_JOBID'],
                        '--script', state['allocator_controller_script'],
                        '--key', 'xs-controller-after-'+os.environ['PBS_JOBID']]
                result = subprocess.run(command, text=True, capture_output=True)
                state['controller_handoff'] = result.stdout.strip() if result.returncode == 0 else 'needs_review: '+result.stderr
                save(args.state, state)
                break
            time.sleep(300)


if __name__ == '__main__':
    main()
