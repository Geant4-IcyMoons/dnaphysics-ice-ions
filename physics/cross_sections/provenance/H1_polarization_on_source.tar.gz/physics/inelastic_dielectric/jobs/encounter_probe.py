"""Reproduce an actual H0 failed loss and save encounter-level evidence."""
import json
import os
from pathlib import Path
import numpy as np
from physics.inelastic_dielectric.checkpoints import atomic_text
from physics.inelastic_dielectric.polarization import nonlinear_polarization as pol
from physics.inelastic_dielectric.projectile_potentials.projectile_form_factors import load_density


def main():
    beta = .014594784218305139
    output = Path(os.environ['ICE_ENCOUNTER_FAILURE_DIR'])
    output.mkdir(parents=True, exist_ok=True)
    try:
        value, error, diagnostics = pol.converged_kernel([67.82012628321215], beta,
            1/np.sqrt(1-beta*beta), load_density('H',0), return_diagnostics=True)
        result = dict(passed=True, value=value.tolist(), error=error.tolist(), diagnostics=diagnostics)
    except Exception as exc:
        result = dict(passed=False, error=str(exc))
    with atomic_text(output/'result.json') as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
