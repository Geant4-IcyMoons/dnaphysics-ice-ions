# Numerically gated recovery

The nonlinear backend keeps its 0.1% relative acceptance target and existing
absolute floor. Up to eight refinement passes preferentially double the
encounter window, tighten the ODE tolerance, or increase impact quadrature
resolution according to the dominant error estimator. This is a bounded
numerical policy, not a change to the force model or proof of physical accuracy.
The impact upper cutoff remains 50; its convergence is not established here.

Strict generation records unresolved losses in row-specific failures JSON,
continues independent losses and energy rows, and refuses final export if
anything remains unresolved. Successful losses are checkpointed; resuming the
same source retries only unfinished strict losses. Diagnostic resumes also
retry numerical flags, while keeping accepted points. No clipping, fallback
to cubic response, or increased tolerance is used. Numerical-version changes
reject older checkpoints; old research products remain preserved.

Optional plot errors produce a separate status JSON and do not determine
generation success. The PBS wrapper independently checks four DAT products,
finite nonnegative values, ordered grids and DCS/TCS integrals, then atomically
writes cache/completion.json. Diagnostic failure flags prevent numerical
completion; absence of such flags does not establish experimental validation.

Prepare campaigns with submit_campaign --defer. A sequence state JSON lists
their submission.json paths under campaigns, optional exclude_cases, an
optional recovery-probe JSON, and max_attempts (default 3). Sequence checks
completion fingerprints, runs hydrogen first and submits helium only after
all selected hydrogen cases pass. It never uses afterok, deletes dependent
jobs, or modifies completed products. Controller submission intents and returned
job IDs are atomic. Ambiguous submissions or unavailable PBS history require
review rather than risking duplicate jobs. Validation failures require review;
generation/time-limit failures have a bounded retry budget. Existing diagnostic
flags are not silently treated as success. The controller is restartable with
the same state and lock and runs at most 70 hours per invocation; it submits
its successor with afterany on itself before exiting. That dependency does
not attach science jobs to each other. A handoff submission failure is
recorded for review. An abrupt controller-node failure still requires a
manual controller restart with the same state file.

Tests: tests/test_polarization_recovery.py and tests/test_output_sequence.py.
The separate compute-node recovery_probe tests the printed H+ failing beta
(rounded in the original error) and two actual flagged H0 points. It is a
targeted implementation check, not a production-grid convergence survey.

The probe enables ICE_POLARIZATION_PROGRESS_DIR next to its result JSON.
Each worker atomically replaces one status JSON, throttled to ten seconds
between encounter boundaries and written at every refinement boundary.
It records completed impact evaluations, current sampled distance, solver
stage, fallback count and completed refinement error estimates. Adaptive
quadrature has no known final evaluation count, so these are not percentages.
A long individual encounter can leave the status unchanged; the timestamp
is not a heartbeat. Existing running Python processes do not acquire this
instrumentation without restarting. Live py-spy stack/locals inspection can
instead diagnose those processes without discarding their ongoing work.

Version lc-v4 also checks agreement of direct encounters at matched windows
and different ODE tolerances. If that check exceeds the existing solver
absolute/relative scale, or any encounter uses fallback, all three estimates
use the regularized solver. The integral still has to satisfy its original
error criterion. Job 243159 reproduced a successful but inaccurate direct
encounter (12.18958 versus the regularized 12.58951) at the 233.1186 eV
witness. Four regularized tolerances agreed; this does not by itself validate
the impact integral, neighbouring points, or the physical approximation.
