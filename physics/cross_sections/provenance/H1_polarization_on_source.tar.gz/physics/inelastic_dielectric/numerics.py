"""Shared quadrature and stable incident-energy grouping."""
import numpy as np


def energy_groups(energies, mask=None):
    """Yield sorted finite energies and stable indices without repeated full scans."""
    energies = np.asarray(energies, dtype=float)
    if energies.ndim != 1:
        raise ValueError("Energy grouping requires a one-dimensional array")
    selected = np.isfinite(energies)
    if mask is not None:
        selected &= np.asarray(mask, dtype=bool)
    indices = np.flatnonzero(selected)
    indices = indices[np.argsort(energies[indices], kind="stable")]
    if not indices.size:
        return
    boundaries = np.r_[0, np.flatnonzero(np.diff(energies[indices]))+1, indices.size]
    for start, stop in zip(boundaries[:-1], boundaries[1:]):
        idx = indices[start:stop]
        yield float(energies[idx[0]]), idx

def _simpson_integrate(y, x):
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    n = y.size
    if n < 2:
        return 0.0
    if n != x.size:
        raise ValueError("x and y must have the same length")
    if n == 2:
        return 0.5 * (y[0] + y[1]) * (x[1] - x[0])

    dx = np.diff(x)
    if not np.allclose(dx, dx[0]):
        return float(np.sum(0.5 * dx * (y[:-1] + y[1:])))

    h = dx[0]
    if n % 2 == 1:
        return float(
            (h / 3.0)
            * (y[0] + y[-1] + 4.0 * np.sum(y[1:-1:2]) + 2.0 * np.sum(y[2:-1:2]))
        )

    n1 = n - 1
    simpson_part = (h / 3.0) * (
        y[0]
        + y[n1 - 1]
        + 4.0 * np.sum(y[1 : n1 - 1 : 2])
        + 2.0 * np.sum(y[2 : n1 - 2 : 2])
    )
    trap_part = 0.5 * (y[-2] + y[-1]) * (x[-1] - x[-2])
    return float(simpson_part + trap_part)
