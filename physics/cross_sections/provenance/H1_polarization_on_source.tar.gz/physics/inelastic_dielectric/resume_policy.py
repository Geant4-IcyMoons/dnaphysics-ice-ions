"""Explicit read-only inheritance for a tolerance-only production continuation.

The preparation record pins both sources. Only source identity, output paths,
and polarization tolerance metadata may differ; all physics/grid keys must match.
"""
from functools import lru_cache
import json
import os
from pathlib import Path
import numpy as np
from physics.inelastic_dielectric import born_archive


@lru_cache(maxsize=1)
def policy():
    name = os.environ.get("DIELECTRIC_RESUME_POLICY")
    if not name:
        return None
    data = json.loads(Path(name).read_text())
    _validate(data)
    return data


def _validate(data):
    if (data['old_rtol'], data['new_rtol']) not in ((.001, .01), (.01, .05)):
        raise ValueError('Supported continuations are 0.001 -> 0.01 and 0.01 -> 0.05')
    if Path(data["old_cache"]).resolve() == Path(data["new_cache"]).resolve():
        raise ValueError("Inherited cache must remain read-only and separate")
    parent = data.get('parent_policy')
    if data['old_rtol'] == .01 and parent is None:
        raise ValueError('The 5% continuation must pin its 1% parent policy')
    if parent is not None:
        _validate(parent)
        for old, new in (('old_cache','new_cache'), ('old_tables','new_tables'),
                         ('old_source','new_source'), ('old_rtol','new_rtol')):
            if data[old] != parent[new]:
                raise ValueError('Discontinuous resume policy chain: '+old)


def tolerance(default):
    data = policy()
    return data["new_rtol"] if data else default


def metadata():
    return _metadata(policy())


def _metadata(data):
    return {} if data is None else dict(polarization_resume=dict(
        new_point_rtol=data["new_rtol"], inherited_point_rtol=data["old_rtol"],
        inherited_source=data["old_source"], per_point_field="rtol_used",
        accuracy_comparison_validated=False))


def parent_path(path):
    data = policy()
    if data is None:
        return None
    return Path(data["old_cache"]) / Path(path).resolve().relative_to(Path(data["new_cache"]).resolve())


def old_signature(signature, data=None):
    data = policy() if data is None else data
    def translate(value):
        if isinstance(value, dict):
            result = {key: (data["old_rtol"] if key == "barkas_quadrature_rtol" else translate(item))
                      for key, item in value.items() if key != "polarization_resume"}
            if 'polarization_resume' in value:
                result.update(_metadata(data.get('parent_policy')))
            return result
        if isinstance(value, list):
            return [translate(item) for item in value]
        if isinstance(value, str):
            if value == data["new_source"]:
                return data["old_source"]
            for new, old in (("new_cache", "old_cache"), ("new_tables", "old_tables")):
                if value == data[new]:
                    return data[old]
        return value
    return translate(json.loads(signature))


def read(path, signature):
    """Return validated arrays and inherited flag; never overwrite parent data."""
    return _read(path, signature, policy())


def _read(path, signature, data):
    path = Path(path)
    try:
        saved = born_archive.open_npz(path)
    except FileNotFoundError:
        if data is None:
            raise
        parent = Path(data['old_cache']) / path.resolve().relative_to(Path(data['new_cache']).resolve())
        parent_signature = json.dumps(old_signature(signature, data), sort_keys=True)
        result, _ = _read(parent, parent_signature, data.get('parent_policy'))
        result['signature'] = np.asarray(signature)
        return result, True
    with saved:
        if json.loads(str(saved['signature'])) != json.loads(signature):
            raise ValueError(f"Incompatible checkpoint provenance: {path}")
        result = {key: saved[key].copy() for key in saved.files}
    return result, False
