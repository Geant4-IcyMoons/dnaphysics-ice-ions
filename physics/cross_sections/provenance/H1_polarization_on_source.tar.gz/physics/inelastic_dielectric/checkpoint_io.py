"""Bounded, ordered checkpoint read-ahead; no validation is bypassed."""
from collections import deque
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from itertools import islice

CHECKPOINT_READERS = 8
MAX_CHECKPOINT_READERS = 32


def checkpoint_order(path):
    """Match the generator's energy-major, then channel-major read order."""
    parts = path.stem.split("_")
    if len(parts) == 4 and parts[0] in ("excitation", "ionization", "kshell"):
        channel, index, start, stop = parts
        return (1, int(start), ("excitation", "ionization", "kshell").index(channel),
                int(index), int(stop))
    return (0, path.name)


def ordered_prefetch(function, items, workers=CHECKPOINT_READERS):
    """Overlap file latency, retaining at most two results per reader."""
    workers = max(1, min(int(workers), CHECKPOINT_READERS))
    items = iter(items)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        pending = deque(pool.submit(function, item) for item in islice(items, 2*workers))
        while pending:
            yield pending.popleft().result()
            for item in islice(items, 1):
                pending.append(pool.submit(function, item))


def completed_prefetch(function, items, workers=CHECKPOINT_READERS):
    """Bounded completion-order I/O for results carrying their own member keys.

    Do not use for numerical reductions that require input ordering. A slow
    file does not prevent other reader slots from accepting further files.
    """
    workers = max(1, min(int(workers), MAX_CHECKPOINT_READERS))
    items = iter(items)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        pending = {pool.submit(function, item) for item in islice(items, 2*workers)}
        try:
            while pending:
                ready, pending = wait(pending, return_when=FIRST_COMPLETED)
                for future in ready:
                    yield future.result()
                    for item in islice(items, 1):
                        pending.add(pool.submit(function, item))
        finally:
            for future in pending:
                future.cancel()


def main():
    """Warm immutable Born checkpoints for a running, older snapshot.

    Read-only assistance: the generator still opens and validates every file.
    Do not traverse polarization checkpoints, which workers actively update.
    """
    import argparse
    import os
    from pathlib import Path
    from tqdm import tqdm

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path, help="Directory containing energy_*.npz and dcs/")
    parser.add_argument("--workers", type=int, default=CHECKPOINT_READERS)
    parser.add_argument("--campaign-cache", action="store_true",
                        help="Resolve run directories under CACHE_DIR/checkpoints")
    args = parser.parse_args()

    def read(path):
        # Stream without retaining file contents or issuing an exists/stat first.
        try:
            with path.open("rb") as stream:
                while stream.read(256*1024):
                    pass
        except FileNotFoundError:
            return False
        return True

    roots = ([p for p in (args.directory/"checkpoints").iterdir() if p.is_dir()]
             if args.campaign_cache else [args.directory])
    directories = [(directory, prefix) for root in roots
                   for directory, prefix in ((root, "energy_"), (root/"dcs", ""))]
    for directory, prefix in directories:
        try:
            with os.scandir(directory) as entries:
                paths = sorted((Path(entry.path) for entry in entries
                               if entry.name.startswith(prefix) and entry.name.endswith(".npz")
                               and entry.name != "manifest.npz"), key=checkpoint_order)
        except FileNotFoundError:
            continue
        count = sum(tqdm(ordered_prefetch(read, paths, args.workers), total=len(paths),
                         desc=f"Checkpoint read-ahead {directory.name}", unit="file", mininterval=10))
        print(f"Read-ahead: {count}/{len(paths)} files; validation remains with generator", flush=True)


if __name__ == "__main__":
    main()
