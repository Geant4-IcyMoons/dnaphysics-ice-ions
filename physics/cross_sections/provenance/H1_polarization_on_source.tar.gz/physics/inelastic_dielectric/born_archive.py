"""Indexed, byte-preserving storage of immutable completed Born checkpoints.

Only energy_*.npz and direct dcs task files are packed. Numerical validation
remains in checkpoints.py; polarization rows and their writes are untouched.
"""
import atexit
from contextlib import closing
import fcntl
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import sqlite3
import threading
import time

if __package__:
    from .checkpoint_io import completed_prefetch, checkpoint_order, CHECKPOINT_READERS
else:
    from checkpoint_io import completed_prefetch, checkpoint_order, CHECKPOINT_READERS

ARCHIVE = "born_checkpoints.sqlite"
_READERS = {}
_MEMBERS = {}
_MISSING_AT = {}
_LOCK = threading.RLock()
_ENERGY = re.compile(r"energy_\d+\.npz\Z")
_TASK = re.compile(r"(?:excitation|ionization|kshell)_\d+_\d+_\d+\.npz\Z")


def location(path):
    path = Path(path)
    if _ENERGY.fullmatch(path.name):
        return path.parent, path.name
    if path.parent.name == "dcs" and _TASK.fullmatch(path.name):
        return path.parent.parent, "dcs/"+path.name
    return None


def close_readers():
    with _LOCK:
        for connection in _READERS.values():
            if connection is not None:
                connection.close()
        _READERS.clear()
        _MEMBERS.clear()
        _MISSING_AT.clear()


atexit.register(close_readers)


def read_packed(path):
    """Return original NPZ bytes, or None when not packed. Never hide corruption."""
    target = location(path)
    if target is None:
        return None
    root, member = target
    archive = root/ARCHIVE
    with _LOCK:
        # A companion packer may publish while a resumed scan is in progress.
        if archive in _MISSING_AT and time.monotonic()-_MISSING_AT[archive] >= 1.:
            _READERS.pop(archive, None)
            _MISSING_AT.pop(archive)
        if archive not in _READERS:
            try:
                archive.stat()
            except FileNotFoundError:
                _READERS[archive] = None
                _MISSING_AT[archive] = time.monotonic()
            else:
                connection = sqlite3.connect(archive.resolve().as_uri()+"?mode=ro", uri=True,
                                             check_same_thread=False)
                try:
                    state = dict(connection.execute("SELECT key,value FROM metadata"))
                    if state.get("complete") != "1" or state.get("format") != "1":
                        raise ValueError(f"Incomplete or unsupported Born archive: {archive}")
                    names = set(json.loads(state["identity"])["names"])
                    actual = {name for name, in connection.execute("SELECT name FROM members")}
                    if actual != names:
                        raise ValueError(f"Corrupt Born archive member index: {archive}")
                    _MEMBERS[archive] = names
                except BaseException:
                    connection.close()
                    raise
                _READERS[archive] = connection
        connection = _READERS[archive]
        if connection is None:
            return None
        row = connection.execute("SELECT payload,sha256 FROM members WHERE name=?", (member,)).fetchone()
        expected_member = member in _MEMBERS[archive]
    if row is None:
        if expected_member:
            raise ValueError(f"Missing packed Born checkpoint: {path}")
        return None
    payload, expected = row
    if hashlib.sha256(payload).hexdigest() != expected:
        raise ValueError(f"Corrupt packed Born checkpoint: {path}")
    return payload


def open_npz(path):
    """Give numpy the exact original byte stream, without per-member file opens."""
    import numpy as np
    payload = read_packed(path)
    return np.load(io.BytesIO(payload) if payload is not None else path, allow_pickle=False)


def assert_writable(path):
    if read_packed(path) is not None:
        raise ValueError("Packed Born checkpoints are immutable; use a new case directory")


def _members(root):
    result = []
    for directory, pattern in ((root, _ENERGY), (root/"dcs", _TASK)):
        with os.scandir(directory) as entries:
            result.extend(Path(entry.path) for entry in entries if pattern.fullmatch(entry.name))
    return sorted(result, key=lambda p: (p.parent != root, checkpoint_order(p)))


def pack(root, *, energy_count=None, task_count=None, workers=CHECKPOINT_READERS):
    """Restart-safe conversion. Originals are never modified or removed.

    Completed Born files must remain immutable during conversion, as in the
    generation workflow. A failed conversion is resumed from committed batches.
    Publication follows a full stored-byte SHA-256 and SQLite integrity check.
    """
    from tqdm import tqdm
    root = Path(root).resolve()
    archive = root/ARCHIVE
    with (root/".born_archive.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if archive.exists():
            return archive
        manifest_hash = hashlib.sha256((root/"manifest.npz").read_bytes()).hexdigest()
        paths = _members(root)
        names = [str(p.relative_to(root)) for p in paths]
        n_energy = sum(p.parent == root for p in paths)
        n_task = len(paths)-n_energy
        if ((energy_count is not None and n_energy != energy_count)
                or (task_count is not None and n_task != task_count)):
            raise ValueError(f"Incomplete Born set: {n_energy} energies, {n_task} tasks")
        if not n_task:
            raise ValueError("No completed Born DCS tasks to pack")
        identity = json.dumps(dict(manifest_sha256=manifest_hash, names=names), sort_keys=True)
        building = root/(ARCHIVE+".building")
        with closing(sqlite3.connect(building)) as db:
            db.execute("PRAGMA synchronous=FULL")
            db.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY,value TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS members (name TEXT PRIMARY KEY,payload BLOB NOT NULL,sha256 TEXT NOT NULL)")
            previous = db.execute("SELECT value FROM metadata WHERE key='identity'").fetchone()
            if previous is not None and previous[0] != identity:
                raise ValueError("Incompatible unfinished Born archive; originals retained")
            db.execute("INSERT OR IGNORE INTO metadata VALUES ('identity',?)", (identity,))
            db.execute("INSERT OR REPLACE INTO metadata VALUES ('format','1')")
            db.commit()
            done = {name for name, in db.execute("SELECT name FROM members")}
            pending = [p for p in paths if str(p.relative_to(root)) not in done]

            def read(path):
                with path.open("rb") as stream:
                    before = os.fstat(stream.fileno())
                    payload = stream.read()
                    after = os.fstat(stream.fileno())
                if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                    raise RuntimeError(f"Checkpoint changed while packing: {path}")
                return str(path.relative_to(root)), payload, hashlib.sha256(payload).hexdigest()

            for i, row in enumerate(tqdm(completed_prefetch(read, pending, workers),
                    total=len(paths), initial=len(done), desc="Packing Born checkpoints", unit="file", mininterval=10), 1):
                db.execute("INSERT INTO members VALUES (?,?,?)", row)
                if i % 16 == 0:
                    db.commit()
            db.commit()
            if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("Born archive failed SQLite integrity check")
            for name, payload, digest in tqdm(db.execute("SELECT name,payload,sha256 FROM members"),
                    total=len(paths), desc="Verifying packed bytes", unit="file", mininterval=10):
                if hashlib.sha256(payload).hexdigest() != digest:
                    raise ValueError(f"Born archive failed byte verification: {name}")
            if db.execute("SELECT count(*) FROM members").fetchone()[0] != len(paths):
                raise ValueError("Born archive member count mismatch")
            db.execute("INSERT OR REPLACE INTO metadata VALUES ('complete','1')")
            db.commit()
        os.replace(building, archive)
        close_readers()
        print(f"Verified Born archive: {archive}; {len(paths)} original files retained", flush=True)
    return archive


def install_legacy(generator):
    """Use this I/O adapter with frozen physics; retain its source-digest function."""
    source = Path(__file__).with_name("checkpoints.py")
    spec = importlib.util.spec_from_file_location("_born_checkpoint_io_adapter", source)
    adapter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(adapter)
    for name in ("load_energy", "load_task", "save_energy", "save_task"):
        setattr(generator.checkpoints, name, getattr(adapter, name))

    def prepare(data, directory):
        if directory is not None:
            import numpy as np
            root = Path(directory).parent.parent
            if (root/"manifest.npz").is_file():
                tasks = len(np.unique(data["T_line"]))*\
                    (data["exc_vals"].shape[1]+data["ion_vals"].shape[1])
                pack(root, task_count=tasks)

    original = generator.correction.apply_barkas_correction_to_dcs_data
    def correction(data, *args, **kwargs):
        prepare(data, kwargs.get("checkpoint_dir"))
        kwargs["workers"] = generator._max_workers_from_environment()
        print("Polarization worker allocation:", kwargs["workers"], flush=True)
        return original(data, *args, **kwargs)
    generator.correction.apply_barkas_correction_to_dcs_data = correction

    from physics.inelastic_dielectric.polarization import diagnostic_tables
    original_diagnostic = diagnostic_tables.write_diagnostic_tables
    def diagnostic(data, s, density, mass, out_dir, checkpoint_dir, *args, **kwargs):
        prepare(data, checkpoint_dir)
        return original_diagnostic(data, s, density, mass, out_dir, checkpoint_dir, *args, **kwargs)
    diagnostic_tables.write_diagnostic_tables = diagnostic
    print("Born archive I/O adapter:", hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "checkpoint adapter:", hashlib.sha256(source.read_bytes()).hexdigest(), flush=True)


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--energy-count", type=int)
    parser.add_argument("--task-count", type=int, required=True)
    parser.add_argument("--workers", type=int, default=CHECKPOINT_READERS)
    args = parser.parse_args()
    pack(args.directory, energy_count=args.energy_count, task_count=args.task_count,
         workers=args.workers)


if __name__ == "__main__":
    main()
