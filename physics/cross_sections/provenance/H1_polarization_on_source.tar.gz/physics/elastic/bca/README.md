# Phase-resolved elastic-collision infrastructure

This package connects equilibrated NEP-MB-pol ice snapshots to retained-domain
NLH hard-collision trajectories. It provides:

1. strict ingestion and provenance checking for periodic extended-XYZ ice
   snapshots; and
2. independent-atom NLH collision kernels for projectiles H, He, C, O, and S
   against the H and O nuclei in ice;
3. a checksum-validated adaptive-kernel runtime reader; and
4. periodic structure-aware sequencing of primary H, He, C, O, and S hard
   collisions,
   including exact projectile deflection and emitted-recoil kinematics.

The trajectory stage produces phase- and orientation-resolved **hard-event
samples**, not a complete elastic cross section. Soft distant scattering,
simultaneous many-atom forces, recoil-cascade reinsertion, lattice relaxation,
electronic stopping, and charge exchange remain separate physics. Every run
manifest states these exclusions and reports collisions for which another hard
candidate overlaps the binary encounter.

## Physical definition of one kernel

For a projectile with total kinetic energy `T`, `scattering.py` obtains the
relativistically exact center-of-mass kinetic energy for a stationary target.
For each impact parameter it solves the distance of closest approach in the
published NLH pair potential and evaluates the classical central-potential
deflection integral with Gauss-Legendre quadrature. The center-of-mass angle is
then transformed using exact two-body kinematics to give the projectile lab
angle and target recoil energy.

The default hard-collision boundary is the impact parameter whose turning
potential is 30 eV, the range in which NLH reports its strongest general
agreement. The published 10 eV lower domain can be selected explicitly. This
quantity is a **pair-potential validity boundary**, not a 10 or 30 eV recoil
cut and not an energy-deposition threshold. Weak, distant scattering below
the boundary is intentionally absent until a validated long-range
projectile--ice interaction is supplied.

The default energy range is 1 keV--100 MeV in **total projectile kinetic
energy**. The 1 keV floor keeps even the least favorable supported pair,
S--H, just inside the 30 eV center-of-mass domain. Point counts are not fixed.
The generator starts from 121 logarithmic energies and adaptively inserts
pair-specific energies after direct quarter/midpoint/three-quarter checks. At
every energy it independently refines the collision-area coordinate
`q=(b/b_max)^2` wherever linear interpolation of the center-of-mass angle,
followed by exact two-body kinematics, fails recoil, transport, or angular
tests. The runtime reader must use this same interpolation contract; it must
not interpolate angle and recoil as unrelated quantities.

The per-axis tolerance is 0.25%, giving a nominal two-axis budget of 0.5%.
Every output manifest records the actual point counts and maximum estimated
errors. The hard-collision cross section is evaluated from the exact
threshold formula and must not be interpolated through its onset. This avoids
the S--H threshold error found in the original fixed-grid diagnostic.

## 1. Attest equilibrated structures

Run the commands below from the parent `nep_mbpol` directory.

Do not attest the committed initial ice-Ih cell. After the cluster trajectory
passes the phase-specific RDF, structure-factor/order, density, and
thermodynamic-stationarity checks described in the parent README, preserve the
reports and run:

```bash
python3 attest_collision_structure.py final_hexagonal_trajectory.xyz \
  --phase "hexagonal ice Ih, 80 K" \
  --validation-report hexagonal_validation.json \
  --confirm-accepted
```

Repeat for every accepted independent trajectory. The sidecar records the
exact SHA-256 of both the trajectory and validation evidence. Register the
accepted inputs with:

```bash
python3 register_collision_structures.py \
  final_hexagonal_seed1000.xyz \
  final_hexagonal_seed2000.xyz \
  final_hexagonal_seed3000.xyz \
  --output collision_structures_hexagonal.json
```

The reader selects the last frame by default. Use `--frame N` to register a
specific frame. `--allow-unvalidated` exists only for checking the plumbing;
it marks every such entry `diagnostic-only`.

The accepted 100 K ice-Ih replicas are already attested under
`../../ice_structures/hexagonal_ih_100K_experimental/`. Their portable
`collision_structures.json` registry points to the three gzip-compressed final
snapshots, and the checksummed evidence is under its `validation/` directory.
The XYZ reader supports both plain and `.gz` inputs.

## 2. Generate reusable pair kernels

The production default uses ten worker processes and restartable per-energy
checkpoints:

```bash
python3 generate_nlh_collision_kernels.py
```

On PBS, the repository launcher requests one 16-CPU, 4-GB allocation, pins threaded
numerical libraries to one thread per worker, generates all five supported
projectile families, and then runs the independent dense-reference benchmark:

```bash
qsub pbs/generate_nlh_collision_kernels.pbs
```

Submit from the repository root. A repeated submission resumes the same
configuration-hashed checkpoints and does not recompute completed kernels.
The allocation follows completed PBS jobs 106763 and 106765: they used about
13 cores on average and less than 0.4 GB peak resident memory. Re-evaluate it
with `ion_ice_model.py calibrate-resources --stage
nlh_kernel_and_benchmark` after material algorithm or workload changes.

The output directory contains:

- `nlh_collision_kernels.csv`: H/O collision geometry, angles, and recoil
  kernels on pair- and energy-specific adaptive meshes. The CSV intentionally
  stores only projectile, target, energy, area quantile, and CM angle. Impact
  parameter, lab angle, recoil, and outgoing energy are exact derived
  quantities and are not duplicated;
- `nlh_collision_kernels.manifest.json`: numerical configuration, physical
  scope, and excluded physics; and
- `.checkpoints/<configuration hash>/`: restart blocks.

The accepted generated product committed in `../collision_kernels/` is paired
with the independent evidence in
`../../process_evidence/hard_nuclear_collisions/benchmarking/reference_results/`;
its local README records the exact checksum, generation commits, and PBS jobs.

For a quick infrastructure check:

```bash
python3 generate_nlh_collision_kernels.py \
  --projectiles C \
  --energy-min-ev 10000 \
  --energy-max-ev 100000 \
  --base-energy-points 3 \
  --axis-relative-tolerance 0.05 \
  --max-energy-points 32 \
  --max-impact-points 256 \
  --quadrature-order 32 \
  --workers 2 \
  --output-directory collision_kernels_test
```

Do not install the CSV directly in Geant4. It is the differential collision
kernel consumed by the structure-aware trajectory generator, not a final total
elastic cross-section table.

## 3. Run hard trajectories through an accepted ice cell

The runtime requires the exact attested snapshot and its validation evidence.
For a c-axis calculation through ice Ih:

```bash
python3 simulate_nlh_hard_collisions.py final_hexagonal_seed1000.xyz \
  --projectile C \
  --energy-ev 100000 \
  --direction 0 0 1 \
  --path-length-angstrom 100
```

Repeat with `--projectile H`, `He`, `O`, and `S`. `H` and `He` are the
proton/helium-projectile entries; the dominant-isotope masses are used, and the
short-range nuclear potential is charge-state independent. Use
`--isotropic-directions` only for an explicitly orientation-averaged target;
it must not be described as an oriented single-crystal result. The default is
ten worker processes. Trajectory seeds depend only on the master seed and
trajectory index, so outputs are independent of worker count and completion
order.

If `--trajectories` is omitted, production sampling is adaptive. Independent
histories are added in restartable batches of 1,000 and assessed after
1,000, 2,000, 4,000, ... histories, up to 1,024,000 by default. Sampling stops
only when the full 95% simultaneous confidence-interval width is below the
predeclared absolute width for each of the hard-event rate, hard nuclear
stopping, hard transport rate, mean recoil energy per collision, and mean
`1-cos(theta_lab)` per collision. Each case freezes those widths from its
independent raw 10,000-history calibration estimate using the numerical
tolerance in JCGM 101:2008 section 7.9.2. Two digits are the predeclared project
reporting requirement; JCGM defines the decimal tolerance but does not prescribe
that precision. The production sample is not reused to set its own stopping
boundary. The trajectory is the independent statistical unit. One Bonferroni
budget covers the five scalar observables, two trajectory CDFs, every scheduled
look, and every declared case in the campaign. Scalar ratio intervals use the
trajectory-clustered Student-t delta method, so their nominal 95% family-wise
coverage is asymptotic rather than an exact finite-sample guarantee. This is the
absolute fixed-width framework of Glynn and Whitt (1992; DOI
`10.1214/aoap/1177005770`). Flegal and Gong (2015; DOI `10.5705/ss.2013.209`)
provide the related relative-width framework; neither source sets the retained
numerical precision. The Dvoretzky--Kiefer--Wolfowitz--Massart CDF bands are
finite-sample distribution-free bounds.

Every completed batch is checksum-protected below
`.trajectory_checkpoints/<configuration hash>/`; rerunning the same command
resumes without repeating finished trajectories. Reaching the maximum without
passing all gates writes the diagnostic outputs and exits nonzero. Use an
explicit fixed count only for plumbing or an externally controlled study:

```bash
python3 simulate_nlh_hard_collisions.py final_hexagonal_seed1000.xyz \
  --projectile C \
  --energy-ev 100000 \
  --isotropic-directions \
  --trajectories 1000
```

Uniform sampling is retained as `--sampling-mode uniform` for direct checks,
but it is not the production default. In the carbon 100-MeV validation
campaign, 7.3--28.8 million uniform histories per case left the recoil/stopping
and transport relative half-widths at approximately 24--64%; direct
extrapolation to 0.5% requires order 10^11 histories per case. The production
sampler instead uses the adaptive impact-area intervals already present in
each physical kernel as collision-tube strata. Half of the default draws
remain uniform cell translations and half select a target atom, longitudinal
encounter point, adaptive `q` interval, and azimuth. Every history carries the
exact periodic target/proposal likelihood ratio, including the sum over
overlapping tube preimages. The uniform mixture component bounds weights by
two. This is the stratified rare-event approach advocated for ion--solid Monte
Carlo by Jakas (1997; DOI `10.1080/10420159708211554`), specialized here
without a fitted bias or a change to the NLH hard boundary. Tests recover the
analytic periodic hard rate and verify likelihood support and bounds. The
direct uniform component alone is retained for ordinary unweighted trajectory
CDFs.

The earlier campaign also found overlapping retained NLH interaction intervals for
approximately 10.1--10.5% of hard events. This conservative ambiguity metric
does not itself prove a bias, because the sequential solver still processes
the competing events, but it requires a multi-centre-force comparison before
the binary ordering can be accepted.

The 0.5% threshold applies to adaptive collision-kernel interpolation and the
separately reported trajectory-CDF band, not to scalar Monte Carlo means. The
absolute-width gates certify normalization and first energy/angular moments;
they do not certify rare tails. Tail-sensitive or binned downstream products
require their own predeclared confidence-band test.

The output directory contains:

- `hard_collision_trajectories.csv`: initial/final projectile state and total
  recoil energy for each history;
- `hard_collision_events.csv`: target atom and periodic image, impact
  parameter, incoming/outgoing directions, recoil direction and energy for
  every retained hard event; and
- `hard_collision_run.manifest.json`: exact structure/kernel provenance,
  configuration, sampled hard rate, uncorrelated independent-atom reference,
  ambiguity count, statistical intervals, and excluded physics.

`--allow-unvalidated` is restricted to plumbing tests with the committed
initial Ih cell. Its manifest remains `diagnostic-only`; such a run is not a
phase-resolved scientific result.

### PBS pilot and hexagonal base matrix

Submit the default resource-calibration pilot from the repository root:

```bash
qsub pbs/run_nlh_hard_collision_trajectories.pbs
```

It runs 10,000 fixed S trajectories at 100 MeV along the ice-Ih c-axis through
the accepted seed-1000 structure. This deliberately exercises the largest
retained collision radii and a full 100-angstrom path. It is a performance and
plumbing measurement, not a converged scientific product.

Chemfarm calibration jobs 106873 and 106875 measured 1.27 GB for 32 workers
and 2.42 GB for 64 workers, respectively. The 64-worker case completed 10,000
trajectories in 19 s at 591 trajectories/s, so the launcher defaults to 64
CPUs and 4 GB. Job 106876 measured 4.65 GB and 881 trajectories/s with 128
workers: twice the allocation delivered only 1.49 times the throughput. The
64-worker layout is therefore the better production-throughput default. Do
not multiply host memory by an arbitrary amount per core; repeat the pilot
after material changes to the structures, kernels, or worker memory layout.

After sizing the CPU, memory, and wall-time request from that job, the initial
hexagonal production matrix is:

```bash
qsub -v RUN_MODE=base_grid -J 0-269 \
    pbs/run_nlh_hard_collision_trajectories.pbs
```

The 270 elements are the Cartesian product of three attested structures, five
projectiles, three orientations (c-axis, basal a-axis, and isotropic), and six
base energies (1, 10, and 100 keV; 1, 10, and 100 MeV). Each element uses
adaptive trajectory sampling, deterministic seeds, and configuration-hashed
checkpoints. The base energies are the first structure-resolved sampling grid,
not an assertion that six energies resolve the final energy dependence.
Independent intermediate-energy runs must be added until the final reduced
observables meet their documented energy-interpolation criterion.

## 4. Reproduce the independent dense-reference benchmark

The internal adaptive estimator is checked against direct solutions on a
separate grid extending down to `q=10^-24`:

```bash
python3 ../process_evidence/hard_nuclear_collisions/benchmarking/benchmark_nlh_adaptive_kernels.py
```

The command tests H, He, C, O, and S against H and O at six energies spanning
1 keV--100 MeV, uses ten workers, and fails with a nonzero status if any
recoil, transport, angular, or quadrature metric exceeds 0.5%. The production
96-point scattering quadrature is compared independently with 192 points. The
command writes the complete case tables and summary under
`../process_evidence/hard_nuclear_collisions/benchmarking/reference_results/`.

## Tests

```bash
python3 -m pytest -q \
  ../../../tests/test_nlh_potential.py \
  ../../../tests/test_nlh_bca_scattering.py \
  ../../../tests/test_nlh_bca_structure.py \
  ../../../tests/test_nlh_bca_adaptivity.py \
  ../../../tests/test_nlh_bca_convergence.py \
  ../../../tests/test_nlh_bca_tables.py \
  ../../../tests/test_nlh_bca_runtime.py
```

The tests cover the published NLH evaluator, turning-potential boundary,
monotonic deflection/recoil behavior, energy conservation, quadrature
convergence, adaptive discovery of the narrow high-energy head-on region,
threshold energy refinement, structure attestation, deterministic
multiprocessing, resume, checksum-validated runtime interpolation, exact
periodic images, search-window invariance, and structure-to-kernel collision
sequencing. The trajectory sampler additionally tests its simultaneous
confidence correction, clustered ratio uncertainty, adaptive schedule, and
restart statistics.

The underlying NLH references and corrected dataset are documented in
`../nlh/README.md`.

## 5. Adaptive per-projectile atomistic transport

`adaptive_nlh_particle_transport.py` is the common controller for H, He, C,
O, and S. It is not particle-specific code. For each requested projectile it:

1. uses an independent 10,000-trajectory calibration sample to choose between
   the raw estimator and a straight-line difference-estimator control variate,
   and freezes the JCGM absolute widths from the raw estimates;
2. runs a distinct production sample with a predeclared sequential schedule;
3. increases trajectory count until every integral rate/first moment has a 95%
   simultaneous confidence-interval width below its frozen absolute width;
4. requires a simultaneous Dvoretzky--Kiefer--Wolfowitz absolute band at most
   0.005 for the complete trajectory-level total-recoil and final-deflection
   CDFs; and
5. recursively evaluates geometric energy midpoints, inserting points wherever
   the confidence-enveloped scalar or CDF discrepancy from endpoint
   interpolation exceeds 0.5%. The bound includes uncertainty from the two
   endpoints and the sampled midpoint.

The control variate subtracts the retained collisions along the sampled
unperturbed line and adds their exact periodic-translation average. Its fixed
coefficient is one; it is an unbiased variance-reduction identity, not a
physical scaling factor. Calibration histories are never reused in production.
The exact average uses the threshold-defined cross section and numerically
integrated recoil/transport moments of the same interpolated kernel. Moment
quadrature is independently limited to one tenth of the kernel interpolation
tolerance.

The collision-tube sampler is an independent numerical layer around that
control variate. Its exact importance weight multiplies the sampled-minus-
reference residual. Proposal component, density ratio, weight, target, atom,
and adaptive `q` stratum are recorded for audit. Configuration signatures
include the proposal and mixture fraction, so legacy uniform checkpoints
cannot be mistaken for the corrected run.

Summary-mode checkpoints store sufficient statistics plus compressed
trajectory-level recoil/deflection samples. They do not write the enormous raw
per-collision CSV products. Seeds depend on the physical case, not worker count,
and all completed batches are checksum verified on resume.

The serial controller remains useful for small pilots. Production campaigns
use case-level sharding so that every structure/orientation/energy case has
exactly one writer and its own configuration-hashed trajectory checkpoints.
One reducer is the only writer of the adaptive energy-grid state. It analyzes
all completed cases at a refinement level, prepares every required geometric
midpoint as one immutable breadth-first wave, and chains the next wave only
after all case shards succeed.

Launch one selected projectile with:

```bash
bash pbs/launch_adaptive_nlh_particle_shards.sh C
```

Current case shards request 64 CPUs and 16 GB. The measured 128-worker rate is
only 1.49 times the 64-worker rate for twice the cores, so 64 is the efficient
campaign allocation; the higher memory request is scheduling headroom and
does not change the calculation. PBS arrays are limited to 50 elements, so the
supervisor splits a wave into non-overlapping array groups while preserving one
global shard index.

The carbon campaign rooted at configuration
`a14a646b863910cc662c2ec19f61292f9af5e12393e5cbec2d0ff6da199e9d28` began
with trajectory implementation v3. The repository later introduced the
distinct multi-kernel v4 signature. Its existing batches are therefore resumed
only by `pbs/run_adaptive_nlh_particle_shard_v3_resume.pbs`, which materializes
the exact launching revision `5f4adfe2585c4707c6d53dba10d580e876e1a688` in
node-local scratch. No persistent second checkout is created, and v3 and v4
batches are never merged. The runner requires the current absolute-width audit
and advances each failed case only to its next predeclared scheduled look. The old
mean-relative acceptance path is not used.

The earlier single-allocation controller remains available for diagnostics:

```bash
qsub -N nlh_C -v PROJECTILE=C pbs/run_adaptive_nlh_particle.pbs
```

The sharded trajectory batch is 100,000 histories. This reduces checkpoint
metadata by a factor of ten relative to the superseded 10,000-history runs,
without changing trajectory seeds or results; interruption loses at most the
currently executing batch. A repeated shard submission checksum-reuses every
completed batch.

The 0.5% criteria retained here apply to kernel/energy interpolation and the
predeclared trajectory-CDF band, not to scalar Monte Carlo means. They do not
reduce the separately reported NLH/DMol pair-potential uncertainty.
These jobs produce structure-sensitive validation and correction evidence;
they do not regenerate the exact analytic hard cross section. H and He outputs
must not overlap HTran in Geant4 and remain validation products until a
non-overlapping handoff or angular/impact-parameter partition is validated.
