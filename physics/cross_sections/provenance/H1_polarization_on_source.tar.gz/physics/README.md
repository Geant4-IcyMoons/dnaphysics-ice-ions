# Physics

[inelastic_dielectric](inelastic_dielectric/README.md) provides the migrated
dielectric workflow. [ctmc](ctmc/README.md) provides the finite COM production
workflow and rolling scheduler, which snapshot an explicitly supplied retained CTMC runtime. Its
collision kernels have not been migrated into this branch.
[Hard-collision production](elastic/hard_collisions/README.md) integrates
deterministic pair differential cross sections with cost-aware adaptive ice
response sampling, checkpoint audits and an explicitly pinned runtime. Pair
tables and phase-dependent transport have separate acceptance contracts.
Software installation is not physical qualification or a Geant4 release.
The [elastic kernels and shared transport](elastic/README.md) now live here.
Shared atomistic inputs live under [models/ice](../models/ice/README.md).
The Geant4 application remains on `ion`.

`constants.py` is the single shared source of material densities, projectile
masses, numerical worker defaults, plotting style, and output locations.
